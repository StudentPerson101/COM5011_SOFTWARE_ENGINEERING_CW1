"""Database helpers for the FASAM prototype.

Stage 4 verifies the SQLite database layer without adding FASAM domain tables.
The FASAM schema is intentionally deferred to the data model / schema stage.
"""
from pathlib import Path

from django.conf import settings
from django.db import connection


def database_path():
    name = settings.DATABASES["default"]["NAME"]
    return Path(name)


def database_summary():
    db_path = database_path()
    return {
        "engine": settings.DATABASES["default"]["ENGINE"],
        "name": str(db_path),
        "exists": db_path.exists(),
        "size_bytes": db_path.stat().st_size if db_path.exists() else 0,
        "using_sqlite": settings.DATABASES["default"]["ENGINE"] == "django.db.backends.sqlite3",
    }


def installed_table_names():
    with connection.cursor():
        return sorted(connection.introspection.table_names())


def database_health():
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1")
        result = cursor.fetchone()

    return {
        "can_connect": result == (1,),
        "vendor": connection.vendor,
        "tables": installed_table_names(),
    }
