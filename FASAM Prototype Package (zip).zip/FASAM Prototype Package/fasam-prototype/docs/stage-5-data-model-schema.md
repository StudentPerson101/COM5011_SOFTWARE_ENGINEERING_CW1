# Stage 5 Data Model / Schema

This stage defines the FASAM domain schema using Django models and an initial app migration.

The model layer is based on the supplied FASAM database design and covers:

- Building structure: buildings, zones, and rooms.
- Sensors and occupancy: sensor types, sensors, and occupancy readings.
- Alarm configuration: alarm policies and response rules.
- Alarm records: alarms, sensor evidence, and alarm confirmations.
- Control area and operators: control-area state, status logs, operators, and operator actions.
- Actuators and commands: actuator types, actuators, and actuator commands.
- Doors and isolation: doors and zone isolation records.
- External services and notifications.
- Event logging and configuration audit logging.

## Boundary

This stage is structural only. It does not add seed data, business rules, simulations, operator workflows, templates, form handling, or tests.

## Schema Source Of Truth

The schema source of truth is:

```text
fasam/models.py
fasam/migrations/0001_initial.py
```

Django's ORM and migrations are used instead of applying the supplied PostgreSQL DDL directly, so the prototype remains portable on SQLite.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py makemigrations --check --dry-run
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py migrate
.\venv1\Scripts\python.exe manage.py showmigrations fasam
```
