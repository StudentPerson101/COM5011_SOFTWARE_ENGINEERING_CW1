"""Stage 14 tests for the FASAM prototype."""
from __future__ import annotations

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Permission
from django.test import TestCase
from django.urls import reverse

from fasam.authz import CONFIGURATION_PERMISSION
from fasam.forms import SimulationActionForm
from fasam.models import (
    ActuatorCommand,
    ActuatorKind,
    Alarm,
    AlarmStatus,
    AlarmType,
    CommandType,
    DoorLockState,
    EventActorType,
    EventLog,
    EventType,
    Notification,
    NotificationMode,
    NotificationStatus,
    SensorCategory,
    ServiceType,
    Severity,
    StaffingStatus,
    Zone,
    ZoneIsolation,
)
from fasam.services.simulation import (
    SIMULATION_SOURCE,
    clear_alarm,
    ensure_demo_data,
    reset_zone,
    run_scenario,
    set_occupancy,
    simulate_notification,
    trigger_multiple_sensors,
    trigger_sensor,
)


def alarm_reference(alarm: Alarm) -> str:
    return f"A-{alarm.pk:04d}"


class FasamDemoDataMixin:
    """Build the reusable simulated FASAM plant used by service and view tests."""

    def setUp(self):
        super().setUp()
        result = ensure_demo_data()
        self.assertTrue(result.success)
        self.control_area = result.data["control_area"]

    def zone(self, code: str) -> Zone:
        return Zone.objects.get(zone_code=code)

    def first_sensor(self, zone_code: str, category: str):
        return (
            self.zone(zone_code)
            .sensors.select_related("sensor_type", "room")
            .filter(sensor_type__category=category)
            .order_by("device_code")
            .first()
        )

    def room(self, zone_code: str):
        return self.zone(zone_code).rooms.order_by("room_code").first()


class AlarmRuleServiceTests(FasamDemoDataMixin, TestCase):
    def test_single_fire_sensor_creates_suspected_alarm_and_log_entries(self):
        sensor = self.first_sensor("Zone 5", SensorCategory.FIRE)

        result = trigger_sensor(sensor, severity=Severity.MEDIUM)

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        alarm.refresh_from_db()
        self.assertEqual(alarm.alarm_type, AlarmType.FIRE)
        self.assertEqual(alarm.status, AlarmStatus.SUSPECTED)
        self.assertEqual(alarm.sensor_evidence.values("sensor_id").distinct().count(), 1)
        self.assertEqual(alarm.actuator_commands.count(), 0)
        self.assertTrue(
            EventLog.objects.filter(
                alarm=alarm,
                sensor=sensor,
                event_type=EventType.SENSOR_ACTIVATED,
            ).exists()
        )
        self.assertTrue(
            EventLog.objects.filter(
                alarm=alarm,
                source_system=SIMULATION_SOURCE,
                event_details__icontains=sensor.device_code,
            ).exists()
        )

    def test_multiple_fire_sensors_confirm_fire_and_block_suppression_when_people_detected(self):
        room = self.room("Zone 3")
        set_occupancy(room, "people")

        result = trigger_multiple_sensors(self.zone("Zone 3"), AlarmType.FIRE, 3, severity=Severity.CRITICAL)

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.CONFIRMED)
        self.assertEqual(alarm.sensor_evidence.values("sensor_id").distinct().count(), 3)
        self.assertEqual(alarm.confirmations.first().sensor_count_used, 2)
        self.assertEqual(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code=ActuatorKind.EXIT_INDICATOR,
                command_type=CommandType.ACTIVATE,
            ).count(),
            1,
        )
        self.assertEqual(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code=ActuatorKind.AUDIBLE_ALARM,
                command_type=CommandType.ACTIVATE,
            ).count(),
            1,
        )
        self.assertEqual(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code__in=[
                    ActuatorKind.SPRINKLER,
                    ActuatorKind.ELECTRICAL_SHUTDOWN,
                ],
            ).count(),
            0,
        )
        blocked_logs = EventLog.objects.filter(
            alarm=alarm,
            event_type=EventType.ACTUATOR_COMMAND_ISSUED,
            result="Blocked",
        )
        self.assertEqual(blocked_logs.count(), 2)
        self.assertTrue(all("People detected" in log.reason for log in blocked_logs))

    def test_confirmed_fire_with_clear_room_activates_suppression_and_auto_escalates_when_unmanned(self):
        self.control_area.current_staffing_status = StaffingStatus.UNMANNED
        self.control_area.save(update_fields=["current_staffing_status"])
        set_occupancy(self.room("Zone 5"), "clear")

        result = trigger_multiple_sensors(self.zone("Zone 5"), AlarmType.FIRE, 2, severity=Severity.CRITICAL)

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.CONFIRMED)
        self.assertTrue(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code=ActuatorKind.SPRINKLER,
                command_type=CommandType.ACTIVATE,
            ).exists()
        )
        self.assertTrue(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code=ActuatorKind.ELECTRICAL_SHUTDOWN,
                command_type=CommandType.ACTIVATE,
            ).exists()
        )
        notification = alarm.notifications.get(service__service_type=ServiceType.EMERGENCY_SERVICES)
        self.assertEqual(notification.notification_mode, NotificationMode.AUTOMATIC)
        self.assertEqual(notification.notification_status, NotificationStatus.SENT)
        self.assertFalse(EventLog.objects.filter(alarm=alarm, result="Blocked").exists())

    def test_security_alarm_locks_internal_doors_and_isolates_zone(self):
        result = trigger_multiple_sensors(self.zone("Zone 1"), AlarmType.SECURITY, 2, severity=Severity.HIGH)

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.CONFIRMED)
        self.assertEqual(alarm.zone.doors.filter(current_lock_state=DoorLockState.LOCKED).count(), 2)
        self.assertTrue(alarm.zone_isolations.filter(isolation_status="ACTIVE").exists())
        self.assertEqual(
            alarm.actuator_commands.filter(
                actuator__actuator_type__type_code=ActuatorKind.DOOR_LOCK,
                command_type=CommandType.LOCK,
            ).count(),
            2,
        )


class SimulationWorkflowTests(FasamDemoDataMixin, TestCase):
    def test_unknown_occupancy_fire_defaults_to_safety_blocking(self):
        result = run_scenario("unknown_occupancy_fire")

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        blocked = EventLog.objects.filter(
            alarm=alarm,
            event_type=EventType.ACTUATOR_COMMAND_ISSUED,
            result="Blocked",
        )
        self.assertEqual(blocked.count(), 2)
        self.assertTrue(all("Occupancy unknown" in log.reason for log in blocked))

    def test_false_fire_alarm_scenario_records_false_alarm_without_escalation(self):
        result = run_scenario("false_fire_alarm")

        self.assertTrue(result.success)
        alarm = result.data["alarm"]
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.FALSE_ALARM)
        self.assertEqual(alarm.confirmation_status, "REJECTED")
        self.assertFalse(alarm.notifications.exists())
        self.assertTrue(EventLog.objects.filter(alarm=alarm, event_type=EventType.SYSTEM_RESET).exists())

    def test_reset_zone_restores_alarms_actuators_doors_and_isolation_without_deleting_audit_history(self):
        scenario = run_scenario("security_intrusion")
        self.assertTrue(scenario.success)
        alarm = scenario.data["alarm"]
        zone = alarm.zone
        event_count_before_reset = EventLog.objects.count()

        result = reset_zone(zone)

        self.assertTrue(result.success)
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.RESOLVED)
        self.assertFalse(zone.doors.filter(current_lock_state=DoorLockState.LOCKED).exists())
        self.assertFalse(ZoneIsolation.objects.filter(zone=zone, isolation_status="ACTIVE").exists())
        self.assertFalse(zone.actuators.filter(status="ACTIVE").exists())
        self.assertGreater(EventLog.objects.count(), event_count_before_reset)

    def test_notification_simulation_uses_database_records_not_external_endpoints(self):
        scenario = run_scenario("security_intrusion")
        alarm = scenario.data["alarm"]

        send_result = simulate_notification(alarm, "send", ServiceType.SECURITY_SERVICES)
        fail_result = simulate_notification(alarm, "fail", ServiceType.SECURITY_SERVICES)
        retry_result = simulate_notification(alarm, "retry", ServiceType.SECURITY_SERVICES)
        ack_result = simulate_notification(alarm, "acknowledge", ServiceType.SECURITY_SERVICES)

        self.assertTrue(send_result.success)
        self.assertTrue(fail_result.success)
        self.assertTrue(retry_result.success)
        self.assertTrue(ack_result.success)
        notification = Notification.objects.filter(alarm=alarm).latest("sent_at")
        self.assertEqual(notification.notification_status, NotificationStatus.ACKNOWLEDGED)
        self.assertEqual(notification.service.contact_endpoint, "")
        self.assertTrue(
            EventLog.objects.filter(
                alarm=alarm,
                event_type=EventType.SERVICE_NOTIFIED,
                source_system=SIMULATION_SOURCE,
            ).exists()
        )

    def test_simulation_action_form_requires_target_fields(self):
        form = SimulationActionForm({"action": "set_occupancy", "occupancy_state": "people"})

        self.assertFalse(form.is_valid())
        self.assertIn("room", form.errors)


class ViewAndAuthorizationTests(FasamDemoDataMixin, TestCase):
    def create_configuration_user(self):
        user = get_user_model().objects.create_user("config-user", password="testpass123")
        app_label, codename = CONFIGURATION_PERMISSION.split(".", 1)
        permission = Permission.objects.get(content_type__app_label=app_label, codename=codename)
        user.user_permissions.add(permission)
        return user

    def test_dashboard_incident_zone_and_log_views_render_model_backed_content(self):
        fire = run_scenario("confirmed_fire_people").data["alarm"]
        security = run_scenario("security_intrusion").data["alarm"]

        dashboard = self.client.get(reverse("fasam:dashboard"))
        self.assertContains(dashboard, "Active Alarm Queue")
        self.assertContains(dashboard, alarm_reference(fire))

        fire_detail = self.client.get(reverse("fasam:fire_incident_detail", args=[alarm_reference(fire)]))
        self.assertContains(fire_detail, "Fire Incident")
        self.assertContains(fire_detail, "People detected")

        security_detail = self.client.get(reverse("fasam:security_incident_detail", args=[alarm_reference(security)]))
        self.assertContains(security_detail, "Security Incident")
        self.assertContains(security_detail, "Zone Isolation")

        zone_view = self.client.get(reverse("fasam:zone_overview"))
        self.assertContains(zone_view, "Building Zone Overview")

        log_view = self.client.get(reverse("fasam:event_log"))
        self.assertContains(log_view, "Event Log")

    def test_configuration_and_simulation_require_authorized_user(self):
        unauthenticated = self.client.get(reverse("fasam:simulation"))
        self.assertEqual(unauthenticated.status_code, 302)
        self.assertIn("/admin/login/", unauthenticated["Location"])

        regular_user = get_user_model().objects.create_user("viewer", password="testpass123")
        self.client.force_login(regular_user)
        self.assertEqual(self.client.get(reverse("fasam:configuration")).status_code, 403)

        config_user = self.create_configuration_user()
        self.client.force_login(config_user)
        self.assertContains(self.client.get(reverse("fasam:configuration")), "Configuration")
        self.assertContains(self.client.get(reverse("fasam:simulation")), "Scenario Controls")

    def test_operator_action_post_confirms_fire_alarm_and_writes_operator_audit(self):
        alarm = trigger_sensor(self.first_sensor("Zone 5", SensorCategory.FIRE), severity=Severity.MEDIUM).data["alarm"]

        response = self.client.post(
            reverse("fasam:alarm_action", args=[alarm_reference(alarm)]),
            {"action": "confirm_fire"},
        )

        self.assertEqual(response.status_code, 302)
        alarm.refresh_from_db()
        self.assertEqual(alarm.status, AlarmStatus.CONFIRMED)
        self.assertTrue(alarm.operator_actions.filter(action_type="CONFIRM_FIRE_ALARM").exists())
        self.assertTrue(EventLog.objects.filter(alarm=alarm, actor_type=EventActorType.OPERATOR).exists())

    def test_simulation_action_post_runs_authorized_scenario(self):
        self.client.force_login(self.create_configuration_user())

        response = self.client.post(
            reverse("fasam:simulation_action"),
            {"action": "run_scenario", "scenario": "confirmed_fire_unmanned"},
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(Alarm.objects.filter(alarm_type=AlarmType.FIRE, status=AlarmStatus.CONFIRMED).exists())
        self.assertTrue(Notification.objects.filter(notification_mode=NotificationMode.AUTOMATIC).exists())

    def test_event_log_csv_export_contains_audit_columns(self):
        run_scenario("confirmed_fire_people")

        response = self.client.get(reverse("fasam:event_log"), {"export": "csv"})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "text/csv")
        body = response.content.decode()
        self.assertIn("Actor Type", body)
        self.assertIn("Occupancy", body)
        self.assertIn("FASAM_SIMULATION", body)

    def test_stage_status_reports_testing_complete(self):
        response = self.client.get(reverse("fasam:stage_status"))

        self.assertEqual(response.status_code, 200)
        payload = response.json()["data"]
        self.assertEqual(payload["completed_stage"], "Stage-14. Testing")
        self.assertEqual(payload["testing"]["framework"], "Django TestCase")
