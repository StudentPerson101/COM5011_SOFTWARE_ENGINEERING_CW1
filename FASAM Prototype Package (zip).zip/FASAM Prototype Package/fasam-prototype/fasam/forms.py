"""Forms used by integrated FASAM views."""
from django import forms

from .models import AlarmStatus, AlarmType, CommandType, EventActorType, EventType, ServiceType, Severity, StaffingStatus
from .validation import parse_alarm_reference


class OperatorActionForm(forms.Form):
    """Small POST contract for operator buttons in the rendered UI."""

    ACTION_CHOICES = (
        ("acknowledge", "Acknowledge alarm"),
        ("notify_service", "Notify external service"),
        ("confirm_fire", "Confirm fire alarm"),
        ("confirm_security", "Confirm security alarm"),
        ("confirm_response", "Confirm operator response"),
        ("lock_doors", "Lock internal doors"),
        ("isolate_zone", "Isolate zone"),
        ("restore_access", "Unlock / restore access"),
        ("activate_sprinklers", "Activate sprinklers"),
        ("shutdown_electrical", "Shut down electrical equipment"),
        ("reset_restore", "Reset / restore system"),
    )

    action = forms.ChoiceField(choices=ACTION_CHOICES, widget=forms.HiddenInput)
    note = forms.CharField(required=False, max_length=300, widget=forms.HiddenInput)

    def clean_note(self):
        return (self.cleaned_data.get("note") or "").strip()


class ControlAreaStateForm(forms.Form):
    """Header form for changing the persisted control-area staffing state."""

    staffing_status = forms.ChoiceField(choices=StaffingStatus.choices)
    next = forms.CharField(required=False, widget=forms.HiddenInput)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["staffing_status"].widget.attrs.update({"class": "form-select form-select-sm"})


class DashboardStateForm(forms.Form):
    """GET-state form for the dashboard alarm queue."""

    q = forms.CharField(required=False, max_length=120)
    alarm_type = forms.ChoiceField(required=False, choices=[("", "Alarm Type")] + list(AlarmType.choices))
    severity = forms.ChoiceField(required=False, choices=[("", "Severity")] + list(Severity.choices))
    status = forms.ChoiceField(required=False, choices=[("", "Status")] + list(AlarmStatus.choices))
    zone = forms.ChoiceField(required=False, choices=[("", "Zone")])

    def __init__(self, *args, zones=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["q"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Alarm ID or zone", "aria-label": "Search alarms"}
        )
        for field_name in ("alarm_type", "severity", "status", "zone"):
            self.fields[field_name].widget.attrs.update({"class": "form-select"})
        if zones is not None:
            self.fields["zone"].choices = [("", "Zone")] + [
                (str(zone.pk), f"{zone.zone_code} / {zone.zone_name}") for zone in zones
            ]


class ZoneStateForm(forms.Form):
    """GET-state form for zone overview filtering and selected zone."""

    q = forms.CharField(required=False, max_length=120)
    status = forms.ChoiceField(
        required=False,
        choices=[
            ("", "Status"),
            ("normal", "Normal"),
            ("fire", "Fire active"),
            ("security", "Security active"),
            ("watch", "Awaiting confirmation"),
        ],
    )
    alarm_type = forms.ChoiceField(required=False, choices=[("", "Alarm Type")] + list(AlarmType.choices))
    occupancy = forms.ChoiceField(
        required=False,
        choices=[("", "Occupancy"), ("people", "People detected"), ("clear", "No people detected")],
    )
    device_state = forms.ChoiceField(
        required=False,
        choices=[("", "Device State"), ("active", "Actuator active"), ("locked", "Doors locked"), ("clear", "All clear")],
    )
    zone = forms.ChoiceField(required=False, choices=[("", "Selected Zone")])

    def __init__(self, *args, zones=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["q"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Zone", "aria-label": "Search zones"}
        )
        for field_name in ("status", "alarm_type", "occupancy", "device_state", "zone"):
            self.fields[field_name].widget.attrs.update({"class": "form-select"})
        if zones is not None:
            self.fields["zone"].choices = [("", "Selected Zone")] + [
                (str(zone.pk), f"{zone.zone_code} / {zone.zone_name}") for zone in zones
            ]


class EventLogStateForm(forms.Form):
    """GET-state form for event-log filtering and selected log entry."""

    q = forms.CharField(required=False, max_length=120)
    alarm = forms.CharField(required=False, max_length=16, widget=forms.HiddenInput)
    log = forms.IntegerField(required=False, min_value=1, widget=forms.HiddenInput)
    occurred_on = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    zone = forms.ChoiceField(required=False, choices=[("", "Zone")])
    alarm_type = forms.ChoiceField(required=False, choices=[("", "Alarm Type")] + list(AlarmType.choices))
    event_type = forms.ChoiceField(required=False, choices=[("", "Action Type")] + list(EventType.choices))
    operator = forms.ChoiceField(required=False, choices=[("", "Operator")])
    actor_type = forms.ChoiceField(
        required=False,
        choices=[("", "System / Manual")] + list(EventActorType.choices),
    )

    def __init__(self, *args, zones=None, operators=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["q"].widget.attrs.update(
            {"class": "form-control", "placeholder": "Logs", "aria-label": "Search logs"}
        )
        for field_name in ("occurred_on", "zone", "alarm_type", "event_type", "operator", "actor_type"):
            self.fields[field_name].widget.attrs.update({"class": "form-select"})
        if zones is not None:
            self.fields["zone"].choices = [("", "Zone")] + [
                (str(zone.pk), f"{zone.zone_code} / {zone.zone_name}") for zone in zones
            ]
        if operators is not None:
            self.fields["operator"].choices = [("", "Operator")] + [
                (str(operator.pk), operator.full_name or operator.username) for operator in operators
            ]

    def clean_alarm(self):
        value = (self.cleaned_data.get("alarm") or "").strip()
        if not value:
            return ""
        return str(parse_alarm_reference(value))


class SimulationActionForm(forms.Form):
    """POST contract for the prototype-only simulation page."""

    ACTION_CHOICES = (
        ("ensure_demo_data", "Load demo hardware"),
        ("trigger_fire_sensor", "Trigger fire sensor"),
        ("trigger_fire_multi", "Trigger multiple fire sensors"),
        ("trigger_security_sensor", "Trigger security sensor"),
        ("trigger_security_multi", "Trigger combined security event"),
        ("set_occupancy", "Set occupancy"),
        ("set_control_area", "Set control-area status"),
        ("simulate_actuator", "Simulate actuator command"),
        ("run_scenario", "Run scenario preset"),
        ("simulate_notification", "Simulate notification"),
        ("reset", "Reset / restore"),
    )
    OCCUPANCY_CHOICES = (
        ("people", "People detected"),
        ("clear", "No people detected"),
        ("unknown", "Unknown"),
    )
    NOTIFICATION_ACTIONS = (
        ("send", "Send"),
        ("fail", "Fail"),
        ("retry", "Retry"),
        ("acknowledge", "Acknowledge"),
    )
    RESET_CHOICES = (
        ("selected_alarm", "Reset selected incident"),
        ("selected_zone", "Reset selected zone"),
        ("all_active", "Reset all active alarms and actuators"),
        ("reload_demo", "Reload seeded demo data"),
        ("clear_logs", "Clear event log"),
    )

    action = forms.ChoiceField(choices=ACTION_CHOICES, widget=forms.HiddenInput)
    zone = forms.IntegerField(required=False, min_value=1)
    room = forms.IntegerField(required=False, min_value=1)
    sensor = forms.IntegerField(required=False, min_value=1)
    actuator = forms.IntegerField(required=False, min_value=1)
    alarm = forms.CharField(required=False, max_length=16)
    severity = forms.ChoiceField(required=False, choices=Severity.choices)
    occupancy_state = forms.ChoiceField(required=False, choices=OCCUPANCY_CHOICES)
    staffing_status = forms.ChoiceField(required=False, choices=StaffingStatus.choices)
    command_type = forms.ChoiceField(required=False, choices=CommandType.choices)
    scenario = forms.CharField(required=False, max_length=80)
    notification_action = forms.ChoiceField(required=False, choices=NOTIFICATION_ACTIONS)
    service_type = forms.ChoiceField(required=False, choices=ServiceType.choices)
    reset_scope = forms.ChoiceField(required=False, choices=RESET_CHOICES)

    def clean_alarm(self):
        value = (self.cleaned_data.get("alarm") or "").strip()
        if not value:
            return ""
        return str(parse_alarm_reference(value))

    def clean(self):
        cleaned = super().clean()
        action = cleaned.get("action")
        required_by_action = {
            "trigger_fire_sensor": ("sensor",),
            "trigger_fire_multi": ("zone",),
            "trigger_security_sensor": ("sensor",),
            "trigger_security_multi": ("zone",),
            "set_occupancy": ("room", "occupancy_state"),
            "set_control_area": ("staffing_status",),
            "simulate_actuator": ("actuator", "command_type"),
            "run_scenario": ("scenario",),
            "simulate_notification": ("alarm", "notification_action"),
            "reset": ("reset_scope",),
        }
        for field_name in required_by_action.get(action, ()):
            if cleaned.get(field_name) in ("", None):
                self.add_error(field_name, "This value is required for the selected simulation action.")
        if action == "reset":
            if cleaned.get("reset_scope") == "selected_alarm" and not cleaned.get("alarm"):
                self.add_error("alarm", "Select an active incident to reset.")
            if cleaned.get("reset_scope") == "selected_zone" and not cleaned.get("zone"):
                self.add_error("zone", "Select a zone to reset.")
        return cleaned
