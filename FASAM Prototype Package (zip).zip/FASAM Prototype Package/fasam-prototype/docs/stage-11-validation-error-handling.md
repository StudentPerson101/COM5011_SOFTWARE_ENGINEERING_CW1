# Stage 11 Validation and Error Handling

This stage adds expected-input validation and operator-readable error handling to the existing Django prototype. It does not add simulation endpoints, extra audit-trail scope, tests, deployment work, migrations, or seed data.

## Validation Scope

Validation is centralized in:

```text
fasam/validation.py
fasam/forms.py
fasam/views.py
```

The prototype now validates:

- Alarm references before lookup, accepting `A-0001` or a plain numeric ID.
- Dashboard, zone, and event-log filter state through Django forms before it is applied to queries.
- Event-log hidden alarm/log selections so malformed IDs do not become server errors.
- Control-area staffing changes through form validation and local-only redirect validation.
- Operator POST actions against the current alarm type and alarm status.
- Safety-sensitive sprinkler/electrical actions so they require a confirmed fire alarm before the existing occupancy block is evaluated.
- Security containment actions so they require a confirmed security alarm.

## Service Guardrails

The existing service layer now rejects invalid enum values earlier:

```text
fasam/services/alarm_rules.py
fasam/services/actuator_service.py
fasam/services/escalation_service.py
fasam/services/event_logger.py
```

These guards prevent unsupported severities, command types, service types, notification modes, event types, and operator-action types from silently creating inconsistent records. Security door locking and zone isolation also report a failed service result if a zone has no active door-lock actuators.

## Error Handling

The root URL configuration wires Django error handlers for:

```text
400 bad request
403 restricted access
404 missing page or record
500 unexpected server error
CSRF failure
```

HTML requests render:

```text
fasam/templates/fasam/errors/error.html
```

JSON-preferring requests receive the existing structured JSON error shape from `fasam/http.py`.

## Status Endpoint

`/stage-status/` now reports:

```text
Stage-11. Validation and error handling
```

and includes a `validation_error_handling` payload describing the active validation surfaces.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from django.test import Client; c=Client(HTTP_HOST='127.0.0.1'); paths=['/dashboard/?alarm_type=INVALID','/zones/?zone=999999','/logs/?log=abc','/alarms/fire/not-an-alarm/','/stage-status/']; print({p: c.get(p).status_code for p in paths}); print(c.get('/stage-status/').json()['data']['completed_stage'])"
```
