"""ASGI config for the FASAM local prototype."""
import os

from django.core.asgi import get_asgi_application


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "fasam_project.settings")

application = get_asgi_application()
