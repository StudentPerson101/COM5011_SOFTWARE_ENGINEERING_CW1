"""Root URL configuration for the FASAM local prototype."""
from django.contrib import admin
from django.urls import include, path


urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("fasam.urls")),
]

handler400 = "fasam.views.bad_request"
handler403 = "fasam.views.permission_denied"
handler404 = "fasam.views.page_not_found"
handler500 = "fasam.views.server_error"
