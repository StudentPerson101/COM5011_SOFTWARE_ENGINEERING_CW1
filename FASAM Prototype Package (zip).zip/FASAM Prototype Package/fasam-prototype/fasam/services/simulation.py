"""Prototype-only simulation layer for FASAM demo workflows."""
from __future__ import annotations

from dataclasses import dataclass

from django.db import transaction
from django.utils import timezone

from fasam.models import (
    Actuator,
    ActuatorKind,
    ActuatorStatus,
    ActuatorType,
    Alarm,
    AlarmPolicy,
    AlarmStatus,
    AlarmType,
    Building,
    CommandType,
    ConfirmationStatus,
    ControlArea,
    Door,
    DoorLockState,
    EventLog,
    EventType,
    ExternalService,
    IsolationStatus,
    Notification,
    NotificationMode,
    NotificationStatus,
    OccupancyReading,
    ResponseRule,
    Room,
    Sensor,
    SensorCategory,
    SensorStatus,
    SensorType,
    ServiceType,
    Severity,
    StaffingStatus,
    Zone,
    ZoneIsolation,
)

from .actuator_service import issue_actuator_command, restore_zone_access
from .alarm_rules import record_sensor_activation
from .contracts import ServiceResult
from .escalation_service import default_service_for_alarm, notify_service
from .event_logger import log_event


SIMULATION_SOURCE = "FASAM_SIMULATION"


@dataclass(frozen=True)
class ScenarioPreset:
    key: str
    title: str
    description: str
    expected: tuple[str, ...]


SCENARIO_PRESETS = (
    ScenarioPreset(
        "confirmed_fire_people",
        "Confirmed fire with people detected",
        "Zone 3 / Lab Wing, three fire sensors, people present, staffed control area.",
        (
            "Fire confirmed",
            "Evacuation and audible alarms active",
            "Sprinklers and shutdown blocked",
            "Fire services pending manual notification",
        ),
    ),
    ScenarioPreset(
        "confirmed_fire_unmanned",
        "Confirmed fire, unmanned control area",
        "Zone 5 / Storage, two fire sensors, no people detected, unmanned control area.",
        (
            "Fire confirmed",
            "Evacuation and audible alarms active",
            "Suppression/shutdown active where installed",
            "Emergency services automatically notified",
        ),
    ),
    ScenarioPreset(
        "security_intrusion",
        "Security intrusion with zone isolation",
        "Zone 1 / Reception, door and motion sensors, containment response.",
        (
            "Security alarm confirmed",
            "Internal doors locked",
            "Zone isolation active",
            "Security services pending manual notification",
        ),
    ),
    ScenarioPreset(
        "false_fire_alarm",
        "False fire alarm",
        "Zone 5 / Storage, one smoke sensor only, then clear as false alarm.",
        (
            "Fire suspected",
            "No full escalation",
            "Alarm marked false alarm",
            "Clear action logged",
        ),
    ),
    ScenarioPreset(
        "unknown_occupancy_fire",
        "Occupancy unknown safety case",
        "Zone 4 / Plant Room, confirmed fire with no occupancy reading.",
        (
            "Fire confirmed",
            "Evacuation and audible alarms active",
            "Suppression/shutdown blocked for safety review",
            "Unknown occupancy reason logged",
        ),
    ),
)


def scenario_presets() -> tuple[ScenarioPreset, ...]:
    return SCENARIO_PRESETS


def _code_filter(prefix: str):
    return {"device_code__startswith": prefix}


def _log(details: str, *, alarm=None, sensor=None, actuator=None, operator=None, result="", reason=""):
    return log_event(
        EventType.OPERATOR_ACTION,
        alarm=alarm,
        sensor=sensor,
        actuator=actuator,
        operator=operator,
        details=details,
        source_system=SIMULATION_SOURCE,
        result=result,
        reason=reason,
    )


def _sensor_type(type_code: str, category: str, description: str) -> SensorType:
    sensor_type, _created = SensorType.objects.get_or_create(
        type_code=type_code,
        defaults={"category": category, "description": description},
    )
    return sensor_type


def _actuator_type(type_code: str, description: str) -> ActuatorType:
    actuator_type, _created = ActuatorType.objects.get_or_create(
        type_code=type_code,
        defaults={"description": description},
    )
    return actuator_type


def _zone(building: Building, zone_code: str, zone_name: str, floor_no: int, description: str) -> Zone:
    zone, _created = Zone.objects.get_or_create(
        zone_code=zone_code,
        defaults={
            "building": building,
            "zone_name": zone_name,
            "floor_no": floor_no,
            "description": description,
        },
    )
    return zone


def _room(zone: Zone, room_code: str, room_name: str) -> Room:
    room, _created = Room.objects.get_or_create(
        room_code=room_code,
        defaults={"zone": zone, "room_name": room_name},
    )
    return room


def _sensor(sensor_type: SensorType, zone: Zone, room: Room | None, device_code: str, location: str) -> Sensor:
    sensor, _created = Sensor.objects.get_or_create(
        device_code=device_code,
        defaults={
            "sensor_type": sensor_type,
            "zone": zone,
            "room": room,
            "location_description": location,
            "status": SensorStatus.ACTIVE,
            "last_seen_at": timezone.now(),
        },
    )
    return sensor


def _actuator(
    actuator_type: ActuatorType,
    zone: Zone,
    room: Room | None,
    device_code: str,
    location: str,
) -> Actuator:
    actuator, _created = Actuator.objects.get_or_create(
        device_code=device_code,
        defaults={
            "actuator_type": actuator_type,
            "zone": zone,
            "room": room,
            "location_description": location,
            "status": ActuatorStatus.READY,
            "is_active": True,
        },
    )
    return actuator


def _policy(zone: Zone, alarm_type: str, min_sensor_count: int, serious_threshold: str = Severity.HIGH):
    policy, _created = AlarmPolicy.objects.get_or_create(
        zone=zone,
        alarm_type=alarm_type,
        defaults={
            "confirmation_required": True,
            "min_sensor_count": min_sensor_count,
            "confirmation_window_seconds": 120,
            "serious_severity_threshold": serious_threshold,
            "auto_notify_if_unmanned": True,
            "is_active": True,
        },
    )
    if policy.min_sensor_count != min_sensor_count:
        policy.min_sensor_count = min_sensor_count
        policy.save(update_fields=["min_sensor_count"])
    return policy


def ensure_demo_data(operator=None) -> ServiceResult:
    """Create reusable prototype-only data needed by the simulation page."""

    building, _created = Building.objects.get_or_create(
        name="FASAM Demo Building",
        defaults={"address": "Prototype simulation environment"},
    )
    control_area, _created = ControlArea.objects.get_or_create(
        building=building,
        name="Main Control Area",
        defaults={"location_description": "Prototype control room", "current_staffing_status": StaffingStatus.MANNED},
    )

    fire_type = _sensor_type("FIRE_SENSOR", SensorCategory.FIRE, "Simulated fire detection sensor")
    security_type = _sensor_type("SECURITY_SENSOR", SensorCategory.SECURITY, "Simulated security sensor")
    occupancy_type = _sensor_type("OCCUPANCY_DETECTOR", SensorCategory.OCCUPANCY, "Simulated occupancy detector")

    actuator_types = {
        kind: _actuator_type(kind, kind.replace("_", " ").title())
        for kind in (
            ActuatorKind.SPRINKLER,
            ActuatorKind.ELECTRICAL_SHUTDOWN,
            ActuatorKind.EXIT_INDICATOR,
            ActuatorKind.AUDIBLE_ALARM,
            ActuatorKind.DOOR_LOCK,
        )
    }

    z1 = _zone(building, "Zone 1", "Reception", 0, "Public reception and entrance doors")
    z2 = _zone(building, "Zone 2", "Offices", 1, "General office area")
    z3 = _zone(building, "Zone 3", "Lab Wing", 2, "Laboratory wing")
    z4 = _zone(building, "Zone 4", "Plant Room", -1, "Electrical and mechanical plant")
    z5 = _zone(building, "Zone 5", "Storage", 0, "Storage area")
    _zone(building, "Zone 6", "Loading Bay", 0, "Loading bay and goods entrance")

    rooms = {
        "reception": _room(z1, "R-Z1-RECEPTION", "Reception"),
        "lab": _room(z3, "R-Z3-LAB", "Lab Wing Main Room"),
        "plant": _room(z4, "R-Z4-PLANT", "Plant Room"),
        "storage": _room(z5, "R-Z5-STORAGE", "Storage"),
    }

    for idx in range(1, 4):
        _sensor(fire_type, z3, rooms["lab"], f"SIM-FIRE-Z3-{idx}", f"Lab Wing fire sensor {idx}")
    for idx in range(1, 3):
        _sensor(fire_type, z5, rooms["storage"], f"SIM-FIRE-Z5-{idx}", f"Storage fire sensor {idx}")
    for idx in range(1, 3):
        _sensor(fire_type, z4, rooms["plant"], f"SIM-FIRE-Z4-{idx}", f"Plant Room fire sensor {idx}")

    _sensor(security_type, z1, rooms["reception"], "SIM-SEC-Z1-DOOR", "Reception door contact")
    _sensor(security_type, z1, rooms["reception"], "SIM-SEC-Z1-MOTION", "Reception motion detector")
    for key, room in rooms.items():
        _sensor(occupancy_type, room.zone, room, f"SIM-OCC-{room.zone.zone_code.replace(' ', '')}-{key.upper()}", f"{room.room_name} occupancy detector")

    for zone, room, suffix in ((z3, rooms["lab"], "Z3"), (z4, rooms["plant"], "Z4"), (z5, rooms["storage"], "Z5")):
        for kind in (ActuatorKind.EXIT_INDICATOR, ActuatorKind.AUDIBLE_ALARM, ActuatorKind.SPRINKLER, ActuatorKind.ELECTRICAL_SHUTDOWN):
            _actuator(actuator_types[kind], zone, room, f"SIM-{kind}-{suffix}", f"{zone.zone_name} {kind.replace('_', ' ').lower()}")

    for code, name in (("NORTH", "Reception North"), ("EAST", "Reception East")):
        actuator = _actuator(actuator_types[ActuatorKind.DOOR_LOCK], z1, rooms["reception"], f"SIM-DOORLOCK-Z1-{code}", name)
        Door.objects.get_or_create(
            door_code=f"SIM-DOOR-Z1-{code}",
            defaults={"zone": z1, "actuator": actuator, "door_name": name, "current_lock_state": DoorLockState.UNLOCKED},
        )

    for zone in (z1, z3, z4, z5):
        _policy(zone, AlarmType.FIRE, 2)
        _policy(zone, AlarmType.SECURITY, 2)

    for service_type, service_name in (
        (ServiceType.FIRE_SERVICES, "Fire Services"),
        (ServiceType.SECURITY_SERVICES, "Security Services"),
        (ServiceType.EMERGENCY_SERVICES, "Emergency Services"),
    ):
        ExternalService.objects.get_or_create(service_type=service_type, service_name=service_name)

    _log("Simulation demo data ensured.", operator=operator)
    return ServiceResult.ok("Simulation demo data is ready.", building=building, control_area=control_area)


def simulation_summary() -> dict:
    return {
        "zones": Zone.objects.filter(zone_code__startswith="Zone ").count(),
        "fire_sensors": Sensor.objects.filter(sensor_type__category=SensorCategory.FIRE).count(),
        "security_sensors": Sensor.objects.filter(sensor_type__category=SensorCategory.SECURITY).count(),
        "occupancy_sensors": Sensor.objects.filter(sensor_type__category=SensorCategory.OCCUPANCY).count(),
        "active_alarms": Alarm.objects.filter(status__in=(AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED)).count(),
        "simulated_events": EventLog.objects.filter(source_system=SIMULATION_SOURCE).count(),
    }


def _first_room_for_zone(zone: Zone) -> Room | None:
    return zone.rooms.order_by("room_code").first()


@transaction.atomic
def set_occupancy(room: Room, state: str, *, operator=None) -> ServiceResult:
    """Set a simulated occupancy reading or clear readings for unknown state."""

    occupancy_sensor = room.sensors.filter(sensor_type__category=SensorCategory.OCCUPANCY).order_by("device_code").first()
    if occupancy_sensor is None:
        return ServiceResult.failed("No occupancy detector is configured for this room.", room=room)

    if state == "unknown":
        room.occupancy_readings.all().delete()
        _log(
            f"Simulation occupancy set to unknown for {room}.",
            sensor=occupancy_sensor,
            operator=operator,
            result="Recorded",
            reason="Occupancy unknown",
        )
        return ServiceResult.ok("Occupancy set to unknown.", room=room)

    detected = state == "people"
    reading = OccupancyReading.objects.create(
        sensor=occupancy_sensor,
        room=room,
        detected_people=detected,
        confidence_score=95,
    )
    log_event(
        EventType.OCCUPANCY_CHECKED,
        sensor=occupancy_sensor,
        operator=operator,
        details=f"Simulation occupancy override for {room}: {'people detected' if detected else 'no people detected'}.",
        source_system=SIMULATION_SOURCE,
        result="Recorded",
        occupancy_status="People detected" if detected else "No people detected",
    )
    return ServiceResult.ok("Occupancy override recorded.", reading=reading, room=room)


@transaction.atomic
def trigger_sensor(sensor: Sensor, *, severity: str = Severity.HIGH, operator=None) -> ServiceResult:
    """Trigger one simulated fire or security sensor through the alarm-rule service."""

    sensor.status = SensorStatus.ACTIVE
    sensor.last_seen_at = timezone.now()
    sensor.save(update_fields=["status", "last_seen_at"])
    result = record_sensor_activation(
        sensor,
        severity=severity,
        reading_value="SIMULATED_ACTIVE",
        evidence_note=f"Simulation trigger from {sensor.device_code}.",
        created_by=SIMULATION_SOURCE,
    )
    if result.success:
        _log(f"Simulation sensor trigger accepted for {sensor.device_code}.", alarm=result.data.get("alarm"), sensor=sensor, operator=operator)
    return result


def trigger_multiple_sensors(zone: Zone, alarm_type: str, count: int, *, severity: str = Severity.HIGH, operator=None) -> ServiceResult:
    category = SensorCategory.FIRE if alarm_type == AlarmType.FIRE else SensorCategory.SECURITY
    sensors = list(
        zone.sensors.select_related("sensor_type", "room")
        .filter(sensor_type__category=category, status=SensorStatus.ACTIVE)
        .order_by("device_code")[:count]
    )
    if len(sensors) < count:
        return ServiceResult.failed(f"Only {len(sensors)} matching simulated sensor(s) are configured for {zone}.")

    last_result = None
    for sensor in sensors:
        last_result = trigger_sensor(sensor, severity=severity, operator=operator)
        if not last_result.success:
            return last_result

    return ServiceResult.ok(
        f"{len(sensors)} simulated sensor trigger(s) recorded.",
        alarm=last_result.data.get("alarm") if last_result else None,
        sensors=sensors,
    )


@transaction.atomic
def clear_alarm(alarm: Alarm, *, operator=None, false_alarm: bool = False) -> ServiceResult:
    """Clear a simulated alarm as resolved or false alarm."""

    restore_zone_access(alarm.zone, operator=operator, alarm=alarm)
    alarm.status = AlarmStatus.FALSE_ALARM if false_alarm else AlarmStatus.RESOLVED
    alarm.confirmation_status = ConfirmationStatus.REJECTED if false_alarm else alarm.confirmation_status
    alarm.resolved_at = timezone.now()
    alarm.save(update_fields=["status", "confirmation_status", "resolved_at"])
    log_event(
        EventType.SYSTEM_RESET,
        alarm=alarm,
        operator=operator,
        details=f"Simulation cleared alarm as {'false alarm' if false_alarm else 'resolved'}.",
        source_system=SIMULATION_SOURCE,
    )
    return ServiceResult.ok("Simulated alarm cleared.", alarm=alarm)


@transaction.atomic
def reset_zone(zone: Zone, *, operator=None) -> ServiceResult:
    """Restore a zone to a normal simulated state without deleting audit history."""

    active_alarms = list(zone.alarms.filter(status__in=(AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED)))
    for alarm in active_alarms:
        clear_alarm(alarm, operator=operator)

    for actuator in zone.actuators.all():
        actuator.status = ActuatorStatus.READY
        actuator.save(update_fields=["status"])
    zone.doors.update(current_lock_state=DoorLockState.UNLOCKED)
    zone.isolations.filter(isolation_status=IsolationStatus.ACTIVE).update(
        isolation_status=IsolationStatus.RELEASED,
        ended_at=timezone.now(),
    )
    log_event(
        EventType.SYSTEM_RESET,
        operator=operator,
        details=f"Simulation reset zone {zone}.",
        source_system=SIMULATION_SOURCE,
    )
    return ServiceResult.ok("Zone simulation state reset.", zone=zone, alarms=active_alarms)


@transaction.atomic
def reset_all_simulation(*, operator=None, clear_logs: bool = False) -> ServiceResult:
    """Reset active simulated system state; optionally clear event history."""

    for alarm in list(Alarm.objects.filter(status__in=(AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED))):
        clear_alarm(alarm, operator=operator)
    Actuator.objects.all().update(status=ActuatorStatus.READY)
    Door.objects.all().update(current_lock_state=DoorLockState.UNLOCKED)
    ZoneIsolation.objects.filter(isolation_status=IsolationStatus.ACTIVE).update(
        isolation_status=IsolationStatus.RELEASED,
        ended_at=timezone.now(),
    )
    if clear_logs:
        EventLog.objects.all().delete()
    else:
        log_event(
            EventType.SYSTEM_RESET,
            operator=operator,
            details="Simulation reset all active alarms, actuators, doors, and isolations.",
            source_system=SIMULATION_SOURCE,
        )
    return ServiceResult.ok("Simulation state reset.")


def _zone_by_code(zone_code: str) -> Zone:
    return Zone.objects.get(zone_code=zone_code)


@transaction.atomic
def run_scenario(preset_key: str, *, operator=None) -> ServiceResult:
    ensure_demo_data(operator=operator)

    if preset_key == "confirmed_fire_people":
        zone = _zone_by_code("Zone 3")
        set_occupancy(_first_room_for_zone(zone), "people", operator=operator)
        result = trigger_multiple_sensors(zone, AlarmType.FIRE, 3, severity=Severity.CRITICAL, operator=operator)
    elif preset_key == "confirmed_fire_unmanned":
        zone = _zone_by_code("Zone 5")
        control_area = ControlArea.objects.filter(building=zone.building).first()
        if control_area:
            control_area.current_staffing_status = StaffingStatus.UNMANNED
            control_area.last_status_update = timezone.now()
            control_area.save(update_fields=["current_staffing_status", "last_status_update"])
        set_occupancy(_first_room_for_zone(zone), "clear", operator=operator)
        result = trigger_multiple_sensors(zone, AlarmType.FIRE, 2, severity=Severity.CRITICAL, operator=operator)
    elif preset_key == "security_intrusion":
        zone = _zone_by_code("Zone 1")
        result = trigger_multiple_sensors(zone, AlarmType.SECURITY, 2, severity=Severity.HIGH, operator=operator)
    elif preset_key == "false_fire_alarm":
        zone = _zone_by_code("Zone 5")
        result = trigger_multiple_sensors(zone, AlarmType.FIRE, 1, severity=Severity.MEDIUM, operator=operator)
        alarm = result.data.get("alarm") if result.success else None
        if alarm is not None:
            clear_alarm(alarm, operator=operator, false_alarm=True)
    elif preset_key == "unknown_occupancy_fire":
        zone = _zone_by_code("Zone 4")
        set_occupancy(_first_room_for_zone(zone), "unknown", operator=operator)
        result = trigger_multiple_sensors(zone, AlarmType.FIRE, 2, severity=Severity.HIGH, operator=operator)
    else:
        return ServiceResult.failed("Unknown simulation scenario preset.")

    if result.success:
        _log(f"Simulation scenario preset completed: {preset_key}.", alarm=result.data.get("alarm"), operator=operator)
        return ServiceResult.ok("Scenario preset completed.", alarm=result.data.get("alarm"), preset=preset_key)
    return result


@transaction.atomic
def simulate_notification(alarm: Alarm, action: str, service_type: str | None = None, *, operator=None) -> ServiceResult:
    service_type = service_type or default_service_for_alarm(alarm)
    latest = alarm.notifications.order_by("-sent_at").first()
    if action == "send":
        notification = notify_service(
            alarm,
            service_type,
            mode=NotificationMode.MANUAL,
            operator=operator,
            message_summary=f"Simulation manual notification for alarm #{alarm.pk}.",
        )
        return ServiceResult.ok("Notification simulated.", notification=notification)

    if latest is None:
        service = ExternalService.objects.filter(service_type=service_type).first()
        if service is None:
            return ServiceResult.failed("No external service endpoint is configured.")
        latest = Notification.objects.create(
            alarm=alarm,
            service=service,
            initiated_by_operator=operator,
            notification_mode=NotificationMode.MANUAL,
            notification_status=NotificationStatus.PENDING,
            message_summary=f"Simulation notification placeholder for alarm #{alarm.pk}.",
        )

    if action == "fail":
        latest.notification_status = NotificationStatus.FAILED
        latest.failure_reason = "Simulated notification failure."
        latest.save(update_fields=["notification_status", "failure_reason"])
        detail = "Notification failed in simulation."
        result = "Failed"
        reason = latest.failure_reason
    elif action == "retry":
        latest.notification_status = NotificationStatus.SENT
        latest.failure_reason = ""
        latest.sent_at = timezone.now()
        latest.save(update_fields=["notification_status", "failure_reason", "sent_at"])
        detail = "Notification retried in simulation."
        result = "Completed"
        reason = ""
    elif action == "acknowledge":
        latest.notification_status = NotificationStatus.ACKNOWLEDGED
        latest.acknowledged_at = timezone.now()
        latest.save(update_fields=["notification_status", "acknowledged_at"])
        detail = "Notification acknowledged in simulation."
        result = "Acknowledged"
        reason = ""
    else:
        return ServiceResult.failed("Unknown notification simulation action.")

    log_event(
        EventType.SERVICE_NOTIFIED,
        alarm=alarm,
        operator=operator,
        notification=latest,
        details=detail,
        source_system=SIMULATION_SOURCE,
        result=result,
        reason=reason,
    )
    return ServiceResult.ok(detail, notification=latest)


def simulation_action_url_for_alarm(alarm: Alarm | None) -> str:
    if alarm is None:
        return ""
    return f"A-{alarm.pk:04d}"
