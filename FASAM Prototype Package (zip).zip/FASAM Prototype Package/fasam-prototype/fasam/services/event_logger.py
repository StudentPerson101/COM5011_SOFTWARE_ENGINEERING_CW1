"""Event and operator-action logging helpers for FASAM services."""
from __future__ import annotations

from fasam.models import (
    ControlArea,
    ConfigAuditLog,
    ConfigChangeType,
    EventActorType,
    EventLog,
    EventType,
    OperatorAction,
    OperatorActionType,
)


def _event_label(event_type: str) -> str:
    try:
        return EventType(event_type).label
    except ValueError:
        return event_type.replace("_", " ").title()


def _actor_type_for(*, operator=None, source_system: str = "FASAM") -> str:
    if operator is not None:
        return EventActorType.OPERATOR
    if "SIMULATION" in (source_system or "").upper():
        return EventActorType.SIMULATION
    return EventActorType.SYSTEM


def _control_area_status_for(alarm=None) -> str:
    queryset = ControlArea.objects.all()
    if alarm is not None and getattr(alarm, "zone_id", None):
        queryset = queryset.filter(building_id=alarm.zone.building_id)
    control_area = queryset.order_by("name").first()
    return control_area.current_staffing_status if control_area else ""


def _occupancy_status_for(alarm=None) -> str:
    if alarm is None or not getattr(alarm, "room_id", None):
        return ""
    reading = alarm.room.occupancy_readings.order_by("-reading_time").first()
    if reading is None:
        return "Occupancy unknown"
    return "People detected" if reading.detected_people else "No people detected"


def _result_from_details(details: str) -> str:
    lowered = (details or "").lower()
    if "blocked" in lowered:
        return "Blocked"
    if "failed" in lowered or "failure" in lowered or "rejected" in lowered:
        return "Failed"
    if "pending" in lowered:
        return "Pending"
    if "reset" in lowered or "restored" in lowered or "cleared" in lowered:
        return "Completed"
    return "Recorded"


def _payload_for(*, alarm=None, sensor=None, actuator=None, operator=None, notification=None) -> dict:
    payload = {}
    if alarm is not None:
        payload.update(
            {
                "alarm_id": alarm.pk,
                "alarm_reference": f"A-{alarm.pk:04d}" if alarm.pk else "",
                "alarm_type": alarm.alarm_type,
                "alarm_status": alarm.status,
                "severity": alarm.severity,
                "zone_id": alarm.zone_id,
                "zone": str(alarm.zone),
                "room_id": alarm.room_id,
                "room": str(alarm.room) if alarm.room else "",
            }
        )
    if sensor is not None:
        payload.update({"sensor_id": sensor.pk, "sensor": sensor.device_code})
    if actuator is not None:
        payload.update({"actuator_id": actuator.pk, "actuator": actuator.device_code})
    if operator is not None:
        payload.update({"operator_id": operator.pk, "operator": operator.username})
    if notification is not None:
        payload.update(
            {
                "notification_id": notification.pk,
                "notification_status": notification.notification_status,
                "notification_mode": notification.notification_mode,
            }
        )
    return payload


def log_event(
    event_type: str,
    *,
    alarm=None,
    sensor=None,
    actuator=None,
    operator=None,
    notification=None,
    details: str = "",
    source_system: str = "FASAM",
    action_label: str = "",
    actor_type: str = "",
    result: str = "",
    reason: str = "",
    control_area_status: str = "",
    occupancy_status: str = "",
    payload: dict | None = None,
) -> EventLog:
    """Persist a normalized event-log row for system and operator activity."""

    if event_type not in EventType.values:
        raise ValueError(f"Unsupported event type: {event_type}")

    resolved_payload = _payload_for(
        alarm=alarm,
        sensor=sensor,
        actuator=actuator,
        operator=operator,
        notification=notification,
    )
    if payload:
        resolved_payload.update(payload)

    return EventLog.objects.create(
        alarm=alarm,
        sensor=sensor,
        actuator=actuator,
        operator=operator,
        notification=notification,
        event_type=event_type,
        action_label=action_label or _event_label(event_type),
        actor_type=actor_type or _actor_type_for(operator=operator, source_system=source_system),
        result=result or _result_from_details(details),
        reason=reason,
        control_area_status=control_area_status or _control_area_status_for(alarm),
        occupancy_status=occupancy_status or _occupancy_status_for(alarm),
        event_details=details,
        source_system=source_system,
        event_payload=resolved_payload,
    )


def log_operator_action(alarm, operator, action_type: str, note: str = "") -> OperatorAction:
    """Record an authorized operator action and mirror it into the event log."""

    if action_type not in OperatorActionType.values:
        raise ValueError(f"Unsupported operator action type: {action_type}")

    action = OperatorAction.objects.create(
        alarm=alarm,
        operator=operator,
        action_type=action_type,
        action_note=note,
    )
    log_event(
        EventType.OPERATOR_ACTION,
        alarm=alarm,
        operator=operator,
        details=f"{action_type}: {note}".strip(": "),
    )
    return action


def log_config_change(
    *,
    operator,
    entity_name: str,
    change_type: str,
    entity_id=None,
    old_value=None,
    new_value=None,
    note: str = "",
) -> ConfigAuditLog:
    """Record a configuration audit row and mirror it into the event log."""

    if change_type not in ConfigChangeType.values:
        raise ValueError(f"Unsupported config change type: {change_type}")

    audit = ConfigAuditLog.objects.create(
        operator=operator,
        entity_name=entity_name,
        entity_id=entity_id,
        change_type=change_type,
        old_value=old_value,
        new_value=new_value,
    )
    log_event(
        EventType.CONFIG_CHANGED,
        operator=operator,
        details=note or f"{change_type} {entity_name} configuration.",
        result="Recorded",
        payload={
            "config_audit_id": audit.pk,
            "entity_name": entity_name,
            "entity_id": entity_id,
            "change_type": change_type,
        },
    )
    return audit
