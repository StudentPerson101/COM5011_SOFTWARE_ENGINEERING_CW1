@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
title FASAM Prototype Server

echo.
echo FASAM Prototype Server
echo ======================
echo.

call :FindPython312

if not defined PYTHON_LAUNCHER (
    echo Python 3.12 was not found on this system.
    echo.
    set /p INSTALL_PYTHON=Auto install Python3.12? y/n: 

    if /I "!INSTALL_PYTHON!"=="Y" (
        where winget >nul 2>nul
        if errorlevel 1 (
            echo.
            echo WinGet was not found, so Python cannot be installed automatically.
            echo Install Python 3.12 from https://www.python.org/downloads/windows/ and run this file again.
            echo.
            pause
            exit /b 1
        )

        echo.
        echo Installing Python 3.12 with WinGet...
        winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
        if errorlevel 1 (
            echo.
            echo Python installation did not complete successfully.
            echo.
            pause
            exit /b 1
        )

        call :FindPython312
        if not defined PYTHON_LAUNCHER (
            echo.
            echo Python may have installed, but this terminal cannot see it yet.
            echo Close this window, open start_server.bat again, and try once more.
            echo.
            pause
            exit /b 1
        )
    ) else (
        echo.
        echo Setup cancelled. Python 3.12 is required to run this prototype.
        echo.
        pause
        exit /b 1
    )
)

%PYTHON_LAUNCHER% "%~dp0start_server.py"
set EXIT_CODE=%ERRORLEVEL%

if not "%EXIT_CODE%"=="0" (
    echo.
    echo The startup process stopped with exit code %EXIT_CODE%.
    echo.
    pause
)

exit /b %EXIT_CODE%

:FindPython312
set PYTHON_LAUNCHER=

py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
if not errorlevel 1 (
    set PYTHON_LAUNCHER=py -3.12
    exit /b 0
)

python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
if not errorlevel 1 (
    set PYTHON_LAUNCHER=python
    exit /b 0
)

exit /b 0
