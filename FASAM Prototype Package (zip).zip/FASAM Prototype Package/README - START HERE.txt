FASAM Prototype Package
=======================

Windows 10/11 setup:

1. Extract the whole zip folder.
2. Double-click "Setup FASAM Prototype.bat".
3. Answer the prompts in the terminal.

The setup can:

- install Python 3.12 with WinGet if it is missing
- create a desktop shortcut
- create the project .venv and install requirements
- start the local Django server

When the server is running, enter: http://127.0.0.1:8000/ into your preferred browser or click CTRL+C in this terminal to end the server.

Keep the "fasam-prototype" folder next to "Setup FASAM Prototype.bat".
If you move the project folder later, run setup again to recreate the desktop shortcut.
