"""Windows bootstrapper for the local FASAM Django prototype."""
from __future__ import annotations

import os
import socket
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
VENV_PYTHON = VENV_DIR / "Scripts" / "python.exe"
REQUIREMENTS = ROOT / "requirements.txt"
SHORTCUT_SCRIPT = ROOT / "create_desktop_shortcut.ps1"
HOST = "0.0.0.0"
PORT = os.environ.get("FASAM_PORT", "8000")


def prompt_yes_no(question: str) -> bool:
    while True:
        answer = input(f"{question} y/n: ").strip().lower()
        if answer in {"y", "yes"}:
            return True
        if answer in {"n", "no"}:
            return False
        print("Please enter y or n.")


def run_step(command: list[str], description: str) -> None:
    print()
    print(description)
    print(" ".join(f'"{part}"' if " " in part else part for part in command))
    subprocess.run(command, cwd=ROOT, check=True)


def ensure_windows() -> None:
    if os.name != "nt":
        raise RuntimeError("This automated launcher is intended for Windows only.")


def ensure_venv() -> None:
    if VENV_PYTHON.exists():
        print()
        print(f"Using existing virtual environment: {VENV_DIR}")
        return

    run_step(
        [sys.executable, "-m", "venv", str(VENV_DIR)],
        "Creating a fresh project virtual environment...",
    )


def install_requirements() -> None:
    if not REQUIREMENTS.exists():
        raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")

    ensure_venv()
    run_step(
        [str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"],
        "Upgrading pip inside the virtual environment...",
    )
    run_step(
        [str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)],
        "Installing project requirements...",
    )


def run_django_setup() -> None:
    run_step(
        [str(VENV_PYTHON), "manage.py", "migrate", "--noinput"],
        "Applying database migrations...",
    )
    run_step(
        [str(VENV_PYTHON), "manage.py", "configure_auth_roles"],
        "Configuring local FASAM auth roles...",
    )


def create_desktop_shortcut() -> None:
    if not SHORTCUT_SCRIPT.exists():
        raise FileNotFoundError(f"Missing shortcut script: {SHORTCUT_SCRIPT}")

    powershell = (
        Path(os.environ.get("SystemRoot", r"C:\Windows"))
        / "System32"
        / "WindowsPowerShell"
        / "v1.0"
        / "powershell.exe"
    )
    command = [
        str(powershell if powershell.exists() else "powershell"),
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(SHORTCUT_SCRIPT),
        "-ProjectRoot",
        str(ROOT),
    ]
    run_step(command, "Creating a desktop shortcut...")


def get_lan_ip() -> str | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            address = sock.getsockname()[0]
    except OSError:
        try:
            address = socket.gethostbyname(socket.gethostname())
        except OSError:
            return None

    if address.startswith("127."):
        return None
    return address


def server_env(lan_ip: str | None) -> dict[str, str]:
    env = os.environ.copy()
    allowed_hosts = ["127.0.0.1", "localhost"]
    if lan_ip:
        allowed_hosts.append(lan_ip)

    env["FASAM_ALLOWED_HOSTS"] = ",".join(allowed_hosts)
    return env


def start_server() -> None:
    if not VENV_PYTHON.exists():
        print()
        print("No .venv was found. The server needs the project requirements first.")
        if prompt_yes_no("Auto install requirements now?"):
            install_requirements()
        else:
            print("Server startup cancelled.")
            return

    run_django_setup()

    lan_ip = get_lan_ip()
    print()
    print("Starting the FASAM Django development server.")
    print("Keep this terminal window open while using the prototype.")
    print()
    print("Enter: http://127.0.0.1:8000/ into your preferred browser or click CTRL+C in this terminal to end the server.")
    print(f"Open this URL on this computer: http://127.0.0.1:{PORT}/")
    if lan_ip:
        print(f"Open this URL from another device on the same network: http://{lan_ip}:{PORT}/")
    print()
    print("Press Ctrl+C in this terminal to stop the server.")
    print()

    subprocess.run(
        [str(VENV_PYTHON), "manage.py", "runserver", f"{HOST}:{PORT}"],
        cwd=ROOT,
        env=server_env(lan_ip),
        check=True,
    )


def run_selected_actions(actions: set[str]) -> None:
    ensure_windows()
    if "create_shortcut" in actions:
        create_desktop_shortcut()
    if "install_requirements" in actions:
        install_requirements()
    if "start_server" in actions:
        start_server()


def parse_actions(argv: list[str]) -> set[str]:
    action_map = {
        "--create-shortcut": "create_shortcut",
        "--install-requirements": "install_requirements",
        "--start-server": "start_server",
    }
    actions = set()
    for arg in argv:
        if arg not in action_map:
            valid = ", ".join(action_map)
            raise ValueError(f"Unknown option {arg!r}. Valid options: {valid}")
        actions.add(action_map[arg])
    return actions


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        actions = parse_actions(argv)
        if actions:
            run_selected_actions(actions)
            return 0

        ensure_windows()
        print("This setup ignores any old portable venv folders and uses .venv in this project.")
        print()

        if prompt_yes_no("Create desktop shortcut?"):
            create_desktop_shortcut()
        else:
            print("Desktop shortcut creation skipped.")

        print()
        if prompt_yes_no("Auto install requirements?"):
            install_requirements()
        else:
            print("Requirement installation skipped.")

        print()
        if prompt_yes_no("Auto start server?"):
            start_server()
        else:
            print("Server startup skipped.")

        return 0
    except KeyboardInterrupt:
        print()
        print("Server stopped.")
        return 0
    except subprocess.CalledProcessError as exc:
        print()
        print(f"Command failed with exit code {exc.returncode}.")
        return exc.returncode
    except Exception as exc:
        print()
        print(f"Startup failed: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
