"""Application-level exceptions for FASAM backend code."""


class FasamError(Exception):
    """Base exception for expected FASAM application errors."""


class StageNotImplementedError(FasamError):
    """Raised when a later-stage capability is called before it exists."""


class InvalidOperatorActionError(FasamError):
    """Raised when an operator action cannot be accepted by backend code."""


class SafetyRuleViolationError(FasamError):
    """Raised when a requested action conflicts with a safety constraint."""
