"""External service escalation rules for FASAM alarms."""
from __future__ import annotations

from django.db import transaction

from fasam.models import (
    AlarmStatus,
    AlarmType,
    ControlArea,
    EventType,
    ExternalService,
    Notification,
    NotificationMode,
    NotificationStatus,
    ServiceType,
    StaffingStatus,
)

from .contracts import ServiceResult
from .event_logger import log_event


SEVERITY_RANK = {
    "LOW": 1,
    "MEDIUM": 2,
    "HIGH": 3,
    "CRITICAL": 4,
}


def alarm_is_serious(alarm) -> bool:
    """Compare alarm severity against its configured serious threshold."""

    threshold = alarm.policy.serious_severity_threshold if alarm.policy else "HIGH"
    return SEVERITY_RANK.get(alarm.severity, 0) >= SEVERITY_RANK.get(threshold, 3)


def control_area_for_alarm(alarm) -> ControlArea | None:
    """Return the first configured control area for the alarm building."""

    return ControlArea.objects.filter(building=alarm.zone.building).order_by("name").first()


def should_auto_notify(alarm, control_area: ControlArea | None = None) -> bool:
    """Decide if an alarm must auto-escalate because the control area is unmanned."""

    if alarm.status != AlarmStatus.CONFIRMED:
        return False
    if alarm.policy and not alarm.policy.auto_notify_if_unmanned:
        return False

    control_area = control_area or control_area_for_alarm(alarm)
    if control_area is None:
        return False

    return control_area.current_staffing_status == StaffingStatus.UNMANNED and alarm_is_serious(alarm)


def _service_label(service_type: str) -> str:
    labels = {
        ServiceType.FIRE_SERVICES: "Fire Services",
        ServiceType.SECURITY_SERVICES: "Security Services",
        ServiceType.EMERGENCY_SERVICES: "Emergency Services",
    }
    return labels.get(service_type, service_type.replace("_", " ").title())


def get_or_create_service(service_type: str) -> ExternalService:
    """Resolve an active service endpoint, creating a placeholder if needed."""

    if service_type not in ServiceType.values:
        raise ValueError(f"Unsupported external service type: {service_type}")

    service = ExternalService.objects.filter(service_type=service_type, is_active=True).order_by("service_name").first()
    if service is not None:
        return service

    return ExternalService.objects.create(
        service_type=service_type,
        service_name=_service_label(service_type),
    )


@transaction.atomic
def notify_service(
    alarm,
    service_type: str,
    *,
    mode: str = NotificationMode.MANUAL,
    operator=None,
    message_summary: str = "",
) -> Notification:
    """Create a notification record for an external service."""

    if mode not in NotificationMode.values:
        raise ValueError(f"Unsupported notification mode: {mode}")

    service = get_or_create_service(service_type)
    notification = Notification.objects.create(
        alarm=alarm,
        service=service,
        initiated_by_operator=operator,
        notification_mode=mode,
        notification_status=NotificationStatus.SENT,
        message_summary=message_summary or f"{alarm.alarm_type} alarm #{alarm.pk} in {alarm.zone}.",
    )
    log_event(
        EventType.SERVICE_NOTIFIED,
        alarm=alarm,
        operator=operator,
        notification=notification,
        details=f"{service.service_name} notified by {mode.lower()} escalation.",
        result="Sent",
    )
    return notification


@transaction.atomic
def auto_escalate_if_required(alarm) -> ServiceResult:
    """Notify emergency services when a serious confirmed alarm is unattended."""

    control_area = control_area_for_alarm(alarm)
    if not should_auto_notify(alarm, control_area):
        return ServiceResult.ok(
            "Automatic escalation not required.",
            alarm=alarm,
            control_area=control_area,
            notification=None,
        )

    notification = notify_service(
        alarm,
        ServiceType.EMERGENCY_SERVICES,
        mode=NotificationMode.AUTOMATIC,
        message_summary=f"Automatic escalation for serious {alarm.alarm_type.lower()} alarm #{alarm.pk}.",
    )
    return ServiceResult.ok(
        "Automatic emergency escalation sent.",
        alarm=alarm,
        control_area=control_area,
        notification=notification,
    )


def default_service_for_alarm(alarm) -> str:
    """Return the specialist service normally associated with an alarm type."""

    if alarm.alarm_type == AlarmType.FIRE:
        return ServiceType.FIRE_SERVICES
    return ServiceType.SECURITY_SERVICES
