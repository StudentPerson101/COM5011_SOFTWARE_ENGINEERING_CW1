"""Actuator and zone-isolation business rules for FASAM."""
from __future__ import annotations

from dataclasses import dataclass

from django.db import transaction
from django.utils import timezone

from fasam.models import (
    Actuator,
    ActuatorCommand,
    ActuatorKind,
    ActuatorStatus,
    AlarmStatus,
    AlarmType,
    CommandStatus,
    CommandType,
    Door,
    DoorLockState,
    EventType,
    IsolationStatus,
    OccupancyReading,
    Zone,
    ZoneIsolation,
)

from .contracts import ServiceResult
from .event_logger import log_event


@dataclass(frozen=True)
class OccupancyDecision:
    """Latest known room occupancy state used for safety-sensitive commands."""

    people_detected: bool
    reading: OccupancyReading | None = None
    reason: str = "No recent occupancy reading found."
    status_label: str = "Unknown"


def latest_occupancy_decision(room) -> OccupancyDecision:
    """Return the latest occupancy reading, blocking safety actions when unknown."""

    if room is None:
        return OccupancyDecision(
            True,
            None,
            "Occupancy unknown because no room is associated with this alarm.",
            "Occupancy unknown",
        )

    reading = room.occupancy_readings.select_related("sensor").order_by("-reading_time").first()
    if reading is None:
        return OccupancyDecision(True, None, "Occupancy unknown; safety-sensitive action requires review.", "Occupancy unknown")

    if reading.detected_people:
        return OccupancyDecision(True, reading, "People detected in the same room.", "People detected")
    return OccupancyDecision(False, reading, "Latest occupancy reading is clear.", "No people detected")


def _active_actuators(zone: Zone, actuator_kind: str, room=None):
    queryset = Actuator.objects.select_related("actuator_type", "room").filter(
        zone=zone,
        actuator_type__type_code=actuator_kind,
        is_active=True,
    )
    if room is not None:
        queryset = queryset.filter(room__in=[room, None])
    return queryset.order_by("device_code")


def issue_actuator_command(
    actuator: Actuator,
    command_type: str,
    *,
    alarm=None,
    response_rule=None,
    operator=None,
    complete_immediately: bool = True,
) -> ActuatorCommand:
    """Create an actuator command and update local actuator/door state."""

    if command_type not in CommandType.values:
        raise ValueError(f"Unsupported actuator command type: {command_type}")
    if not actuator.is_active:
        raise ValueError(f"Actuator {actuator.device_code} is inactive and cannot accept commands.")

    now = timezone.now()
    command = ActuatorCommand.objects.create(
        actuator=actuator,
        alarm=alarm,
        response_rule=response_rule,
        issued_by_operator=operator,
        command_type=command_type,
        command_status=CommandStatus.COMPLETED if complete_immediately else CommandStatus.SENT,
        issued_at=now,
        completed_at=now if complete_immediately else None,
    )

    if complete_immediately:
        if command_type in (CommandType.ACTIVATE, CommandType.LOCK, CommandType.ISOLATE_ZONE):
            actuator.status = ActuatorStatus.ACTIVE
        elif command_type in (CommandType.DEACTIVATE, CommandType.UNLOCK, CommandType.RESET):
            actuator.status = ActuatorStatus.READY
        actuator.save(update_fields=["status"])

        if actuator.actuator_type.type_code == ActuatorKind.DOOR_LOCK:
            door = getattr(actuator, "door", None)
            if door is not None:
                if command_type == CommandType.LOCK:
                    door.current_lock_state = DoorLockState.LOCKED
                    door.save(update_fields=["current_lock_state"])
                elif command_type in (CommandType.UNLOCK, CommandType.RESET):
                    door.current_lock_state = DoorLockState.UNLOCKED
                    door.save(update_fields=["current_lock_state"])

    log_event(
        EventType.ACTUATOR_COMMAND_ISSUED,
        alarm=alarm,
        actuator=actuator,
        operator=operator,
        details=f"{command_type} command issued to {actuator.device_code}.",
        result="Completed" if complete_immediately else "Sent",
    )
    return command


@transaction.atomic
def activate_fire_response(alarm, *, operator=None) -> ServiceResult:
    """Apply confirmed-fire response rules with occupancy safety blocking."""

    if alarm.alarm_type != AlarmType.FIRE or alarm.status != AlarmStatus.CONFIRMED:
        return ServiceResult.failed("Fire response requires a confirmed fire alarm.", alarm=alarm)

    issued_commands = []
    blocked_actions = []

    for actuator_kind in (ActuatorKind.EXIT_INDICATOR, ActuatorKind.AUDIBLE_ALARM):
        for actuator in _active_actuators(alarm.zone, actuator_kind):
            issued_commands.append(
                issue_actuator_command(
                    actuator,
                    CommandType.ACTIVATE,
                    alarm=alarm,
                    operator=operator,
                )
            )

    occupancy = latest_occupancy_decision(alarm.room)
    log_event(
        EventType.OCCUPANCY_CHECKED,
        alarm=alarm,
        operator=operator,
        details=occupancy.reason,
        result="Blocked" if occupancy.people_detected else "Clear",
        reason=occupancy.reason if occupancy.people_detected else "",
        occupancy_status=occupancy.status_label,
    )

    for actuator_kind in (ActuatorKind.SPRINKLER, ActuatorKind.ELECTRICAL_SHUTDOWN):
        for actuator in _active_actuators(alarm.zone, actuator_kind, room=alarm.room):
            if occupancy.people_detected:
                blocked_actions.append(
                    {
                        "actuator": actuator,
                        "command_type": CommandType.ACTIVATE,
                        "reason": occupancy.reason,
                    }
                )
                log_event(
                    EventType.ACTUATOR_COMMAND_ISSUED,
                    alarm=alarm,
                    actuator=actuator,
                    operator=operator,
                    details=f"ACTIVATE command blocked for {actuator.device_code}: {occupancy.reason}",
                    result="Blocked",
                    reason=occupancy.reason,
                    occupancy_status=occupancy.status_label,
                )
                continue

            issued_commands.append(
                issue_actuator_command(
                    actuator,
                    CommandType.ACTIVATE,
                    alarm=alarm,
                    operator=operator,
                )
            )

    return ServiceResult.ok(
        "Confirmed fire response evaluated.",
        alarm=alarm,
        issued_commands=issued_commands,
        blocked_actions=blocked_actions,
        occupancy=occupancy,
    )


@transaction.atomic
def lock_security_doors(alarm, *, operator=None) -> ServiceResult:
    """Lock internal doors for a confirmed security alarm."""

    if alarm.alarm_type != AlarmType.SECURITY or alarm.status != AlarmStatus.CONFIRMED:
        return ServiceResult.failed("Door locking requires a confirmed security alarm.", alarm=alarm)

    commands = []
    skipped = []
    for door in Door.objects.select_related("actuator", "actuator__actuator_type").filter(zone=alarm.zone):
        if door.actuator.is_active:
            commands.append(
                issue_actuator_command(
                    door.actuator,
                    CommandType.LOCK,
                    alarm=alarm,
                    operator=operator,
                )
            )
        else:
            skipped.append(door)

    if not commands:
        return ServiceResult.failed(
            "No active door-lock actuators are configured for this zone.",
            alarm=alarm,
            skipped_doors=skipped,
        )
    return ServiceResult.ok("Security doors locked.", alarm=alarm, issued_commands=commands)


@transaction.atomic
def isolate_zone(alarm, *, operator=None, reason: str = "Security alarm containment") -> ServiceResult:
    """Create or reuse active zone isolation and lock zone doors."""

    if alarm.alarm_type != AlarmType.SECURITY or alarm.status != AlarmStatus.CONFIRMED:
        return ServiceResult.failed("Zone isolation requires a confirmed security alarm.", alarm=alarm)

    isolation = ZoneIsolation.objects.filter(
        zone=alarm.zone,
        alarm=alarm,
        isolation_status=IsolationStatus.ACTIVE,
    ).first()
    if isolation is None:
        isolation = ZoneIsolation.objects.create(
            zone=alarm.zone,
            alarm=alarm,
            isolation_status=IsolationStatus.ACTIVE,
            reason=reason,
        )
    door_result = lock_security_doors(alarm, operator=operator)

    if not door_result.success:
        return ServiceResult.failed(door_result.message, alarm=alarm, isolation=isolation)

    return ServiceResult.ok(
        "Zone isolation is active.",
        alarm=alarm,
        isolation=isolation,
        issued_commands=door_result.data.get("issued_commands", []),
    )


@transaction.atomic
def restore_zone_access(zone: Zone, *, operator=None, alarm=None) -> ServiceResult:
    """Unlock internal doors and release active isolations for a zone."""

    commands = []
    for door in Door.objects.select_related("actuator", "actuator__actuator_type").filter(zone=zone):
        if door.actuator.is_active:
            commands.append(
                issue_actuator_command(
                    door.actuator,
                    CommandType.UNLOCK,
                    alarm=alarm,
                    operator=operator,
                )
            )

    released = []
    for isolation in zone.isolations.filter(isolation_status=IsolationStatus.ACTIVE):
        isolation.isolation_status = IsolationStatus.RELEASED
        isolation.ended_at = timezone.now()
        isolation.save(update_fields=["isolation_status", "ended_at"])
        released.append(isolation)

    log_event(
        EventType.SYSTEM_RESET,
        alarm=alarm,
        operator=operator,
        details=f"Zone access restored for {zone.zone_code}.",
    )
    return ServiceResult.ok("Zone access restored.", zone=zone, released_isolations=released, issued_commands=commands)
