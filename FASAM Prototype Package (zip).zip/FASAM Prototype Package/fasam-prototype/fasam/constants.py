"""Shared backend constants for the FASAM Django app.

These values describe stable application vocabulary without creating database
models or implementing response rules. Later stages can reuse them in models,
forms, services, templates, and tests.
"""
from enum import StrEnum


class AlarmType(StrEnum):
    FIRE = "FIRE"
    SECURITY = "SECURITY"


class AlarmStatus(StrEnum):
    SUSPECTED = "SUSPECTED"
    CONFIRMED = "CONFIRMED"
    FALSE_ALARM = "FALSE_ALARM"
    RESOLVED = "RESOLVED"


class Severity(StrEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class StaffingStatus(StrEnum):
    MANNED = "MANNED"
    UNMANNED = "UNMANNED"


class EventType(StrEnum):
    SENSOR_ACTIVATED = "SENSOR_ACTIVATED"
    ALARM_CREATED = "ALARM_CREATED"
    ALARM_CONFIRMED = "ALARM_CONFIRMED"
    CONTROL_AREA_ALERTED = "CONTROL_AREA_ALERTED"
    SERVICE_NOTIFIED = "SERVICE_NOTIFIED"
    ACTUATOR_COMMAND_ISSUED = "ACTUATOR_COMMAND_ISSUED"
    OCCUPANCY_CHECKED = "OCCUPANCY_CHECKED"
    SYSTEM_RESET = "SYSTEM_RESET"
    CONFIG_CHANGED = "CONFIG_CHANGED"
    OPERATOR_ACTION = "OPERATOR_ACTION"


class ActuatorType(StrEnum):
    SPRINKLER = "SPRINKLER"
    ELECTRICAL_SHUTDOWN = "ELECTRICAL_SHUTDOWN"
    EXIT_INDICATOR = "EXIT_INDICATOR"
    AUDIBLE_ALARM = "AUDIBLE_ALARM"
    DOOR_LOCK = "DOOR_LOCK"


def enum_choices(enum_class):
    """Return Django-friendly choices from a string enum."""
    return [(item.value, item.value.replace("_", " ").title()) for item in enum_class]
