# Stage 13 - Event Logging / Audit Trail

This stage expands the existing event log into a usable audit trail. It does not implement the later testing or deployment stages.

## Implemented Scope

- Added normalized `EventLog` audit fields for action label, actor type, result, reason, control-area status, occupancy status, and structured payload context.
- Added migration `0002_eventlog_audit_fields.py` with a backfill for existing log rows.
- Updated `log_event()` so system, operator, and simulation events automatically capture related alarm, zone, room, sensor, actuator, notification, staffing, and occupancy context.
- Added `log_config_change()` to mirror configuration audit rows into the main event log.
- Improved blocked/failed/sent/completed results for actuator, occupancy, notification, and manual safety-action logging.
- Expanded `/logs/` filters to include date, operator, and actor/source in addition to search, zone, alarm type, and action type.
- Added CSV export through `/logs/?export=csv`.
- Expanded the selected log detail panel with result, reason, device, source, control-area status, occupancy status, incident link, zone link, and print support.

## Audit Coverage

The logger records alarm activations, alarm creation, confirmations, control-area alerts, notifications, actuator commands, occupancy checks, resets, configuration changes, and operator actions. The structured payload keeps traceable IDs and display labels for related alarms, zones, rooms, sensors, actuators, notifications, and operators.

## Verification

Run:

```powershell
.\venv1\Scripts\python.exe manage.py migrate
.\venv1\Scripts\python.exe manage.py check
```

Optional smoke check:

```powershell
.\venv1\Scripts\python.exe manage.py shell -c "from fasam.services.simulation import ensure_demo_data, run_scenario; from fasam.models import EventLog; ensure_demo_data(); run_scenario('confirmed_fire_people'); log = EventLog.objects.latest('event_time'); print(log.action_label, log.actor_type, log.result, bool(log.event_payload))"
```
