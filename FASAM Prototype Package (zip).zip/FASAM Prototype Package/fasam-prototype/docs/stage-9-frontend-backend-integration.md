# Stage 9 Frontend-Backend Integration

This stage connects the existing Stage 8 Django templates to the Stage 5 models and Stage 6 service layer. It does not add seed data, simulations, new database schema, tests, or deployment work.

## Integrated Views

The main application routes now render HTML templates backed by Django ORM queries:

```text
/dashboard/
/alarms/fire/<alarm-reference>/
/alarms/security/<alarm-reference>/
/zones/
/logs/
/configuration/
```

The dashboard and partial alarm queue show active suspected or confirmed alarms from the database. The incident pages show alarm evidence, current zone state, notification state, occupancy checks, door isolation state, and recent operator actions from related model records.

## Operator Actions

Incident and dashboard buttons now submit POST requests to:

```text
/alarms/<alarm-reference>/action/
```

Supported actions include acknowledgement, manual fire/security notification, operator confirmation, security door locking, zone isolation, access restoration, safety-gated sprinkler/electrical commands, and reset/restore. These actions call the existing backend services where available and write operator or event log rows.

For local prototype usability, unauthenticated operator actions are recorded against a simulated `operator_a` record. Authenticated users are recorded by their Django username. The configuration screen still requires Django login plus the existing `fasam.change_alarmpolicy` permission.

## Dynamic Partials

The alarm queue partial is model-backed and available at:

```text
/dashboard/alarm-queue/
```

This can later be used for HTMX refresh behavior without changing the view contract.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from django.test import Client; c=Client(HTTP_HOST='127.0.0.1'); print({p: c.get(p).status_code for p in ['/dashboard/','/zones/','/logs/','/logs/?alarm=1','/dashboard/alarm-queue/','/stage-status/']})"
```
