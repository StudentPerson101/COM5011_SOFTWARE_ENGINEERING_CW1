# Stage 3 Page/View Design

This document records the page and view design for the FASAM Django prototype. It is intentionally limited to page contracts and route design. It does not add database models, migrations, seed data, templates, authentication rules, business logic, simulations, or tests.

## Page Map

| Page | Route name | Path | Planned template | Source wireframe |
| --- | --- | --- | --- | --- |
| Control Area Dashboard | `fasam:dashboard` | `/dashboard/` | `fasam/dashboard.html` | `p1 - Control Area Dashboard.txt` |
| Fire Alarm Incident Details | `fasam:fire_incident_detail` | `/alarms/fire/<alarm_reference>/` | `fasam/fire_incident_detail.html` | `p2 - Fire Alarm Incident Details.txt` |
| Security Alarm Incident Details | `fasam:security_incident_detail` | `/alarms/security/<alarm_reference>/` | `fasam/security_incident_detail.html` | `p3 - Security Alarm Incident Details.txt` |
| Zone Status / Building Overview | `fasam:zone_overview` | `/zones/` | `fasam/zone_overview.html` | `p4 - Zone Status or Building Overview.txt` |
| Event Log / Audit History | `fasam:event_log` | `/logs/` | `fasam/event_log.html` | `p5 - Event Log or Audit History.txt` |
| Configuration / Authorized Settings | `fasam:configuration` | `/configuration/` | `fasam/configuration.html` | `p6 - Configuration or Authorized Settings.txt` |

The root path `/` is mapped to the dashboard design because the eventual application should open into the control-area interface.

## Current Design Endpoints

The current endpoints return JSON contracts instead of rendered pages:

```text
/
/dashboard/
/alarms/fire/A-1047/
/alarms/security/A-1048/
/zones/
/logs/
/configuration/
/page-design/
/page-design/<page_key>/
```

These responses expose planned sections, filters, operator actions, context contracts, planned templates, and deferred implementation notes.

## Deferred Work

- Database-backed page data belongs to the database and data-model stages.
- Business decisions such as confirmation, escalation, occupancy blocking, door locking, and audit writing belong to the business-logic and event-logging stages.
- HTML, Bootstrap layout, partial templates, CSS, JavaScript, and HTMX behavior belong to the frontend stages.
- Operator action POST handlers belong to the integration, validation, simulation, and logging stages.
