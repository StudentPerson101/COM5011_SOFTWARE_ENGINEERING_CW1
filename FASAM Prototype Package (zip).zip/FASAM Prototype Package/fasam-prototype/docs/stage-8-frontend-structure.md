# Stage 8 Frontend Structure

This stage adds the Django template and static-file structure for the FASAM interface. It does not connect the templates to model queries, forms, simulations, HTMX refreshes, or live state.

## Created Structure

```text
fasam/templates/fasam/base.html
fasam/templates/fasam/dashboard.html
fasam/templates/fasam/fire_incident_detail.html
fasam/templates/fasam/security_incident_detail.html
fasam/templates/fasam/zone_overview.html
fasam/templates/fasam/event_log.html
fasam/templates/fasam/configuration.html
fasam/templates/fasam/partials/alarm_queue.html
fasam/templates/fasam/partials/recent_logs.html
fasam/templates/fasam/partials/zone_status_cards.html
fasam/static/fasam/css/styles.css
fasam/static/fasam/js/app.js
```

## Template Boundary

The templates mirror the supplied wireframes using Bootstrap-oriented HTML and local static assets. They currently use structural sample content so that later stages can replace those values with database-backed context.

Stage 9 can wire the existing Django views to render these templates and provide context from the Stage 5 models and Stage 6 services.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from django.template.loader import get_template; [get_template(name) for name in ['fasam/base.html','fasam/dashboard.html','fasam/fire_incident_detail.html','fasam/security_incident_detail.html','fasam/zone_overview.html','fasam/event_log.html','fasam/configuration.html']]; print('stage-8 templates load ok')"
```
