"""Authentication and authorization helpers for the FASAM prototype."""
from __future__ import annotations

from dataclasses import dataclass


FASAM_OPERATOR_GROUP = "FASAM Operators"
FASAM_SUPERVISOR_GROUP = "FASAM Supervisors"
FASAM_CONFIG_ADMIN_GROUP = "FASAM Configuration Administrators"
FASAM_MAINTENANCE_GROUP = "FASAM Maintenance"

CONFIGURATION_PERMISSION = "fasam.change_alarmpolicy"
CONTROL_COMMAND_PERMISSION = "fasam.add_actuatorcommand"
OPERATOR_ACTION_PERMISSION = "fasam.add_operatoraction"
ALARM_MANAGEMENT_PERMISSION = "fasam.change_alarm"


@dataclass(frozen=True)
class RoleDefinition:
    """A named Django group and the permissions assigned to it."""

    name: str
    permissions: tuple[str, ...]


MONITORING_PERMISSIONS = (
    "fasam.view_alarm",
    "fasam.view_alarmsensorevidence",
    "fasam.view_alarmconfirmation",
    "fasam.view_zone",
    "fasam.view_room",
    "fasam.view_sensor",
    "fasam.view_sensortype",
    "fasam.view_occupancyreading",
    "fasam.view_controlarea",
    "fasam.view_controlareastatuslog",
    "fasam.view_actuator",
    "fasam.view_actuatortype",
    "fasam.view_actuatorcommand",
    "fasam.view_door",
    "fasam.view_zoneisolation",
    "fasam.view_notification",
    "fasam.view_externalservice",
    "fasam.view_eventlog",
)

OPERATOR_ACTION_PERMISSIONS = (
    OPERATOR_ACTION_PERMISSION,
    ALARM_MANAGEMENT_PERMISSION,
    "fasam.add_alarmconfirmation",
    "fasam.add_notification",
    "fasam.add_controlareastatuslog",
    CONTROL_COMMAND_PERMISSION,
    "fasam.change_actuator",
    "fasam.change_door",
    "fasam.add_zoneisolation",
    "fasam.change_zoneisolation",
)

CONFIGURATION_PERMISSIONS = (
    "fasam.add_building",
    "fasam.change_building",
    "fasam.delete_building",
    "fasam.add_zone",
    "fasam.change_zone",
    "fasam.delete_zone",
    "fasam.add_room",
    "fasam.change_room",
    "fasam.delete_room",
    "fasam.add_sensor",
    "fasam.change_sensor",
    "fasam.delete_sensor",
    "fasam.add_sensortype",
    "fasam.change_sensortype",
    "fasam.delete_sensortype",
    "fasam.add_alarmpolicy",
    CONFIGURATION_PERMISSION,
    "fasam.delete_alarmpolicy",
    "fasam.add_responserule",
    "fasam.change_responserule",
    "fasam.delete_responserule",
    "fasam.add_actuator",
    "fasam.change_actuator",
    "fasam.delete_actuator",
    "fasam.add_actuatortype",
    "fasam.change_actuatortype",
    "fasam.delete_actuatortype",
    "fasam.add_door",
    "fasam.change_door",
    "fasam.delete_door",
    "fasam.add_controlarea",
    "fasam.change_controlarea",
    "fasam.delete_controlarea",
    "fasam.add_externalservice",
    "fasam.change_externalservice",
    "fasam.delete_externalservice",
    "fasam.add_configauditlog",
    "fasam.view_configauditlog",
)

ROLE_DEFINITIONS = (
    RoleDefinition(
        FASAM_OPERATOR_GROUP,
        MONITORING_PERMISSIONS + OPERATOR_ACTION_PERMISSIONS,
    ),
    RoleDefinition(
        FASAM_SUPERVISOR_GROUP,
        MONITORING_PERMISSIONS + OPERATOR_ACTION_PERMISSIONS + ("fasam.view_configauditlog",),
    ),
    RoleDefinition(
        FASAM_CONFIG_ADMIN_GROUP,
        MONITORING_PERMISSIONS + OPERATOR_ACTION_PERMISSIONS + CONFIGURATION_PERMISSIONS,
    ),
    RoleDefinition(
        FASAM_MAINTENANCE_GROUP,
        MONITORING_PERMISSIONS
        + (
            "fasam.change_sensor",
            "fasam.change_actuator",
            "fasam.add_configauditlog",
            "fasam.view_configauditlog",
        ),
    ),
)


def user_in_group(user, group_name: str) -> bool:
    """Return whether a Django user is a member of a named FASAM group."""

    return bool(user and user.is_authenticated and user.groups.filter(name=group_name).exists())


def can_view_monitoring(user) -> bool:
    """Allow monitoring views to authenticated staff/operators or model viewers."""

    return bool(
        user
        and user.is_authenticated
        and (user.is_staff or user.has_perm("fasam.view_alarm") or user_in_group(user, FASAM_OPERATOR_GROUP))
    )


def can_perform_operator_action(user) -> bool:
    """Authorize acknowledgement, manual notification, and response actions."""

    return bool(user and user.is_authenticated and (user.is_staff or user.has_perm(OPERATOR_ACTION_PERMISSION)))


def can_issue_control_command(user) -> bool:
    """Authorize actuator and zone isolation commands."""

    return bool(user and user.is_authenticated and (user.is_staff or user.has_perm(CONTROL_COMMAND_PERMISSION)))


def can_manage_configuration(user) -> bool:
    """Authorize zone, rule, actuator, escalation, and permission configuration."""

    return bool(user and user.is_authenticated and (user.is_staff or user.has_perm(CONFIGURATION_PERMISSION)))


def auth_status_payload(user) -> dict:
    """Summarize authentication and authorization state for status endpoints."""

    group_names = []
    if user and user.is_authenticated:
        group_names = list(user.groups.order_by("name").values_list("name", flat=True))

    return {
        "is_authenticated": bool(user and user.is_authenticated),
        "username": user.get_username() if user and user.is_authenticated else "",
        "groups": group_names,
        "can_view_monitoring": can_view_monitoring(user),
        "can_perform_operator_action": can_perform_operator_action(user),
        "can_issue_control_command": can_issue_control_command(user),
        "can_manage_configuration": can_manage_configuration(user),
        "configuration_permission": CONFIGURATION_PERMISSION,
        "login_url": "/admin/login/",
    }
