"""WSGI config for the FASAM local prototype."""
import os

from django.core.wsgi import get_wsgi_application


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "fasam_project.settings")

application = get_wsgi_application()
