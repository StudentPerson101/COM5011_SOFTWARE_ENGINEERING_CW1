"""Service-layer package for FASAM business logic."""
