param(
    [string]$ProjectRoot = $PSScriptRoot
)

$ErrorActionPreference = "Stop"

$resolvedRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$targetPath = Join-Path -Path $resolvedRoot -ChildPath "start_server.bat"

if (-not (Test-Path -LiteralPath $targetPath)) {
    throw "Could not find start_server.bat at $targetPath"
}

$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path -Path $desktopPath -ChildPath "FASAM Prototype Server.lnk"

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $targetPath
$shortcut.WorkingDirectory = $resolvedRoot
$shortcut.WindowStyle = 1
$shortcut.Description = "Start the FASAM prototype server"
$shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,220"
$shortcut.Save()

Write-Host "Desktop shortcut created:"
Write-Host $shortcutPath
