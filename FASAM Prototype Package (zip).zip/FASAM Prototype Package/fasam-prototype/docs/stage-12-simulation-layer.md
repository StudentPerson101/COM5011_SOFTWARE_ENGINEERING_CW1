# Stage 12 Simulation Layer

This stage adds prototype-only simulation controls. It does not connect to real sensors, emergency services, sprinklers, door locks, electrical shutdown equipment, or external APIs.

## Entry Points

```text
/simulation/
/simulation/action/
```

The simulation page requires an authenticated staff/configuration user, matching the Stage 12 requirement that normal viewers should not trigger simulated alarms or hardware responses.

## Simulation Service

Core simulation behavior is implemented in:

```text
fasam/services/simulation.py
```

The service can:

- Load reusable demo building data, zones, rooms, simulated sensors, actuators, doors, policies, control area, and external service placeholders.
- Trigger single or multiple fire sensors through `record_sensor_activation`.
- Trigger single or combined security sensors through `record_sensor_activation`.
- Set occupancy readings to people detected, clear, or unknown.
- Run scenario presets for confirmed fire, unmanned escalation, security containment, false fire alarm, and unknown occupancy safety review.
- Simulate manual notification send/failure/retry/acknowledgement.
- Issue simulated actuator commands using the existing actuator service.
- Reset selected incidents, selected zones, all active alarms/actuators/doors, or clear event history when explicitly requested.

## Design Boundary

Simulation controls call the same services used by the operational views:

```text
simulation form -> simulation service -> alarm/actuator/escalation/event services -> Django models/templates
```

They do not directly edit dashboard cards or bypass rule evaluation. Event rows are written with `source_system="FASAM_SIMULATION"` when the action itself is part of the simulation layer.

## Scenario Presets

Implemented presets:

- `confirmed_fire_people`
- `confirmed_fire_unmanned`
- `security_intrusion`
- `false_fire_alarm`
- `unknown_occupancy_fire`

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from fasam.services.simulation import ensure_demo_data, run_scenario, reset_all_simulation; from fasam.models import Alarm; print(ensure_demo_data().success); print(run_scenario('confirmed_fire_people').success); print(run_scenario('security_intrusion').success); print(Alarm.objects.filter(status__in=['SUSPECTED','CONFIRMED']).count()); print(reset_all_simulation().success)"
```
