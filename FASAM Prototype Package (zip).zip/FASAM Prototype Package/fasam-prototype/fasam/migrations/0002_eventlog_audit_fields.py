from django.db import migrations, models


EVENT_LABELS = {
    "SENSOR_ACTIVATED": "Sensor activated",
    "ALARM_CREATED": "Alarm created",
    "ALARM_CONFIRMED": "Alarm confirmed",
    "CONTROL_AREA_ALERTED": "Control area alerted",
    "SERVICE_NOTIFIED": "Service notified",
    "ACTUATOR_COMMAND_ISSUED": "Actuator command issued",
    "OCCUPANCY_CHECKED": "Occupancy checked",
    "SYSTEM_RESET": "System reset",
    "CONFIG_CHANGED": "Config changed",
    "OPERATOR_ACTION": "Operator action",
}


def backfill_event_audit_fields(apps, schema_editor):
    EventLog = apps.get_model("fasam", "EventLog")
    for log in EventLog.objects.select_related("operator").all():
        details = (log.event_details or "").lower()
        if "blocked" in details:
            result = "Blocked"
        elif "failed" in details or "failure" in details or "rejected" in details:
            result = "Failed"
        elif "pending" in details:
            result = "Pending"
        elif "reset" in details or "restored" in details or "cleared" in details:
            result = "Completed"
        else:
            result = "Recorded"
        actor_type = "OPERATOR" if log.operator_id else "SIMULATION" if "SIMULATION" in (log.source_system or "").upper() else "SYSTEM"
        log.action_label = EVENT_LABELS.get(log.event_type, log.event_type.replace("_", " ").title())
        log.actor_type = actor_type
        log.result = result
        log.save(update_fields=["action_label", "actor_type", "result"])


class Migration(migrations.Migration):

    dependencies = [
        ("fasam", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="eventlog",
            name="action_label",
            field=models.CharField(blank=True, max_length=150),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="actor_type",
            field=models.CharField(
                choices=[("SYSTEM", "System"), ("OPERATOR", "Operator"), ("SIMULATION", "Simulation")],
                default="SYSTEM",
                max_length=30,
            ),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="control_area_status",
            field=models.CharField(
                blank=True,
                choices=[("MANNED", "Manned"), ("UNMANNED", "Unmanned")],
                max_length=30,
            ),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="event_payload",
            field=models.JSONField(blank=True, default=dict),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="occupancy_status",
            field=models.CharField(blank=True, max_length=80),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="reason",
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name="eventlog",
            name="result",
            field=models.CharField(blank=True, max_length=80),
        ),
        migrations.RunPython(backfill_event_audit_fields, migrations.RunPython.noop),
        migrations.AddIndex(
            model_name="eventlog",
            index=models.Index(fields=["actor_type"], name="fasam_event_actor_t_3e0a54_idx"),
        ),
        migrations.AddIndex(
            model_name="eventlog",
            index=models.Index(fields=["result"], name="fasam_event_result_3a0602_idx"),
        ),
    ]
