"""State management helpers for the FASAM server-rendered prototype."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from django.db.models import Q
from django.urls import reverse
from django.utils import timezone

from .forms import DashboardStateForm, EventLogStateForm, ZoneStateForm
from .models import (
    ActuatorKind,
    Alarm,
    AlarmStatus,
    AlarmType,
    ControlArea,
    ControlAreaStatusLog,
    DoorLockState,
    EventLog,
    EventType,
    NotificationStatus,
    Operator,
    StaffingStatus,
    Zone,
)
from .services.actuator_service import latest_occupancy_decision
from .services.contracts import ServiceResult
from .services.event_logger import log_event


ACTIVE_ALARM_STATUSES = (AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED)
TERMINAL_ALARM_STATUSES = (AlarmStatus.FALSE_ALARM, AlarmStatus.RESOLVED)

DASHBOARD_STATE_KEY = "fasam.dashboard_state"
ZONE_STATE_KEY = "fasam.zone_state"
LOG_STATE_KEY = "fasam.log_state"


@dataclass(frozen=True)
class RequestState:
    """Validated GET/session state for one page."""

    form: object
    values: dict
    source: str


def _request_has_state(request) -> bool:
    ignored = {"csrfmiddlewaretoken"}
    return bool(set(request.GET.keys()) - ignored)


def _stored_state(request, key: str) -> dict:
    value = request.session.get(key, {})
    return value if isinstance(value, dict) else {}


def _persist_state(request, key: str, values: dict) -> None:
    compact = {name: value for name, value in values.items() if value not in ("", None, [], ())}
    if compact:
        request.session[key] = compact
    else:
        request.session.pop(key, None)
    request.session.modified = True


def _state_from_request(request, key: str, form_class, **form_kwargs) -> RequestState:
    if request.GET.get("clear_state"):
        request.session.pop(key, None)
        request.session.modified = True
        form = form_class(**form_kwargs)
        return RequestState(form=form, values={}, source="cleared")

    if _request_has_state(request):
        submitted = request.GET.dict()
        values = _stored_state(request, key)
        values.update(submitted)
        form = form_class(values, **form_kwargs)
        if form.is_valid():
            cleaned_values = dict(form.cleaned_data)
            _persist_state(request, key, cleaned_values)
            return RequestState(form=form, values=cleaned_values, source="query")
        return RequestState(form=form, values={}, source="invalid")

    values = _stored_state(request, key)
    form = form_class(values or None, **form_kwargs)
    if form.is_valid():
        return RequestState(form=form, values=dict(form.cleaned_data), source="session" if values else "default")
    return RequestState(form=form_class(**form_kwargs), values={}, source="default")


def dashboard_request_state(request, zones: Iterable[Zone]) -> RequestState:
    return _state_from_request(request, DASHBOARD_STATE_KEY, DashboardStateForm, zones=zones)


def zone_request_state(request, zones: Iterable[Zone]) -> RequestState:
    return _state_from_request(request, ZONE_STATE_KEY, ZoneStateForm, zones=zones)


def event_log_request_state(request, zones: Iterable[Zone]) -> RequestState:
    operators = Operator.objects.filter(event_logs__isnull=False).distinct().order_by("username")
    return _state_from_request(request, LOG_STATE_KEY, EventLogStateForm, zones=zones, operators=operators)


def _alarm_pk_from_reference(value: str) -> int | None:
    normalized = (value or "").upper().strip()
    if normalized.startswith("A-"):
        normalized = normalized[2:]
    return int(normalized) if normalized.isdigit() else None


def apply_dashboard_state(queryset, values: dict):
    q = (values.get("q") or "").strip()
    if q:
        query = Q(zone__zone_code__icontains=q) | Q(zone__zone_name__icontains=q) | Q(room__room_code__icontains=q)
        alarm_pk = _alarm_pk_from_reference(q)
        if alarm_pk is not None:
            query |= Q(pk=alarm_pk)
        queryset = queryset.filter(query)

    if values.get("alarm_type"):
        queryset = queryset.filter(alarm_type=values["alarm_type"])
    if values.get("severity"):
        queryset = queryset.filter(severity=values["severity"])
    if values.get("status"):
        queryset = queryset.filter(status=values["status"])
    if values.get("zone"):
        queryset = queryset.filter(zone_id=values["zone"])
    return queryset


def apply_event_log_state(queryset, values: dict):
    q = (values.get("q") or "").strip()
    if q:
        queryset = queryset.filter(
            Q(event_details__icontains=q)
            | Q(source_system__icontains=q)
            | Q(alarm__zone__zone_code__icontains=q)
            | Q(alarm__zone__zone_name__icontains=q)
        )
    if values.get("alarm"):
        queryset = queryset.filter(alarm_id=values["alarm"])
    if values.get("zone"):
        queryset = queryset.filter(alarm__zone_id=values["zone"])
    if values.get("alarm_type"):
        queryset = queryset.filter(alarm__alarm_type=values["alarm_type"])
    if values.get("event_type"):
        queryset = queryset.filter(event_type=values["event_type"])
    if values.get("occurred_on"):
        queryset = queryset.filter(event_time__date=values["occurred_on"])
    if values.get("operator"):
        queryset = queryset.filter(operator_id=values["operator"])
    if values.get("actor_type"):
        queryset = queryset.filter(actor_type=values["actor_type"])
    return queryset


def apply_zone_state(summaries: list[dict], values: dict) -> list[dict]:
    q = (values.get("q") or "").strip().lower()
    status = values.get("status")
    alarm_type = values.get("alarm_type")
    occupancy = values.get("occupancy")
    device_state = values.get("device_state")

    filtered = []
    for summary in summaries:
        zone = summary["object"]
        latest_alarm = summary.get("latest_alarm")
        if q and q not in zone.zone_code.lower() and q not in zone.zone_name.lower():
            continue
        if alarm_type and (latest_alarm is None or latest_alarm.alarm_type != alarm_type):
            continue
        if status == "normal" and latest_alarm is not None:
            continue
        if status == "fire" and (latest_alarm is None or latest_alarm.alarm_type != AlarmType.FIRE):
            continue
        if status == "security" and (latest_alarm is None or latest_alarm.alarm_type != AlarmType.SECURITY):
            continue
        if status == "watch" and (latest_alarm is None or latest_alarm.status != AlarmStatus.SUSPECTED):
            continue
        if occupancy == "people" and not summary["people_detected"]:
            continue
        if occupancy == "clear" and summary["people_detected"]:
            continue
        if device_state == "active" and not summary["active_actuators"]:
            continue
        if device_state == "locked" and not summary["locked_doors"]:
            continue
        if device_state == "clear" and (summary["active_actuators"] or summary["locked_doors"]):
            continue
        filtered.append(summary)
    return filtered


def selected_zone_from_state(zones: list[Zone], values: dict) -> Zone | None:
    zone_id = values.get("zone")
    if zone_id:
        for zone in zones:
            if str(zone.pk) == str(zone_id):
                return zone
    return zones[0] if zones else None


def application_state_snapshot() -> dict:
    control_area = ControlArea.objects.order_by("name").first()
    active_alarms = Alarm.objects.filter(status__in=ACTIVE_ALARM_STATUSES)
    return {
        "generated_at": timezone.now(),
        "control_area": control_area,
        "control_area_status": control_area.get_current_staffing_status_display() if control_area else "Unconfigured",
        "active_alarm_count": active_alarms.count(),
        "suspected_alarm_count": active_alarms.filter(status=AlarmStatus.SUSPECTED).count(),
        "confirmed_alarm_count": active_alarms.filter(status=AlarmStatus.CONFIRMED).count(),
        "fire_alarm_count": active_alarms.filter(alarm_type=AlarmType.FIRE).count(),
        "security_alarm_count": active_alarms.filter(alarm_type=AlarmType.SECURITY).count(),
        "notification_pending_count": active_alarms.exclude(notifications__notification_status=NotificationStatus.SENT)
        .distinct()
        .count(),
        "zone_count": Zone.objects.filter(is_active=True).count(),
    }


def alarm_reference(alarm: Alarm | None) -> str:
    return "" if alarm is None or alarm.pk is None else f"A-{alarm.pk:04d}"


def alarm_detail_url(alarm: Alarm) -> str:
    route = "fasam:fire_incident_detail" if alarm.alarm_type == AlarmType.FIRE else "fasam:security_incident_detail"
    return reverse(route, args=[alarm_reference(alarm)])


def alarm_response_state(alarm: Alarm) -> dict:
    occupancy = latest_occupancy_decision(alarm.room)
    has_notification = alarm.notifications.filter(notification_status=NotificationStatus.SENT).exists()
    exit_active = alarm.actuator_commands.filter(actuator__actuator_type__type_code=ActuatorKind.EXIT_INDICATOR).exists()
    audible_active = alarm.actuator_commands.filter(actuator__actuator_type__type_code=ActuatorKind.AUDIBLE_ALARM).exists()

    return {
        "occupancy": occupancy,
        "has_service_notification": has_notification,
        "response_steps": [
            {
                "label": "Evacuation indicators activated",
                "status": "Completed" if exit_active else "Pending",
                "badge": "text-bg-success" if exit_active else "text-bg-secondary",
            },
            {
                "label": "Audible evacuation alarm activated",
                "status": "Completed" if audible_active else "Pending",
                "badge": "text-bg-success" if audible_active else "text-bg-secondary",
            },
            {
                "label": "Sprinkler activation",
                "status": "Blocked" if occupancy.people_detected else "Available",
                "badge": "text-bg-warning" if occupancy.people_detected else "text-bg-secondary",
                "detail": occupancy.reason if occupancy.people_detected else "",
            },
            {
                "label": "Electrical shutdown",
                "status": "Blocked" if occupancy.people_detected else "Available",
                "badge": "text-bg-warning" if occupancy.people_detected else "text-bg-secondary",
                "detail": occupancy.reason if occupancy.people_detected else "",
            },
            {
                "label": "Fire services notification",
                "status": "Completed" if has_notification else "Pending",
                "badge": "text-bg-success" if has_notification else "text-bg-secondary",
            },
        ],
    }


def security_response_state(alarm: Alarm) -> dict:
    return {
        "locked_doors": alarm.zone.doors.filter(current_lock_state=DoorLockState.LOCKED),
        "active_isolation": alarm.zone_isolations.filter(isolation_status="ACTIVE").first(),
        "security_notification_sent": alarm.notifications.filter(
            service__service_type="SECURITY_SERVICES",
            notification_status=NotificationStatus.SENT,
        ).exists(),
    }


def transition_control_area_state(control_area: ControlArea | None, staffing_status: str, operator: Operator | None):
    if control_area is None:
        return ServiceResult.failed("No control area is configured.")
    if staffing_status not in StaffingStatus.values:
        return ServiceResult.failed("Unsupported staffing status.")

    if control_area.current_staffing_status == staffing_status:
        return ServiceResult.ok("Control area state was already current.", control_area=control_area, changed=False)

    control_area.current_staffing_status = staffing_status
    control_area.last_status_update = timezone.now()
    control_area.save(update_fields=["current_staffing_status", "last_status_update"])
    ControlAreaStatusLog.objects.create(
        control_area=control_area,
        staffing_status=staffing_status,
        changed_by_operator=operator,
        note="Changed from the integrated control-area header.",
    )
    log_event(
        EventType.OPERATOR_ACTION,
        operator=operator,
        details=f"Control area staffing state changed to {staffing_status}.",
    )
    return ServiceResult.ok("Control area state updated.", control_area=control_area, changed=True)
