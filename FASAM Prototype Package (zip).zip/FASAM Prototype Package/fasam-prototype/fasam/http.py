"""Small HTTP helpers for backend framework views."""
from django.http import JsonResponse


def ok_response(payload=None, *, status=200):
    """Return a consistent JSON success response."""
    return JsonResponse({"ok": True, "data": payload or {}}, status=status)


def error_response(message, *, status=400, code="bad_request"):
    """Return a consistent JSON error response."""
    return JsonResponse(
        {"ok": False, "error": {"code": code, "message": message}},
        status=status,
    )
