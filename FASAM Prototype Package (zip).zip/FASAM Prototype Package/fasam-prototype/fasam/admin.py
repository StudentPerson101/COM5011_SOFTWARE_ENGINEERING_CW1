"""Admin registration for FASAM data model inspection."""
from django.contrib import admin

from . import models


FASAM_MODELS = [
    models.Building,
    models.Zone,
    models.Room,
    models.SensorType,
    models.Sensor,
    models.OccupancyReading,
    models.AlarmPolicy,
    models.ResponseRule,
    models.Alarm,
    models.AlarmSensorEvidence,
    models.Operator,
    models.AlarmConfirmation,
    models.ControlArea,
    models.ControlAreaStatusLog,
    models.OperatorAction,
    models.ActuatorType,
    models.Actuator,
    models.ActuatorCommand,
    models.Door,
    models.ZoneIsolation,
    models.ExternalService,
    models.Notification,
    models.EventLog,
    models.ConfigAuditLog,
]


for model in FASAM_MODELS:
    admin.site.register(model)
