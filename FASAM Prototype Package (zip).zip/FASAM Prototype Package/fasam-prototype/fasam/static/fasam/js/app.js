(function () {
  "use strict";

  document.querySelectorAll("[data-disable-on-click]").forEach(function (button) {
    button.addEventListener("click", function () {
      button.setAttribute("disabled", "disabled");
    });
  });
})();
