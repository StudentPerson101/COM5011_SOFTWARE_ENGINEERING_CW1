"""Alarm correlation, confirmation, and response orchestration rules."""
from __future__ import annotations

from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from fasam.models import (
    Alarm,
    AlarmConfirmation,
    AlarmPolicy,
    AlarmSensorEvidence,
    AlarmStatus,
    AlarmType,
    ConfirmationMethod,
    ConfirmationStatus,
    EventType,
    SensorCategory,
    SensorStatus,
    Severity,
)

from .contracts import ServiceResult
from .event_logger import log_event


SEVERITY_RANK = {
    Severity.LOW: 1,
    Severity.MEDIUM: 2,
    Severity.HIGH: 3,
    Severity.CRITICAL: 4,
}


def get_alarm_policy(zone, alarm_type: str) -> AlarmPolicy | None:
    """Fetch the active confirmation/response policy for a zone and alarm type."""

    return (
        AlarmPolicy.objects.filter(zone=zone, alarm_type=alarm_type, is_active=True)
        .order_by("pk")
        .first()
    )


def _alarm_type_for_sensor(sensor) -> str | None:
    category = sensor.sensor_type.category
    if category == SensorCategory.FIRE:
        return AlarmType.FIRE
    if category == SensorCategory.SECURITY:
        return AlarmType.SECURITY
    return None


def _default_min_sensor_count(alarm_type: str) -> int:
    return 2 if alarm_type in (AlarmType.FIRE, AlarmType.SECURITY) else 1


def _recommended_action(alarm_type: str, confirmed: bool) -> str:
    if alarm_type == AlarmType.FIRE:
        if confirmed:
            return "Evacuate, activate indicators/audible alarms, and notify fire services as required."
        return "Await further fire sensor confirmation."
    if confirmed:
        return "Lock internal doors, isolate affected zone, and notify security services as required."
    return "Await further security sensor confirmation."


def _highest_severity(current: str, incoming: str) -> str:
    return incoming if SEVERITY_RANK.get(incoming, 0) > SEVERITY_RANK.get(current, 0) else current


def _confirmation_settings(alarm):
    policy = alarm.policy
    if policy is None:
        return {
            "required": True,
            "min_sensor_count": _default_min_sensor_count(alarm.alarm_type),
            "window_seconds": 60,
        }

    return {
        "required": policy.confirmation_required,
        "min_sensor_count": policy.min_sensor_count,
        "window_seconds": policy.confirmation_window_seconds,
    }


def _active_alarm_for(sensor, alarm_type: str):
    queryset = Alarm.objects.filter(
        zone=sensor.zone,
        room=sensor.room,
        alarm_type=alarm_type,
        status__in=[AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED],
    ).order_by("-first_detected_at")
    return queryset.first()


def _evidence_count_in_window(alarm, window_seconds: int) -> int:
    window_start = timezone.now() - timedelta(seconds=window_seconds)
    return (
        alarm.sensor_evidence.filter(activation_time__gte=window_start)
        .values("sensor_id")
        .distinct()
        .count()
    )


def _record_confirmation(alarm, sensor_count: int, method: str, note: str = ""):
    return AlarmConfirmation.objects.create(
        alarm=alarm,
        policy=alarm.policy,
        sensor_count_used=max(sensor_count, 1),
        confirmation_method=method,
        decision_note=note,
    )


@transaction.atomic
def record_sensor_activation(
    sensor,
    *,
    reading_value: str = "",
    evidence_note: str = "",
    severity: str = Severity.LOW,
    created_by: str = "SYSTEM",
) -> ServiceResult:
    """Create/update an alarm from an activated fire or security sensor."""

    if severity not in Severity.values:
        return ServiceResult.failed("Unsupported alarm severity.", sensor=sensor)
    if sensor.room_id and sensor.room.zone_id != sensor.zone_id:
        return ServiceResult.failed("Sensor room and zone configuration is inconsistent.", sensor=sensor)
    if sensor.status != SensorStatus.ACTIVE:
        return ServiceResult.failed("Inactive, faulty, or maintenance sensors do not create alarms.", sensor=sensor)

    alarm_type = _alarm_type_for_sensor(sensor)
    if alarm_type is None:
        return ServiceResult.failed("Occupancy sensors are evaluated by occupancy checks, not alarm creation.", sensor=sensor)

    policy = get_alarm_policy(sensor.zone, alarm_type)
    alarm = _active_alarm_for(sensor, alarm_type)
    created = False

    if alarm is None:
        alarm = Alarm.objects.create(
            zone=sensor.zone,
            room=sensor.room,
            policy=policy,
            alarm_type=alarm_type,
            severity=severity,
            confirmation_status=ConfirmationStatus.PENDING,
            recommended_action=_recommended_action(alarm_type, confirmed=False),
            created_by=created_by,
        )
        created = True
        log_event(EventType.ALARM_CREATED, alarm=alarm, sensor=sensor, details=f"{alarm_type} alarm created.")
        log_event(EventType.CONTROL_AREA_ALERTED, alarm=alarm, sensor=sensor, details="Control area alerted.")
    else:
        next_severity = _highest_severity(alarm.severity, severity)
        if next_severity != alarm.severity:
            alarm.severity = next_severity
            alarm.save(update_fields=["severity"])

    evidence = AlarmSensorEvidence.objects.create(
        alarm=alarm,
        sensor=sensor,
        reading_value=reading_value,
        evidence_note=evidence_note,
    )
    log_event(
        EventType.SENSOR_ACTIVATED,
        alarm=alarm,
        sensor=sensor,
        details=evidence_note or f"{sensor.device_code} activated.",
    )

    confirmation = evaluate_alarm_confirmation(alarm)
    return ServiceResult.ok(
        "Sensor activation recorded.",
        alarm=alarm,
        evidence=evidence,
        alarm_created=created,
        confirmation=confirmation,
    )


@transaction.atomic
def evaluate_alarm_confirmation(alarm) -> ServiceResult:
    """Evaluate whether an alarm meets its confirmation rule."""

    settings = _confirmation_settings(alarm)
    if not settings["required"]:
        alarm.status = AlarmStatus.CONFIRMED
        alarm.confirmation_status = ConfirmationStatus.NOT_REQUIRED
        alarm.confirmed_at = alarm.confirmed_at or timezone.now()
        alarm.recommended_action = _recommended_action(alarm.alarm_type, confirmed=True)
        alarm.save(update_fields=["status", "confirmation_status", "confirmed_at", "recommended_action"])
        _record_confirmation(alarm, 1, ConfirmationMethod.AUTO_CONFIRMED, "Confirmation not required by policy.")
        log_event(EventType.ALARM_CONFIRMED, alarm=alarm, details="Alarm auto-confirmed by policy.")
        handle_confirmed_alarm(alarm)
        return ServiceResult.ok("Alarm auto-confirmed.", alarm=alarm, confirmed=True)

    sensor_count = _evidence_count_in_window(alarm, settings["window_seconds"])
    if sensor_count < settings["min_sensor_count"]:
        if alarm.status != AlarmStatus.SUSPECTED or alarm.confirmation_status != ConfirmationStatus.PENDING:
            alarm.status = AlarmStatus.SUSPECTED
            alarm.confirmation_status = ConfirmationStatus.PENDING
            alarm.recommended_action = _recommended_action(alarm.alarm_type, confirmed=False)
            alarm.save(update_fields=["status", "confirmation_status", "recommended_action"])
        return ServiceResult.ok(
            "Alarm remains suspected pending more sensor evidence.",
            alarm=alarm,
            confirmed=False,
            sensor_count=sensor_count,
            required_sensor_count=settings["min_sensor_count"],
        )

    if alarm.status == AlarmStatus.CONFIRMED and alarm.confirmation_status == ConfirmationStatus.CONFIRMED:
        return ServiceResult.ok("Alarm already confirmed.", alarm=alarm, confirmed=True, sensor_count=sensor_count)

    method = ConfirmationMethod.MULTI_SENSOR if sensor_count > 1 else ConfirmationMethod.SINGLE_SENSOR
    alarm.status = AlarmStatus.CONFIRMED
    alarm.confirmation_status = ConfirmationStatus.CONFIRMED
    alarm.confirmed_at = timezone.now()
    alarm.recommended_action = _recommended_action(alarm.alarm_type, confirmed=True)
    alarm.save(update_fields=["status", "confirmation_status", "confirmed_at", "recommended_action"])
    _record_confirmation(
        alarm,
        sensor_count,
        method,
        f"{sensor_count} sensor(s) matched in the confirmation window.",
    )
    log_event(
        EventType.ALARM_CONFIRMED,
        alarm=alarm,
        details=f"{alarm.alarm_type} alarm confirmed with {sensor_count} sensor(s).",
    )
    handle_confirmed_alarm(alarm)
    return ServiceResult.ok("Alarm confirmed.", alarm=alarm, confirmed=True, sensor_count=sensor_count)


def handle_confirmed_alarm(alarm) -> ServiceResult:
    """Run the configured automatic response for a confirmed alarm."""

    if alarm.status != AlarmStatus.CONFIRMED:
        return ServiceResult.failed("Automatic response requires a confirmed alarm.", alarm=alarm)

    from .actuator_service import activate_fire_response, isolate_zone
    from .escalation_service import auto_escalate_if_required

    if alarm.alarm_type == AlarmType.FIRE:
        response = activate_fire_response(alarm)
    else:
        response = isolate_zone(alarm)

    escalation = auto_escalate_if_required(alarm)
    return ServiceResult.ok(
        "Confirmed alarm response evaluated.",
        alarm=alarm,
        response=response,
        escalation=escalation,
    )
