"""Django data model for the FASAM prototype."""
from django.db import models
from django.db.models import F, Q
from django.utils import timezone


class AlarmType(models.TextChoices):
    FIRE = "FIRE", "Fire"
    SECURITY = "SECURITY", "Security"


class AlarmStatus(models.TextChoices):
    SUSPECTED = "SUSPECTED", "Suspected"
    CONFIRMED = "CONFIRMED", "Confirmed"
    FALSE_ALARM = "FALSE_ALARM", "False alarm"
    RESOLVED = "RESOLVED", "Resolved"


class ConfirmationStatus(models.TextChoices):
    NOT_REQUIRED = "NOT_REQUIRED", "Not required"
    PENDING = "PENDING", "Pending"
    CONFIRMED = "CONFIRMED", "Confirmed"
    REJECTED = "REJECTED", "Rejected"


class Severity(models.TextChoices):
    LOW = "LOW", "Low"
    MEDIUM = "MEDIUM", "Medium"
    HIGH = "HIGH", "High"
    CRITICAL = "CRITICAL", "Critical"


class SensorCategory(models.TextChoices):
    FIRE = "FIRE", "Fire"
    SECURITY = "SECURITY", "Security"
    OCCUPANCY = "OCCUPANCY", "Occupancy"


class SensorStatus(models.TextChoices):
    ACTIVE = "ACTIVE", "Active"
    INACTIVE = "INACTIVE", "Inactive"
    FAULT = "FAULT", "Fault"
    MAINTENANCE = "MAINTENANCE", "Maintenance"


class StaffingStatus(models.TextChoices):
    MANNED = "MANNED", "Manned"
    UNMANNED = "UNMANNED", "Unmanned"


class OperatorRole(models.TextChoices):
    OPERATOR = "OPERATOR", "Operator"
    SUPERVISOR = "SUPERVISOR", "Supervisor"
    ADMIN = "ADMIN", "Admin"
    MAINTENANCE = "MAINTENANCE", "Maintenance"


class OperatorActionType(models.TextChoices):
    ACKNOWLEDGE_ALARM = "ACKNOWLEDGE_ALARM", "Acknowledge alarm"
    VIEW_AFFECTED_ZONE = "VIEW_AFFECTED_ZONE", "View affected zone"
    VIEW_CONFIRMATION_STATUS = "VIEW_CONFIRMATION_STATUS", "View confirmation status"
    CHECK_HUMAN_PRESENCE = "CHECK_HUMAN_PRESENCE", "Check human presence"
    CONFIRM_FIRE_ALARM = "CONFIRM_FIRE_ALARM", "Confirm fire alarm"
    CONFIRM_SECURITY_ALARM = "CONFIRM_SECURITY_ALARM", "Confirm security alarm"
    CONTACT_FIRE_SERVICES = "CONTACT_FIRE_SERVICES", "Contact fire services"
    CONTACT_SECURITY_SERVICES = "CONTACT_SECURITY_SERVICES", "Contact security services"
    RESET_RESTORE_SYSTEM = "RESET_RESTORE_SYSTEM", "Reset / restore system"


class ActuatorKind(models.TextChoices):
    SPRINKLER = "SPRINKLER", "Sprinkler"
    ELECTRICAL_SHUTDOWN = "ELECTRICAL_SHUTDOWN", "Electrical shutdown"
    EXIT_INDICATOR = "EXIT_INDICATOR", "Exit indicator"
    AUDIBLE_ALARM = "AUDIBLE_ALARM", "Audible alarm"
    DOOR_LOCK = "DOOR_LOCK", "Door lock"


class ActuatorStatus(models.TextChoices):
    READY = "READY", "Ready"
    ACTIVE = "ACTIVE", "Active"
    INACTIVE = "INACTIVE", "Inactive"
    FAULT = "FAULT", "Fault"
    MAINTENANCE = "MAINTENANCE", "Maintenance"


class CommandType(models.TextChoices):
    ACTIVATE = "ACTIVATE", "Activate"
    DEACTIVATE = "DEACTIVATE", "Deactivate"
    LOCK = "LOCK", "Lock"
    UNLOCK = "UNLOCK", "Unlock"
    ISOLATE_ZONE = "ISOLATE_ZONE", "Isolate zone"
    RESET = "RESET", "Reset"


class CommandStatus(models.TextChoices):
    PENDING = "PENDING", "Pending"
    SENT = "SENT", "Sent"
    COMPLETED = "COMPLETED", "Completed"
    FAILED = "FAILED", "Failed"
    CANCELLED = "CANCELLED", "Cancelled"


class DoorLockState(models.TextChoices):
    LOCKED = "LOCKED", "Locked"
    UNLOCKED = "UNLOCKED", "Unlocked"
    FAULT = "FAULT", "Fault"


class IsolationStatus(models.TextChoices):
    ACTIVE = "ACTIVE", "Active"
    RELEASED = "RELEASED", "Released"
    FAILED = "FAILED", "Failed"


class ServiceType(models.TextChoices):
    FIRE_SERVICES = "FIRE_SERVICES", "Fire services"
    SECURITY_SERVICES = "SECURITY_SERVICES", "Security services"
    EMERGENCY_SERVICES = "EMERGENCY_SERVICES", "Emergency services"


class NotificationMode(models.TextChoices):
    AUTOMATIC = "AUTOMATIC", "Automatic"
    MANUAL = "MANUAL", "Manual"


class NotificationStatus(models.TextChoices):
    PENDING = "PENDING", "Pending"
    SENT = "SENT", "Sent"
    ACKNOWLEDGED = "ACKNOWLEDGED", "Acknowledged"
    FAILED = "FAILED", "Failed"


class ConfirmationMethod(models.TextChoices):
    SINGLE_SENSOR = "SINGLE_SENSOR", "Single sensor"
    MULTI_SENSOR = "MULTI_SENSOR", "Multi sensor"
    OPERATOR_CONFIRMED = "OPERATOR_CONFIRMED", "Operator confirmed"
    AUTO_CONFIRMED = "AUTO_CONFIRMED", "Auto confirmed"


class EventType(models.TextChoices):
    SENSOR_ACTIVATED = "SENSOR_ACTIVATED", "Sensor activated"
    ALARM_CREATED = "ALARM_CREATED", "Alarm created"
    ALARM_CONFIRMED = "ALARM_CONFIRMED", "Alarm confirmed"
    CONTROL_AREA_ALERTED = "CONTROL_AREA_ALERTED", "Control area alerted"
    SERVICE_NOTIFIED = "SERVICE_NOTIFIED", "Service notified"
    ACTUATOR_COMMAND_ISSUED = "ACTUATOR_COMMAND_ISSUED", "Actuator command issued"
    OCCUPANCY_CHECKED = "OCCUPANCY_CHECKED", "Occupancy checked"
    SYSTEM_RESET = "SYSTEM_RESET", "System reset"
    CONFIG_CHANGED = "CONFIG_CHANGED", "Config changed"
    OPERATOR_ACTION = "OPERATOR_ACTION", "Operator action"


class EventActorType(models.TextChoices):
    SYSTEM = "SYSTEM", "System"
    OPERATOR = "OPERATOR", "Operator"
    SIMULATION = "SIMULATION", "Simulation"


class ConfigChangeType(models.TextChoices):
    INSERT = "INSERT", "Insert"
    UPDATE = "UPDATE", "Update"
    DELETE = "DELETE", "Delete"


class Building(models.Model):
    name = models.CharField(max_length=150)
    address = models.TextField(blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Zone(models.Model):
    building = models.ForeignKey(Building, on_delete=models.CASCADE, related_name="zones")
    zone_code = models.CharField(max_length=50, unique=True)
    zone_name = models.CharField(max_length=150)
    floor_no = models.IntegerField(null=True, blank=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["zone_code"]
        indexes = [models.Index(fields=["building"])]

    def __str__(self):
        return f"{self.zone_code} / {self.zone_name}"


class Room(models.Model):
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="rooms")
    room_code = models.CharField(max_length=50, unique=True)
    room_name = models.CharField(max_length=150, blank=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["room_code"]
        indexes = [models.Index(fields=["zone"])]

    def __str__(self):
        return self.room_code if not self.room_name else f"{self.room_code} / {self.room_name}"


class SensorType(models.Model):
    type_code = models.CharField(max_length=50, unique=True)
    category = models.CharField(max_length=30, choices=SensorCategory.choices)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["type_code"]

    def __str__(self):
        return self.type_code


class Sensor(models.Model):
    sensor_type = models.ForeignKey(SensorType, on_delete=models.PROTECT, related_name="sensors")
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="sensors")
    room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, blank=True, related_name="sensors")
    device_code = models.CharField(max_length=80, unique=True)
    location_description = models.TextField(blank=True)
    installed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=30, choices=SensorStatus.choices, default=SensorStatus.ACTIVE)
    last_seen_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["device_code"]
        indexes = [
            models.Index(fields=["zone"]),
            models.Index(fields=["room"]),
        ]

    def __str__(self):
        return self.device_code


class OccupancyReading(models.Model):
    sensor = models.ForeignKey(Sensor, on_delete=models.CASCADE, related_name="occupancy_readings")
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name="occupancy_readings")
    detected_people = models.BooleanField()
    confidence_score = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    reading_time = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-reading_time"]
        indexes = [models.Index(fields=["room", "-reading_time"])]
        constraints = [
            models.CheckConstraint(
                condition=Q(confidence_score__isnull=True)
                | (Q(confidence_score__gte=0) & Q(confidence_score__lte=100)),
                name="occupancy_confidence_between_0_and_100",
            )
        ]

    def __str__(self):
        return f"{self.room} at {self.reading_time:%Y-%m-%d %H:%M:%S}"


class AlarmPolicy(models.Model):
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="alarm_policies")
    alarm_type = models.CharField(max_length=30, choices=AlarmType.choices)
    confirmation_required = models.BooleanField(default=True)
    min_sensor_count = models.PositiveIntegerField(default=1)
    confirmation_window_seconds = models.PositiveIntegerField(default=60)
    serious_severity_threshold = models.CharField(max_length=30, choices=Severity.choices, default=Severity.HIGH)
    auto_notify_if_unmanned = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["zone__zone_code", "alarm_type"]
        constraints = [
            models.UniqueConstraint(fields=["zone", "alarm_type"], name="unique_alarm_policy_zone_type"),
            models.CheckConstraint(condition=Q(min_sensor_count__gte=1), name="alarm_policy_min_sensor_count_gte_1"),
            models.CheckConstraint(
                condition=Q(confirmation_window_seconds__gt=0),
                name="alarm_policy_window_seconds_gt_0",
            ),
        ]

    def __str__(self):
        return f"{self.zone} {self.alarm_type}"


class ResponseRule(models.Model):
    policy = models.ForeignKey(AlarmPolicy, on_delete=models.CASCADE, related_name="response_rules")
    rule_name = models.CharField(max_length=150)
    trigger_condition = models.TextField()
    target_actuator_type = models.CharField(max_length=50, choices=ActuatorKind.choices, blank=True)
    command_type = models.CharField(max_length=50, choices=CommandType.choices, blank=True)
    requires_no_occupancy = models.BooleanField(default=False)
    priority = models.IntegerField(default=100)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["priority", "rule_name"]

    def __str__(self):
        return self.rule_name


class Alarm(models.Model):
    zone = models.ForeignKey(Zone, on_delete=models.PROTECT, related_name="alarms")
    room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, blank=True, related_name="alarms")
    policy = models.ForeignKey(AlarmPolicy, on_delete=models.SET_NULL, null=True, blank=True, related_name="alarms")
    alarm_type = models.CharField(max_length=30, choices=AlarmType.choices)
    status = models.CharField(max_length=30, choices=AlarmStatus.choices, default=AlarmStatus.SUSPECTED)
    severity = models.CharField(max_length=30, choices=Severity.choices, default=Severity.LOW)
    confirmation_status = models.CharField(
        max_length=30,
        choices=ConfirmationStatus.choices,
        default=ConfirmationStatus.PENDING,
    )
    first_detected_at = models.DateTimeField(default=timezone.now)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    recommended_action = models.TextField(blank=True)
    created_by = models.CharField(max_length=80, default="SYSTEM")

    class Meta:
        ordering = ["-first_detected_at"]
        indexes = [
            models.Index(fields=["zone"]),
            models.Index(fields=["room"]),
            models.Index(fields=["alarm_type", "status"]),
            models.Index(fields=["first_detected_at"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=Q(resolved_at__isnull=True) | Q(resolved_at__gte=F("first_detected_at")),
                name="alarm_resolved_at_after_first_detected",
            ),
            models.CheckConstraint(
                condition=Q(confirmed_at__isnull=True) | Q(confirmed_at__gte=F("first_detected_at")),
                name="alarm_confirmed_at_after_first_detected",
            ),
        ]

    def __str__(self):
        return f"{self.alarm_type} alarm #{self.pk or 'new'}"


class AlarmSensorEvidence(models.Model):
    alarm = models.ForeignKey(Alarm, on_delete=models.CASCADE, related_name="sensor_evidence")
    sensor = models.ForeignKey(Sensor, on_delete=models.PROTECT, related_name="alarm_evidence")
    activation_time = models.DateTimeField(default=timezone.now)
    reading_value = models.TextField(blank=True)
    evidence_note = models.TextField(blank=True)

    class Meta:
        ordering = ["activation_time"]
        indexes = [
            models.Index(fields=["alarm"]),
            models.Index(fields=["sensor"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["alarm", "sensor", "activation_time"],
                name="unique_alarm_sensor_activation_time",
            )
        ]

    def __str__(self):
        return f"{self.sensor} evidence for {self.alarm}"


class Operator(models.Model):
    username = models.CharField(max_length=80, unique=True)
    full_name = models.CharField(max_length=150, blank=True)
    role = models.CharField(max_length=50, choices=OperatorRole.choices, default=OperatorRole.OPERATOR)
    is_authorized = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    last_login_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["username"]

    def __str__(self):
        return self.username


class AlarmConfirmation(models.Model):
    alarm = models.ForeignKey(Alarm, on_delete=models.CASCADE, related_name="confirmations")
    policy = models.ForeignKey(AlarmPolicy, on_delete=models.SET_NULL, null=True, blank=True, related_name="confirmations")
    sensor_count_used = models.PositiveIntegerField(default=1)
    confirmation_method = models.CharField(max_length=50, choices=ConfirmationMethod.choices)
    confirmed_by_operator = models.ForeignKey(
        Operator,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="alarm_confirmations",
    )
    confirmed_at = models.DateTimeField(default=timezone.now)
    decision_note = models.TextField(blank=True)

    class Meta:
        ordering = ["-confirmed_at"]
        constraints = [
            models.CheckConstraint(
                condition=Q(sensor_count_used__gte=1),
                name="alarm_confirmation_sensor_count_gte_1",
            )
        ]

    def __str__(self):
        return f"{self.confirmation_method} for {self.alarm}"


class ControlArea(models.Model):
    building = models.ForeignKey(Building, on_delete=models.CASCADE, related_name="control_areas")
    name = models.CharField(max_length=150)
    location_description = models.TextField(blank=True)
    current_staffing_status = models.CharField(
        max_length=30,
        choices=StaffingStatus.choices,
        default=StaffingStatus.UNMANNED,
    )
    last_status_update = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class ControlAreaStatusLog(models.Model):
    control_area = models.ForeignKey(ControlArea, on_delete=models.CASCADE, related_name="status_logs")
    staffing_status = models.CharField(max_length=30, choices=StaffingStatus.choices)
    changed_by_operator = models.ForeignKey(
        Operator,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="control_area_status_changes",
    )
    changed_at = models.DateTimeField(default=timezone.now)
    note = models.TextField(blank=True)

    class Meta:
        ordering = ["-changed_at"]

    def __str__(self):
        return f"{self.control_area} {self.staffing_status}"


class OperatorAction(models.Model):
    alarm = models.ForeignKey(Alarm, on_delete=models.CASCADE, related_name="operator_actions")
    operator = models.ForeignKey(Operator, on_delete=models.PROTECT, related_name="actions")
    action_type = models.CharField(max_length=80, choices=OperatorActionType.choices)
    action_time = models.DateTimeField(default=timezone.now)
    action_note = models.TextField(blank=True)

    class Meta:
        ordering = ["-action_time"]

    def __str__(self):
        return f"{self.operator} {self.action_type}"


class ActuatorType(models.Model):
    type_code = models.CharField(max_length=50, choices=ActuatorKind.choices, unique=True)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["type_code"]

    def __str__(self):
        return self.type_code


class Actuator(models.Model):
    actuator_type = models.ForeignKey(ActuatorType, on_delete=models.PROTECT, related_name="actuators")
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="actuators")
    room = models.ForeignKey(Room, on_delete=models.SET_NULL, null=True, blank=True, related_name="actuators")
    device_code = models.CharField(max_length=80, unique=True)
    location_description = models.TextField(blank=True)
    installed_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=30, choices=ActuatorStatus.choices, default=ActuatorStatus.READY)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["device_code"]
        indexes = [
            models.Index(fields=["zone"]),
            models.Index(fields=["room"]),
        ]

    def __str__(self):
        return self.device_code


class ActuatorCommand(models.Model):
    actuator = models.ForeignKey(Actuator, on_delete=models.PROTECT, related_name="commands")
    alarm = models.ForeignKey(Alarm, on_delete=models.SET_NULL, null=True, blank=True, related_name="actuator_commands")
    response_rule = models.ForeignKey(
        ResponseRule,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="actuator_commands",
    )
    issued_by_operator = models.ForeignKey(
        Operator,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="issued_actuator_commands",
    )
    command_type = models.CharField(max_length=50, choices=CommandType.choices)
    command_status = models.CharField(max_length=30, choices=CommandStatus.choices, default=CommandStatus.PENDING)
    issued_at = models.DateTimeField(default=timezone.now)
    completed_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.TextField(blank=True)

    class Meta:
        ordering = ["-issued_at"]
        indexes = [models.Index(fields=["alarm"])]
        constraints = [
            models.CheckConstraint(
                condition=Q(completed_at__isnull=True) | Q(completed_at__gte=F("issued_at")),
                name="actuator_command_completed_at_after_issued",
            )
        ]

    def __str__(self):
        return f"{self.command_type} {self.actuator}"


class Door(models.Model):
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="doors")
    actuator = models.OneToOneField(Actuator, on_delete=models.PROTECT, related_name="door")
    door_code = models.CharField(max_length=80, unique=True)
    door_name = models.CharField(max_length=150, blank=True)
    connects_zone = models.ForeignKey(
        Zone,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="connected_doors",
    )
    current_lock_state = models.CharField(
        max_length=30,
        choices=DoorLockState.choices,
        default=DoorLockState.UNLOCKED,
    )

    class Meta:
        ordering = ["door_code"]

    def __str__(self):
        return self.door_code


class ZoneIsolation(models.Model):
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="isolations")
    alarm = models.ForeignKey(Alarm, on_delete=models.CASCADE, related_name="zone_isolations")
    isolation_status = models.CharField(
        max_length=30,
        choices=IsolationStatus.choices,
        default=IsolationStatus.ACTIVE,
    )
    started_at = models.DateTimeField(default=timezone.now)
    ended_at = models.DateTimeField(null=True, blank=True)
    reason = models.TextField(blank=True)

    class Meta:
        ordering = ["-started_at"]
        constraints = [
            models.CheckConstraint(
                condition=Q(ended_at__isnull=True) | Q(ended_at__gte=F("started_at")),
                name="zone_isolation_ended_at_after_started",
            )
        ]

    def __str__(self):
        return f"{self.zone} {self.isolation_status}"


class ExternalService(models.Model):
    service_type = models.CharField(max_length=50, choices=ServiceType.choices)
    service_name = models.CharField(max_length=150)
    contact_endpoint = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["service_type", "service_name"]

    def __str__(self):
        return self.service_name


class Notification(models.Model):
    alarm = models.ForeignKey(Alarm, on_delete=models.CASCADE, related_name="notifications")
    service = models.ForeignKey(ExternalService, on_delete=models.PROTECT, related_name="notifications")
    initiated_by_operator = models.ForeignKey(
        Operator,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notifications",
    )
    notification_mode = models.CharField(max_length=30, choices=NotificationMode.choices)
    notification_status = models.CharField(
        max_length=30,
        choices=NotificationStatus.choices,
        default=NotificationStatus.PENDING,
    )
    sent_at = models.DateTimeField(default=timezone.now)
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    message_summary = models.TextField(blank=True)
    failure_reason = models.TextField(blank=True)

    class Meta:
        ordering = ["-sent_at"]
        indexes = [models.Index(fields=["alarm"])]
        constraints = [
            models.CheckConstraint(
                condition=Q(acknowledged_at__isnull=True) | Q(acknowledged_at__gte=F("sent_at")),
                name="notification_acknowledged_at_after_sent",
            )
        ]

    def __str__(self):
        return f"{self.service} notification for {self.alarm}"


class EventLog(models.Model):
    alarm = models.ForeignKey(Alarm, on_delete=models.SET_NULL, null=True, blank=True, related_name="event_logs")
    sensor = models.ForeignKey(Sensor, on_delete=models.SET_NULL, null=True, blank=True, related_name="event_logs")
    actuator = models.ForeignKey(Actuator, on_delete=models.SET_NULL, null=True, blank=True, related_name="event_logs")
    operator = models.ForeignKey(Operator, on_delete=models.SET_NULL, null=True, blank=True, related_name="event_logs")
    notification = models.ForeignKey(
        Notification,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="event_logs",
    )
    event_type = models.CharField(max_length=80, choices=EventType.choices)
    event_time = models.DateTimeField(default=timezone.now)
    action_label = models.CharField(max_length=150, blank=True)
    actor_type = models.CharField(max_length=30, choices=EventActorType.choices, default=EventActorType.SYSTEM)
    result = models.CharField(max_length=80, blank=True)
    reason = models.TextField(blank=True)
    control_area_status = models.CharField(max_length=30, choices=StaffingStatus.choices, blank=True)
    occupancy_status = models.CharField(max_length=80, blank=True)
    event_details = models.TextField(blank=True)
    source_system = models.CharField(max_length=80, default="FASAM")
    event_payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-event_time"]
        indexes = [
            models.Index(fields=["alarm"]),
            models.Index(fields=["event_time"]),
            models.Index(fields=["event_type"]),
            models.Index(fields=["actor_type"]),
            models.Index(fields=["result"]),
        ]

    def __str__(self):
        return f"{self.event_type} at {self.event_time:%Y-%m-%d %H:%M:%S}"


class ConfigAuditLog(models.Model):
    operator = models.ForeignKey(Operator, on_delete=models.SET_NULL, null=True, blank=True, related_name="config_audits")
    entity_name = models.CharField(max_length=100)
    entity_id = models.PositiveBigIntegerField(null=True, blank=True)
    change_type = models.CharField(max_length=30, choices=ConfigChangeType.choices)
    old_value = models.JSONField(null=True, blank=True)
    new_value = models.JSONField(null=True, blank=True)
    changed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-changed_at"]

    def __str__(self):
        return f"{self.change_type} {self.entity_name}"
