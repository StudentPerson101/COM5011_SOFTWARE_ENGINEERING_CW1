# Stage 7 Authentication And Authorization

This stage adds Django authentication and role-based authorization boundaries for the FASAM prototype. It does not add templates, operator action forms, simulations, seeded alarm data, or frontend integration.

## Auth Mechanism

- Django's built-in `auth`, `sessions`, and `admin` apps remain the authentication mechanism.
- Users log in through Django admin at `/admin/login/`.
- FASAM role groups are configured with `python manage.py configure_auth_roles`.
- The configuration page contract now requires an authenticated user with configuration permission.

## Role Groups

```text
FASAM Operators
FASAM Supervisors
FASAM Configuration Administrators
FASAM Maintenance
```

The role definitions live in:

```text
fasam/authz.py
```

The setup command lives in:

```text
fasam/management/commands/configure_auth_roles.py
```

## Authorization Boundaries

- Monitoring access is based on authenticated staff, monitoring group membership, or `fasam.view_alarm`.
- Operator actions are based on `fasam.add_operatoraction`.
- Actuator/control commands are based on `fasam.add_actuatorcommand`.
- Configuration access is based on `fasam.change_alarmpolicy`.
- `/configuration/` is protected with `login_required` and `permission_required`.
- `/page-design/configuration/` rejects unauthorized users instead of exposing the configuration design contract.
- `/auth-status/` reports the current user's FASAM authorization capabilities.

## Setup

Run migrations first so Django has created model permissions, then configure the FASAM groups:

```powershell
.\venv1\Scripts\python.exe manage.py migrate
.\venv1\Scripts\python.exe manage.py configure_auth_roles
.\venv1\Scripts\python.exe manage.py createsuperuser
```

After creating a user, assign that user to one of the FASAM groups through Django admin.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py configure_auth_roles
.\venv1\Scripts\python.exe manage.py shell -c "from fasam.authz import ROLE_DEFINITIONS, can_manage_configuration; print(len(ROLE_DEFINITIONS), can_manage_configuration(None))"
```
