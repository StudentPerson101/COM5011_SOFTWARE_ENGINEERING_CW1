# Stage 10 State Management

This stage adds server-side state management for the Django-rendered FASAM prototype. It does not add seed data, simulations, validation/error-handling rules, audit-trail expansion, tests, or deployment work.

## Managed State

State is now coordinated in:

```text
fasam/state.py
```

The state layer covers:

- Application summary state for active alarms, suspected/confirmed counts, fire/security counts, pending notifications, active zones, and control-area status.
- Dashboard filter state for alarm search, alarm type, severity, status, and zone.
- Zone overview state for search, status, alarm type, occupancy, device state, and selected zone.
- Event-log state for search, selected alarm/log, zone, alarm type, event type, and system/manual source.
- Incident response state summaries for fire and security incident screens.
- Control-area staffing state transitions using the existing `ControlArea` and `ControlAreaStatusLog` models.

## State Storage

The prototype uses existing Django models for operational state and Django sessions for UI state:

```text
ControlArea.current_staffing_status
ControlAreaStatusLog
Alarm.status
Alarm.confirmation_status
Actuator.status
Door.current_lock_state
ZoneIsolation.isolation_status
Notification.notification_status
request.session["fasam.dashboard_state"]
request.session["fasam.zone_state"]
request.session["fasam.log_state"]
```

This keeps Stage 10 inside the current schema and avoids adding migrations or seed data.

## UI Integration

The dashboard, zone overview, and event log filter forms are now real GET forms. Submitted filters are stored in the session, so returning to those pages preserves the operator's current view. Each page includes a reset link using `clear_state=1`.

The header now exposes a compact control-area staffing selector. Submitting it posts to:

```text
/control-area/state/
```

The view updates the configured control area, writes a status log row, and returns to the current page.

## Status Endpoint

`/stage-status/` now reports:

```text
Stage-10. State management
```

It also includes a `state_management` payload describing session-backed filters, model-backed control-area state, service-backed response snapshots, and application counts.

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from django.test import Client; c=Client(HTTP_HOST='127.0.0.1'); paths=['/dashboard/','/dashboard/?alarm_type=FIRE','/zones/','/zones/?status=normal','/logs/','/logs/?source=system','/stage-status/','/database-status/']; print({p: c.get(p).status_code for p in paths}); print(c.get('/stage-status/').json()['data']['completed_stage'])"
```
