# FASAM Django Prototype

Stage 14 adds a focused Django testing pass on top of the integrated FASAM Django frontend.

The project now has the runtime scaffold, backend framework boundaries, page/view contracts, a verified SQLite database connection, Django models/migrations for the FASAM domain schema, Python services for alarm confirmation, actuator response, escalation, event logging, Django auth role definitions, Bootstrap-oriented Django templates/static assets, model-backed views with operator action POST handling, session/model-backed state management, focused validation/error handling, authorized simulation controls, enriched audit logging, and Django tests for the critical service/view workflows.

This stage intentionally does not add the deployment stage from the supplied plan.

## Project Layout

```text
fasam-prototype/
|-- start_server.bat
|-- start_server.py
|-- create_desktop_shortcut.ps1
|-- manage.py
|-- requirements.txt
|-- README.md
|-- db.sqlite3
|-- docs/
|   |-- stage-3-page-view-design.md
|   |-- stage-4-database.md
|   |-- stage-5-data-model-schema.md
|   |-- stage-6-business-logic.md
|   |-- stage-7-authentication-authorization.md
|   |-- stage-8-frontend-structure.md
|   |-- stage-9-frontend-backend-integration.md
|   |-- stage-10-state-management.md
|   |-- stage-11-validation-error-handling.md
|   |-- stage-12-simulation-layer.md
|   |-- stage-13-event-logging-audit-trail.md
|   `-- stage-14-testing.md
|-- fasam_project/
|   |-- settings.py
|   |-- urls.py
|   |-- asgi.py
|   `-- wsgi.py
`-- fasam/
    |-- forms.py
    |-- models.py
    |-- state.py
    |-- validation.py
    |-- urls.py
    |-- views.py
    |-- management/commands/configure_auth_roles.py
    |-- migrations/0001_initial.py
    |-- services/
    |   |-- actuator_service.py
    |   |-- alarm_rules.py
    |   |-- escalation_service.py
    |   |-- simulation.py
    |   `-- event_logger.py
    |-- templates/fasam/
    |   |-- base.html
    |   |-- dashboard.html
    |   |-- fire_incident_detail.html
    |   |-- security_incident_detail.html
    |   |-- zone_overview.html
    |   |-- event_log.html
    |   |-- configuration.html
    |   |-- simulation.html
    |   |-- errors/error.html
    |   `-- partials/
    |       |-- alarm_queue.html
    |       |-- recent_logs.html
    |       `-- zone_status_cards.html
    `-- static/fasam/
        |-- css/styles.css
        `-- js/app.js
```

## Package Setup

The preferred distribution format is:

```text
FASAM Prototype Package/
|-- Setup FASAM Prototype.bat
`-- fasam-prototype/
    |-- start_server.bat
    |-- start_server.py
    |-- create_desktop_shortcut.ps1
    `-- ...
```

After extracting the package, double-click the top-level setup file:

```text
Setup FASAM Prototype.bat
```

The setup script checks for Python 3.12, can install it with WinGet, can create
the desktop shortcut, can install requirements into `.venv`, and can start the
server.

## Windows Project Startup

This prototype is intended to be started on Windows 10/11. From the extracted
`fasam-prototype` folder, double-click:

```text
start_server.bat
```

The launcher checks for Python 3.12 first. If Python 3.12 is missing, it asks:

```text
Auto install Python3.12? y/n
```

If the user enters `y`, the launcher installs Python 3.12 with WinGet:

```cmd
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
```

After Python is available, `start_server.py` asks:

```text
Create desktop shortcut? y/n
Auto install requirements? y/n
Auto start server? y/n
```

Selecting `y` for the desktop shortcut creates `FASAM Prototype Server.lnk` on
the current user's Desktop. The shortcut points to `start_server.bat` in the
current project folder, so recreate the shortcut if the project folder is moved.

Selecting `y` for requirements creates a fresh project-local `.venv`, upgrades
pip, and installs `requirements.txt` into that `.venv`. The existing `venv1`
folder is not required and should not be shipped with the final portable copy.

Selecting `y` for server startup applies migrations, configures the local FASAM
auth roles, starts Django's development server, and prints the browser URL.
When the server is running, enter: `http://127.0.0.1:8000/` into your preferred
browser or click CTRL+C in the terminal to end the server.

## Manual Runtime Setup

The automated launcher is preferred, but the equivalent manual setup is:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py configure_auth_roles
```

## Run The App Manually

```powershell
.\.venv\Scripts\python.exe manage.py runserver 0.0.0.0:8000
```

Then open the URL printed by Django or use:

```text
http://127.0.0.1:8000/
```

## Current HTML Endpoints

These routes render model-backed Django templates:

```text
http://127.0.0.1:8000/
http://127.0.0.1:8000/dashboard/
http://127.0.0.1:8000/dashboard/alarm-queue/
http://127.0.0.1:8000/alarms/fire/<alarm-reference>/
http://127.0.0.1:8000/alarms/security/<alarm-reference>/
http://127.0.0.1:8000/control-area/state/
http://127.0.0.1:8000/zones/
http://127.0.0.1:8000/logs/
http://127.0.0.1:8000/simulation/
http://127.0.0.1:8000/configuration/
```

The `simulation/` and `configuration/` routes require a logged-in Django user with `fasam.change_alarmpolicy` or staff/superuser access.

## Current JSON Endpoints

```text
http://127.0.0.1:8000/page-design/
http://127.0.0.1:8000/database-status/
http://127.0.0.1:8000/auth-status/
http://127.0.0.1:8000/health/
http://127.0.0.1:8000/stage-status/
```

## Stage 7 Auth Setup

Run the role setup after migrations:

```powershell
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py configure_auth_roles
.\.venv\Scripts\python.exe manage.py createsuperuser
```

Assign users to the FASAM groups in Django admin. Configuration access is permission-protected; ordinary monitoring pages are readable in this local prototype.

## Stage 9 Integration

The main views now query Django models and render live context:

```text
fasam/views.py
fasam/urls.py
fasam/forms.py
fasam/templates/fasam/
```

Dashboard alarm cards, incident details, zone cards, event-log rows, and configuration rule summaries are database-backed. Operator buttons submit to `alarms/<alarm-reference>/action/` and call the existing service layer for acknowledgement logging, manual notifications, alarm confirmation, security door locking, zone isolation, access restoration, safety-gated suppression/shutdown commands, and reset/restore.

For local prototype use, unauthenticated operator actions are logged as the simulated `operator_a` operator. Authenticated users are logged with their Django username.

## Stage 10 State Management

State management is centralized in:

```text
fasam/state.py
```

The application now manages:

- Dashboard filter state for search, alarm type, severity, status, and zone.
- Zone overview state for search, status, alarm type, occupancy, device state, and selected zone.
- Event-log state for search, selected alarm/log, zone, alarm type, event type, and system/manual source.
- Header-level control-area staffing state, persisted on the `ControlArea` model and recorded in `ControlAreaStatusLog`.
- Application state snapshots for active alarm counts, suspected/confirmed counts, fire/security counts, pending notifications, and control-area status.
- Incident response-state summaries for fire and security pages.

Operational state remains model-backed. UI filter/selection state uses Django sessions and can be reset per page with `clear_state=1`.

## Stage 11 Validation And Error Handling

Validation is centralized in:

```text
fasam/validation.py
fasam/forms.py
fasam/views.py
```

The app now validates alarm references, filter/query state, event-log selections, control-area state changes, safe local redirects, operator action compatibility, and safety-sensitive action preconditions. Invalid filter state is reset with a visible operator message instead of failing the request.

Expected errors are routed through friendly handlers for bad requests, restricted configuration access, missing records, unexpected server errors, and CSRF failures. HTML requests render `fasam/templates/fasam/errors/error.html`; JSON-preferring requests receive the existing structured error response.

## Stage 12 Simulation Layer

Simulation controls are centralized in:

```text
fasam/services/simulation.py
fasam/templates/fasam/simulation.html
```

The authorized simulation page supports demo data loading, manual fire/security sensor activation, occupancy overrides, control-area staffing changes, scenario presets, notification send/fail/retry/acknowledge states, simulated actuator commands, and reset/restore actions.

Simulation actions call the existing alarm, actuator, escalation, occupancy, and event-log services. They do not connect to real sensors, emergency services, sprinklers, door locks, electrical shutdown equipment, evacuation hardware, or external APIs.

Implemented scenario presets:

- Confirmed fire with people detected.
- Confirmed fire with unmanned control area.
- Security intrusion with zone isolation.
- False fire alarm.
- Occupancy unknown safety case.

## Stage 13 Event Logging / Audit Trail

Audit logging is centralized in:

```text
fasam/services/event_logger.py
fasam/templates/fasam/event_log.html
```

`EventLog` rows now keep normalized audit fields alongside the original detail text: action label, actor type, result, reason, control-area status, occupancy status, source system, and structured payload context. The logger automatically captures related alarm, zone, room, sensor, actuator, notification, operator, staffing, and occupancy context where available.

The `/logs/` page now supports search plus date, zone, alarm type, action type, operator, and system/operator/simulation filters. Selected log entries show the full audit context, link back to related incident and zone pages, support browser printing, and can export the current filtered log set as CSV with `?export=csv`.

`ConfigAuditLog` remains the configuration-specific audit table, and `log_config_change()` mirrors configuration changes into the main event log for one searchable audit trail.

## Stage 14 Testing

Testing is implemented in:

```text
fasam/tests.py
docs/stage-14-testing.md
```

The test suite covers Django models and constraints through real ORM writes, alarm-rule services, fire response safety blocking, automatic escalation, security containment, reset/restore behavior, simulation presets, notification simulation, model-backed pages, protected configuration/simulation access, operator action POSTs, CSV audit export, and stage-status reporting.

Run the test suite from this directory:

```powershell
.\.venv\Scripts\python.exe manage.py test
```

The tests use Django's temporary test database and do not require a running development server.

## Verification

```powershell
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py test
.\.venv\Scripts\python.exe manage.py shell -c "from fasam.services.simulation import ensure_demo_data, run_scenario, reset_all_simulation; from fasam.models import Alarm; print(ensure_demo_data().success); print(run_scenario('confirmed_fire_people').success); print(run_scenario('security_intrusion').success); print(Alarm.objects.filter(status__in=['SUSPECTED','CONFIRMED']).count()); print(reset_all_simulation().success)"
```

## Later Stage Notes

- Use HTMX only for targeted partial refresh behavior if it helps the alarm queue or logs.
