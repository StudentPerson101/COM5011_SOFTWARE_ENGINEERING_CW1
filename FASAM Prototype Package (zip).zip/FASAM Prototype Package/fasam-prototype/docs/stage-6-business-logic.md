# Stage 6 Business Logic

This stage adds the first FASAM business-rule layer on top of the Stage 5 Django data model. It does not add templates, authentication, simulations, seed data, or frontend behavior.

## Service Modules

```text
fasam/services/alarm_rules.py
fasam/services/actuator_service.py
fasam/services/escalation_service.py
fasam/services/event_logger.py
```

## Covered Rules

- Fire and security sensor activations create or update active alarms for the affected room and zone.
- Confirmation rules use `AlarmPolicy` when configured, with a safe default of multiple matching sensors in the confirmation window.
- Confirmed fire alarms activate exit indicators and audible evacuation alarms.
- Sprinkler and electrical shutdown commands are blocked when the latest room occupancy reading detects people in the same room.
- Confirmed security alarms lock internal doors and create active zone isolation records.
- Serious confirmed alarms automatically notify emergency services when the related control area is unmanned.
- Manual or automatic notifications can target fire, security, or emergency services.
- System and operator actions are written to `EventLog`.

## Boundary

This stage keeps the logic callable from Python services only. Later stages can connect these services to forms, authenticated operator workflows, templates, and test/simulation fixtures.

## Example Use

```powershell
.\venv1\Scripts\python.exe manage.py shell
```

```python
from fasam.models import Sensor
from fasam.services.alarm_rules import record_sensor_activation

sensor = Sensor.objects.get(device_code="S-31")
result = record_sensor_activation(sensor, severity="HIGH", evidence_note="Smoke threshold exceeded")
result.success
```

## Verification

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py shell -c "from fasam.services.alarm_rules import record_sensor_activation; from fasam.services.actuator_service import activate_fire_response; from fasam.services.escalation_service import auto_escalate_if_required; print('stage-6 services import ok')"
```
