# Stage 14 - Testing

Stage 14 adds Django test coverage for the model-backed FASAM prototype. The tests are intentionally local and database-backed: they exercise Django models, service-layer rules, views, permissions, operator actions, simulation workflows, audit logging, and the stage/status endpoints without connecting to real emergency services or hardware.

## Coverage Added

- Fire alarm rule behavior:
  - A single fire sensor creates a suspected alarm.
  - Multiple fire sensors in one zone confirm a fire alarm.
  - Confirmed fire activates evacuation indicators and audible alarms.
  - Occupancy readings block or allow sprinkler and electrical-shutdown actions.
- Escalation behavior:
  - Serious confirmed alarms automatically create an emergency-services notification when the control area is unmanned.
  - Simulated notification send/fail/retry/acknowledge states are persisted as database records only.
- Security response behavior:
  - Confirmed security alarms lock configured doors.
  - Zone isolation records are created and released by reset/restore.
- Simulation workflows:
  - Scenario presets are executable through services and authorized POST views.
  - Unknown occupancy defaults to safety blocking.
  - False fire alarms resolve without escalation.
  - Reset restores alarms, doors, isolations, and actuators while preserving audit history.
- UI and authorization behavior:
  - Dashboard, incident detail, zone overview, and event-log pages render model-backed content.
  - Configuration and simulation pages require authenticated configuration permission.
  - Operator action POSTs update alarm state and create mirrored audit events.
  - Event log CSV export includes audit context columns.

## Run Tests

From the project directory:

```powershell
.\venv1\Scripts\python.exe manage.py test
```

The tests use Django's temporary test database. They do not require the development server and do not write to the project `db.sqlite3`.

## Boundary

This stage does not add deployment, production hardening, external API integrations, browser automation, or new product features. It verifies the behavior already implemented by Stages 1-13.
