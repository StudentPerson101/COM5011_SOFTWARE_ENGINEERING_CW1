"""Page and view design contracts for the FASAM prototype.

Stage 3 records what each page should expose without querying a database,
rendering templates, or implementing operator actions.
"""
from dataclasses import asdict, dataclass, field


@dataclass(frozen=True)
class PageDesign:
    key: str
    title: str
    route_name: str
    path: str
    planned_template: str
    wireframe_source: str
    purpose: str
    primary_sections: list[str]
    filters: list[str] = field(default_factory=list)
    operator_actions: list[str] = field(default_factory=list)
    context_contract: dict[str, str] = field(default_factory=dict)
    deferred_until_later_stages: list[str] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


PAGE_DESIGNS = {
    "dashboard": PageDesign(
        key="dashboard",
        title="Control Area Dashboard",
        route_name="fasam:dashboard",
        path="/dashboard/",
        planned_template="fasam/dashboard.html",
        wireframe_source="wireframes/p1 - Control Area Dashboard.txt",
        purpose=(
            "Give operators a single control-area view of active fire and "
            "security alarms, staffed status, severity, confirmation state, "
            "and recommended next action."
        ),
        primary_sections=[
            "control_area_summary",
            "navigation",
            "alarm_search",
            "alarm_filters",
            "active_alarm_queue",
        ],
        filters=["alarm_type", "severity", "status", "zone"],
        operator_actions=[
            "open_incident",
            "acknowledge_alarm",
            "view_affected_zone",
        ],
        context_contract={
            "control_area": "staffing status and operator display details",
            "active_alarms": "ordered fire and security alarm summaries",
            "filters": "available alarm type, severity, status, and zone filters",
        },
        deferred_until_later_stages=[
            "database-backed alarm query",
            "acknowledge action handler",
            "dashboard template",
            "HTMX alarm queue refresh",
        ],
    ),
    "fire_incident_detail": PageDesign(
        key="fire_incident_detail",
        title="Fire Alarm Incident Details",
        route_name="fasam:fire_incident_detail",
        path="/alarms/fire/<alarm_reference>/",
        planned_template="fasam/fire_incident_detail.html",
        wireframe_source="wireframes/p2 - Fire Alarm Incident Details.txt",
        purpose=(
            "Show fire incident status, confirmation evidence, occupancy "
            "state, escalation status, recommended response sequence, and "
            "safety-sensitive blocked actions."
        ),
        primary_sections=[
            "incident_header",
            "incident_summary",
            "recommended_response_sequence",
            "operator_actions",
            "safety_sensitive_actions",
        ],
        operator_actions=[
            "notify_fire_services",
            "confirm_operator_response",
            "view_affected_zone",
            "view_event_log",
            "reset_restore_system",
        ],
        context_contract={
            "alarm": "fire alarm identity, zone, severity, status, and age",
            "confirmation": "sensor evidence and confirmation status",
            "occupancy": "human presence status for suppression decisions",
            "response_steps": "evacuation, suppression, shutdown, and notification statuses",
        },
        deferred_until_later_stages=[
            "fire confirmation logic",
            "occupancy blocking logic",
            "actuator command handling",
            "fire incident template",
        ],
    ),
    "security_incident_detail": PageDesign(
        key="security_incident_detail",
        title="Security Alarm Incident Details",
        route_name="fasam:security_incident_detail",
        path="/alarms/security/<alarm_reference>/",
        planned_template="fasam/security_incident_detail.html",
        wireframe_source="wireframes/p3 - Security Alarm Incident Details.txt",
        purpose=(
            "Show security incident confirmation, affected zone, internal "
            "door locking, zone isolation, security-service notification, "
            "and restoration actions."
        ),
        primary_sections=[
            "incident_header",
            "incident_summary",
            "door_locking_status",
            "zone_isolation_status",
            "notification_status",
            "operator_actions",
        ],
        operator_actions=[
            "notify_security_services",
            "lock_internal_doors",
            "isolate_zone",
            "unlock_restore_access",
            "view_affected_zone",
            "reset_alarm",
        ],
        context_contract={
            "alarm": "security alarm identity, zone, severity, status, and age",
            "confirmation": "door and motion evidence for the alarm",
            "door_locks": "affected doors and lock state",
            "zone_isolation": "affected zone and isolation state",
        },
        deferred_until_later_stages=[
            "security confirmation logic",
            "door locking handler",
            "zone isolation handler",
            "security incident template",
        ],
    ),
    "zone_overview": PageDesign(
        key="zone_overview",
        title="Zone Status / Building Overview",
        route_name="fasam:zone_overview",
        path="/zones/",
        planned_template="fasam/zone_overview.html",
        wireframe_source="wireframes/p4 - Zone Status or Building Overview.txt",
        purpose=(
            "Summarize building zones, current fire/security state, occupancy, "
            "device condition, and selected-zone details."
        ),
        primary_sections=[
            "zone_search",
            "zone_filters",
            "zone_cards",
            "selected_zone_details",
        ],
        filters=["status", "alarm_type", "occupancy", "device_state"],
        operator_actions=["view_zone"],
        context_contract={
            "zones": "cards with zone names, statuses, occupancy, and device summaries",
            "selected_zone": "current detailed zone state when a zone is selected",
            "filters": "available zone status, alarm, occupancy, and device filters",
        },
        deferred_until_later_stages=[
            "zone model query",
            "device status aggregation",
            "zone overview template",
        ],
    ),
    "event_log": PageDesign(
        key="event_log",
        title="Event Log / Audit History",
        route_name="fasam:event_log",
        path="/logs/",
        planned_template="fasam/event_log.html",
        wireframe_source="wireframes/p5 - Event Log or Audit History.txt",
        purpose=(
            "Allow operators to search, filter, inspect, export, and trace "
            "alarm, actuator, notification, and operator events."
        ),
        primary_sections=[
            "log_search",
            "log_filters",
            "event_log_table",
            "selected_log_entry",
            "log_actions",
        ],
        filters=["date", "zone", "alarm_type", "action_type", "operator", "source"],
        operator_actions=[
            "export_log",
            "view_related_incident",
            "view_zone",
            "print_report",
        ],
        context_contract={
            "events": "ordered event rows with time, event, zone, and recorded-by fields",
            "selected_event": "detail panel for the selected event",
            "filters": "available event-log filter values",
        },
        deferred_until_later_stages=[],
    ),
    "configuration": PageDesign(
        key="configuration",
        title="Configuration / Authorized Settings",
        route_name="fasam:configuration",
        path="/configuration/",
        planned_template="fasam/configuration.html",
        wireframe_source="wireframes/p6 - Configuration or Authorized Settings.txt",
        purpose=(
            "Define the authorized-operator configuration surface for zones, "
            "confirmation rules, actuator behavior, escalation rules, and "
            "user permissions."
        ),
        primary_sections=[
            "authorization_status",
            "configuration_menu",
            "alarm_confirmation_rule_editor",
            "audit_notice",
        ],
        operator_actions=["save_rule", "cancel"],
        context_contract={
            "authorization": "current user's configuration authorization state",
            "configuration_sections": "zone, confirmation, actuator, escalation, and access menus",
            "rule_editor": "draft alarm confirmation rule fields",
        },
        deferred_until_later_stages=[
            "authentication and authorization",
            "configuration forms",
            "audit logging",
            "configuration template",
        ],
    ),
}


def list_page_designs():
    return [page.to_dict() for page in PAGE_DESIGNS.values()]


def get_page_design(key):
    return PAGE_DESIGNS.get(key)
