"""App URL configuration for the current FASAM prototype endpoints."""
from django.urls import path

from . import views


app_name = "fasam"

urlpatterns = [
    path("", views.dashboard, name="home"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("dashboard/alarm-queue/", views.alarm_queue_partial, name="alarm_queue_partial"),
    path(
        "alarms/fire/<str:alarm_reference>/",
        views.fire_incident,
        name="fire_incident_detail",
    ),
    path(
        "alarms/security/<str:alarm_reference>/",
        views.security_incident,
        name="security_incident_detail",
    ),
    path("alarms/<str:alarm_reference>/action/", views.alarm_action, name="alarm_action"),
    path("control-area/state/", views.control_area_state, name="control_area_state"),
    path("zones/", views.zone_overview, name="zone_overview"),
    path("logs/", views.event_log, name="event_log"),
    path("simulation/", views.simulation, name="simulation"),
    path("simulation/action/", views.simulation_action, name="simulation_action"),
    path("configuration/", views.configuration, name="configuration"),
    path("backend-ready/", views.runtime_ready, name="runtime_ready"),
    path("health/", views.health_check, name="health_check"),
    path("stage-status/", views.stage_status, name="stage_status"),
    path("database-status/", views.database_status, name="database_status"),
    path("auth-status/", views.auth_status, name="auth_status"),
    path("page-design/", views.page_design_index, name="page_design_index"),
    path("page-design/<slug:key>/", views.page_design_detail, name="page_design_detail"),
]
