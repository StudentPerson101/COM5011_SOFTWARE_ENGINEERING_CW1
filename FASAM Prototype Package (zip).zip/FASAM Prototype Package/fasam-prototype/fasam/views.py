"""Integrated views for the FASAM Django app."""
from __future__ import annotations

import csv

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db.models import Count, Q
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

from .authz import CONFIGURATION_PERMISSION, auth_status_payload, can_manage_configuration
from .database import database_health, database_summary
from .forms import ControlAreaStateForm, OperatorActionForm, SimulationActionForm
from .http import ok_response
from .models import (
    ActuatorKind,
    Actuator,
    Alarm,
    AlarmConfirmation,
    AlarmStatus,
    AlarmType,
    CommandType,
    ConfirmationMethod,
    ConfirmationStatus,
    ControlArea,
    DoorLockState,
    EventLog,
    EventType,
    NotificationMode,
    Operator,
    OperatorActionType,
    Room,
    ResponseRule,
    Sensor,
    SensorCategory,
    ServiceType,
    Severity,
    Zone,
)
from .page_design import get_page_design, list_page_designs
from .services.actuator_service import issue_actuator_command, isolate_zone, latest_occupancy_decision, lock_security_doors, restore_zone_access
from .services.alarm_rules import handle_confirmed_alarm
from .services.contracts import ServiceResult
from .services.escalation_service import default_service_for_alarm, notify_service
from .services.event_logger import log_event, log_operator_action
from .services.simulation import (
    SIMULATION_SOURCE,
    clear_alarm,
    ensure_demo_data,
    reset_all_simulation,
    reset_zone,
    run_scenario,
    scenario_presets,
    set_occupancy,
    simulate_notification,
    simulation_summary,
    trigger_multiple_sensors,
    trigger_sensor,
)
from .state import (
    alarm_response_state,
    application_state_snapshot,
    apply_dashboard_state,
    apply_event_log_state,
    apply_zone_state,
    dashboard_request_state,
    event_log_request_state,
    security_response_state,
    selected_zone_from_state,
    transition_control_area_state,
    zone_request_state,
)
from .validation import form_error_summary, parse_alarm_reference, safe_next_url, validate_operator_action


ACTIVE_ALARM_STATUSES = (AlarmStatus.SUSPECTED, AlarmStatus.CONFIRMED)
TERMINAL_ALARM_STATUSES = (AlarmStatus.FALSE_ALARM, AlarmStatus.RESOLVED)


def _page_design_payload(page_key, **extra):
    page = get_page_design(page_key)
    if page is None:
        raise Http404(f"Unknown FASAM page design: {page_key}")

    payload = {
        "stage": "Stage-3. Page/view design",
        "page": page.to_dict(),
    }
    payload.update(extra)
    return ok_response(payload)


def _active_alarm_queryset():
    return (
        Alarm.objects.select_related("zone", "room", "policy")
        .prefetch_related("sensor_evidence__sensor", "notifications", "actuator_commands")
        .filter(status__in=ACTIVE_ALARM_STATUSES)
        .order_by("-first_detected_at")
    )


def _alarm_reference(alarm: Alarm | None) -> str:
    return "" if alarm is None or alarm.pk is None else f"A-{alarm.pk:04d}"


def _parse_alarm_reference(reference: str) -> int:
    try:
        return parse_alarm_reference(reference)
    except DjangoValidationError as exc:
        raise Http404(exc.messages[0]) from exc


def _duration_label(started_at):
    if not started_at:
        return "Unknown"
    elapsed = max(int((timezone.now() - started_at).total_seconds()), 0)
    hours, remainder = divmod(elapsed, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    return f"{minutes:02d}:{seconds:02d}"


def _badge_for_severity(severity: str) -> str:
    return {
        Severity.CRITICAL: "text-bg-danger",
        Severity.HIGH: "text-bg-warning",
        Severity.MEDIUM: "text-bg-info",
        Severity.LOW: "text-bg-secondary",
    }.get(severity, "text-bg-secondary")


def _first_alarm_reference(alarm_type: str) -> dict | None:
    alarm = (
        Alarm.objects.filter(alarm_type=alarm_type)
        .exclude(status__in=TERMINAL_ALARM_STATUSES)
        .order_by("-first_detected_at")
        .first()
    )
    if alarm is None:
        alarm = Alarm.objects.filter(alarm_type=alarm_type).order_by("-first_detected_at").first()
    return {"reference": _alarm_reference(alarm)} if alarm else None


def _base_context(request, active_nav: str = "") -> dict:
    app_state = application_state_snapshot()
    control_area = app_state["control_area"]
    operator_label = request.user.get_username() if request.user.is_authenticated else "Operator A (simulated)"
    return {
        "active_nav": active_nav,
        "control_area": control_area,
        "app_state": app_state,
        "control_area_status": app_state["control_area_status"],
        "control_area_state_form": ControlAreaStateForm(
            initial={
                "staffing_status": control_area.current_staffing_status if control_area else "",
                "next": request.get_full_path(),
            }
        ),
        "active_alarm_count": app_state["active_alarm_count"],
        "operator_label": operator_label,
        "first_fire_alarm": _first_alarm_reference(AlarmType.FIRE),
        "first_security_alarm": _first_alarm_reference(AlarmType.SECURITY),
        "authorization_status": (
            "Authorized Operator" if can_manage_configuration(request.user) else "Monitoring access"
        ),
    }


def _evidence_summary(alarm: Alarm) -> str:
    sensors = list(alarm.sensor_evidence.select_related("sensor").order_by("sensor__device_code"))
    if not sensors:
        return "No sensor evidence recorded"
    distinct_codes = sorted({evidence.sensor.device_code for evidence in sensors})
    if len(distinct_codes) == 1:
        return f"1 sensor matched: {distinct_codes[0]}"
    return f"{len(distinct_codes)} sensors matched: {', '.join(distinct_codes[:4])}"


def _alarm_detail_url(alarm: Alarm) -> str:
    route_name = "fasam:fire_incident_detail" if alarm.alarm_type == AlarmType.FIRE else "fasam:security_incident_detail"
    return reverse(route_name, args=[_alarm_reference(alarm)])


def _surface_state_errors(request, page_state, label: str) -> None:
    if page_state.source == "invalid":
        messages.warning(request, f"{label} filters were reset because one or more values were not valid.")


def _zone_url(zone: Zone | None) -> str:
    base = reverse("fasam:zone_overview")
    return base if zone is None else f"{base}?zone={zone.pk}"


def _alarm_card(alarm: Alarm) -> dict:
    return {
        "object": alarm,
        "reference": _alarm_reference(alarm),
        "type_label": alarm.get_alarm_type_display(),
        "type_class": "alarm-card-fire" if alarm.alarm_type == AlarmType.FIRE else "alarm-card-security",
        "severity": alarm.get_severity_display(),
        "severity_badge": _badge_for_severity(alarm.severity),
        "zone": str(alarm.zone),
        "status": alarm.get_status_display(),
        "confirmation": _evidence_summary(alarm),
        "time_active": _duration_label(alarm.first_detected_at),
        "recommended_action": alarm.recommended_action or "Review alarm and follow configured response policy.",
        "detail_url": _alarm_detail_url(alarm),
        "zone_url": _zone_url(alarm.zone),
    }


def _alarm_context(alarm: Alarm) -> dict:
    context = {
        "alarm": alarm,
        "alarm_reference": _alarm_reference(alarm),
        "evidence_summary": _evidence_summary(alarm),
        "time_active": _duration_label(alarm.first_detected_at),
        "action_url": reverse("fasam:alarm_action", args=[_alarm_reference(alarm)]),
        "zone_url": _zone_url(alarm.zone),
        "event_log_url": f"{reverse('fasam:event_log')}?alarm={alarm.pk}",
        "notifications": alarm.notifications.select_related("service").order_by("-sent_at"),
        "operator_actions": alarm.operator_actions.select_related("operator").order_by("-action_time")[:5],
    }
    context["has_service_notification"] = alarm.notifications.filter(notification_status="SENT").exists()
    return context


def _manual_operator(request) -> Operator:
    if request.user.is_authenticated:
        username = request.user.get_username()
        full_name = request.user.get_full_name() or username
    else:
        username = "operator_a"
        full_name = "Operator A"

    operator, _created = Operator.objects.get_or_create(
        username=username,
        defaults={"full_name": full_name, "is_authorized": True},
    )
    return operator


def _manual_confirm_alarm(alarm: Alarm, operator: Operator, action_type: str) -> None:
    if alarm.status != AlarmStatus.CONFIRMED:
        alarm.status = AlarmStatus.CONFIRMED
        alarm.confirmation_status = ConfirmationStatus.CONFIRMED
        alarm.confirmed_at = timezone.now()
        alarm.recommended_action = (
            "Evacuate, activate indicators/audible alarms, and notify fire services as required."
            if alarm.alarm_type == AlarmType.FIRE
            else "Lock internal doors, isolate affected zone, and notify security services as required."
        )
        alarm.save(update_fields=["status", "confirmation_status", "confirmed_at", "recommended_action"])
        AlarmConfirmation.objects.create(
            alarm=alarm,
            policy=alarm.policy,
            sensor_count_used=max(alarm.sensor_evidence.values("sensor_id").distinct().count(), 1),
            confirmation_method=ConfirmationMethod.OPERATOR_CONFIRMED,
            confirmed_by_operator=operator,
            decision_note="Confirmed from integrated incident detail screen.",
        )
        log_event(EventType.ALARM_CONFIRMED, alarm=alarm, operator=operator, details="Operator confirmed alarm.")
        handle_confirmed_alarm(alarm)
    log_operator_action(alarm, operator, action_type, "Manual confirmation from incident detail screen.")


def _issue_safety_sensitive_command(alarm: Alarm, operator: Operator, actuator_kind: str) -> tuple[bool, str]:
    occupancy = latest_occupancy_decision(alarm.room)
    if occupancy.people_detected:
        log_event(
            EventType.ACTUATOR_COMMAND_ISSUED,
            alarm=alarm,
            operator=operator,
            details=f"Manual {actuator_kind} command blocked: {occupancy.reason}",
            result="Blocked",
            reason=occupancy.reason,
            occupancy_status=occupancy.status_label,
        )
        return False, f"{occupancy.reason} Command blocked."

    actuators = alarm.zone.actuators.select_related("actuator_type").filter(
        actuator_type__type_code=actuator_kind,
        is_active=True,
    )
    if alarm.room_id:
        actuators = actuators.filter(Q(room=alarm.room) | Q(room__isnull=True))

    issued = 0
    for actuator in actuators:
        issue_actuator_command(actuator, CommandType.ACTIVATE, alarm=alarm, operator=operator)
        issued += 1

    if not issued:
        return False, f"No active {actuator_kind.lower().replace('_', ' ')} actuators are configured for this alarm."
    return True, f"{issued} {actuator_kind.lower().replace('_', ' ')} command(s) issued."


def _zone_summary(zone: Zone) -> dict:
    active_alarms = list(zone.alarms.filter(status__in=ACTIVE_ALARM_STATUSES).order_by("-first_detected_at"))
    latest_alarm = active_alarms[0] if active_alarms else None
    locked_doors = zone.doors.filter(current_lock_state=DoorLockState.LOCKED).count()
    active_actuators = zone.actuators.filter(status="ACTIVE").count()
    occupancy = (
        zone.rooms.filter(occupancy_readings__isnull=False)
        .annotate(reading_count=Count("occupancy_readings"))
        .order_by("-occupancy_readings__reading_time")
        .first()
    )
    people_detected = False
    if occupancy is not None:
        latest_reading = occupancy.occupancy_readings.order_by("-reading_time").first()
        people_detected = bool(latest_reading and latest_reading.detected_people)

    if latest_alarm is None:
        state = "Normal"
        state_class = ""
    elif latest_alarm.alarm_type == AlarmType.FIRE and latest_alarm.status == AlarmStatus.CONFIRMED:
        state = "Fire Confirmed"
        state_class = "zone-fire"
    elif latest_alarm.alarm_type == AlarmType.FIRE:
        state = "Fire Suspected"
        state_class = "zone-watch"
    elif latest_alarm.alarm_type == AlarmType.SECURITY:
        state = "Security Active"
        state_class = "zone-security"
    else:
        state = latest_alarm.get_status_display()
        state_class = ""

    return {
        "object": zone,
        "name": zone.zone_code,
        "area": zone.zone_name,
        "state": state,
        "state_class": state_class,
        "locked_doors": locked_doors,
        "active_actuators": active_actuators,
        "people_detected": people_detected,
        "latest_alarm": latest_alarm,
        "url": _zone_url(zone),
    }


def _selected_zone_context(zone: Zone | None) -> dict | None:
    if zone is None:
        return None

    active_alarms = zone.alarms.filter(status__in=ACTIVE_ALARM_STATUSES)
    fire_active = active_alarms.filter(alarm_type=AlarmType.FIRE).count()
    security_active = active_alarms.filter(alarm_type=AlarmType.SECURITY).count()
    latest_alarm = active_alarms.order_by("-first_detected_at").first()
    active_actuator_kinds = set(
        zone.actuators.filter(status="ACTIVE").values_list("actuator_type__type_code", flat=True)
    )
    locked_doors = zone.doors.filter(current_lock_state=DoorLockState.LOCKED).count()
    latest_occupancy = (
        zone.rooms.filter(occupancy_readings__isnull=False)
        .order_by("-occupancy_readings__reading_time")
        .first()
    )
    people_detected = False
    if latest_occupancy:
        latest_reading = latest_occupancy.occupancy_readings.order_by("-reading_time").first()
        people_detected = bool(latest_reading and latest_reading.detected_people)

    return {
        "zone": zone,
        "current_state": _zone_summary(zone)["state"],
        "fire_active": fire_active,
        "security_active": security_active,
        "people_detected": people_detected,
        "sprinklers": "Active" if ActuatorKind.SPRINKLER in active_actuator_kinds else "Ready/blocked by rule",
        "electrical_shutdown": (
            "Active" if ActuatorKind.ELECTRICAL_SHUTDOWN in active_actuator_kinds else "Ready/blocked by rule"
        ),
        "exit_indicators": "Active" if ActuatorKind.EXIT_INDICATOR in active_actuator_kinds else "Ready",
        "audible_alarm": "Active" if ActuatorKind.AUDIBLE_ALARM in active_actuator_kinds else "Ready",
        "internal_doors": f"{locked_doors} locked" if locked_doors else "Normal",
        "latest_alarm": latest_alarm,
    }


def runtime_ready(_request):
    return ok_response(
        {
            "application": "FASAM",
            "message": "Django prototype includes tested service, simulation, view, authorization, and audit-log workflows.",
            "stage": "Stage-14. Testing",
        }
    )


def health_check(_request):
    return ok_response({"status": "healthy"})


def stage_status(_request):
    app_state = application_state_snapshot()
    return ok_response(
        {
            "completed_stage": "Stage-14. Testing",
            "page_view_design": "complete",
            "database": database_summary(),
            "database_models": "defined",
            "business_logic": {
                "alarm_rules": "integrated",
                "actuator_rules": "integrated",
                "escalation_rules": "integrated",
                "event_logging": "integrated",
            },
            "authentication": auth_status_payload(_request.user),
            "frontend_structure": {
                "templates": "model_backed",
                "partials": "model_backed",
                "static_assets": "defined",
                "frontend_backend_integration": "complete",
            },
            "state_management": {
                "dashboard_filters": "session_backed",
                "zone_selection": "query_or_session_backed",
                "event_log_selection": "query_or_session_backed",
                "control_area_staffing": "model_backed",
                "response_state_snapshots": "service_backed",
                "application_state": {
                    "control_area_status": app_state["control_area_status"],
                    "active_alarm_count": app_state["active_alarm_count"],
                    "suspected_alarm_count": app_state["suspected_alarm_count"],
                    "confirmed_alarm_count": app_state["confirmed_alarm_count"],
                    "notification_pending_count": app_state["notification_pending_count"],
                },
            },
            "validation_error_handling": {
                "alarm_reference_validation": "A-0001/numeric references are parsed before lookup",
                "filter_validation": "dashboard, zone, and log filters use Django forms and reset invalid state",
                "operator_action_validation": "POST actions are checked against alarm type and current status",
                "safety_action_validation": "sprinkler and electrical shutdown actions require confirmed fire alarms and clear occupancy",
                "safe_redirects": "control-area state redirects are restricted to local URLs",
                "friendly_error_pages": "400, 403, 404, 500, and CSRF failures render operator-readable pages",
            },
            "simulation_layer": {
                "simulation_page": "/simulation/",
                "permission_model": "requires authenticated configuration permission or staff access",
                "manual_fire_sensor_events": "use record_sensor_activation service",
                "manual_security_sensor_events": "use record_sensor_activation service",
                "occupancy_overrides": "write OccupancyReading rows or clear readings for unknown state",
                "control_area_staffing": "uses existing ControlArea state transition helper",
                "scenario_presets": [preset.key for preset in scenario_presets()],
                "reset_restore": "resolves active alarms and restores doors/actuators without deleting audit history by default",
                "external_integrations": "none; notifications, actuators, sensors, and doors are simulated only",
                "summary": simulation_summary(),
            },
            "event_logging_audit_trail": {
                "event_model": "normalized EventLog rows include actor type, action label, result, reason, staffing, occupancy, source, and payload context",
                "operator_actions": "operator actions mirror into EventLog",
                "configuration_audit": "ConfigAuditLog rows can be mirrored through the event logger helper",
                "filters": "date, zone, alarm type, action type, operator, and actor/source filters",
                "export": "CSV export available from /logs/?export=csv",
                "trace_links": "selected log entries link back to related incidents and zones",
            },
            "testing": {
                "framework": "Django TestCase",
                "command": "python manage.py test",
                "coverage_focus": [
                    "alarm rule services",
                    "fire safety actuator blocking",
                    "automatic escalation",
                    "security containment",
                    "simulation presets and reset",
                    "view rendering and authorization",
                    "operator actions",
                    "event-log CSV export",
                ],
            },
            "data_counts": {
                "active_alarms": app_state["active_alarm_count"],
                "zones": Zone.objects.count(),
                "event_logs": EventLog.objects.count(),
            },
            "page_count": len(list_page_designs()),
            "debug": settings.DEBUG,
        }
    )


def page_design_index(_request):
    return ok_response(
        {
            "stage": "Stage-3. Page/view design",
            "pages": list_page_designs(),
        }
    )


def page_design_detail(_request, key):
    if key == "configuration" and not can_manage_configuration(_request.user):
        raise PermissionDenied("Configuration design requires FASAM configuration permission.")
    return _page_design_payload(key)


def database_status(_request):
    return ok_response(
        {
            "stage": "Stage-5. Data model / schema",
            "database": database_summary(),
            "health": database_health(),
            "domain_schema": "defined_by_django_models",
            "frontend_backend_integration": "views query Django models directly",
            "state_management": "uses existing models plus Django session state",
        }
    )


def auth_status(_request):
    return ok_response(
        {
            "stage": "Stage-7. Authentication and authorization",
            "authentication": auth_status_payload(_request.user),
        }
    )


def dashboard(request):
    zones = list(Zone.objects.order_by("zone_code"))
    page_state = dashboard_request_state(request, zones)
    _surface_state_errors(request, page_state, "Dashboard")
    alarms = [_alarm_card(alarm) for alarm in apply_dashboard_state(_active_alarm_queryset(), page_state.values)]
    context = _base_context(request, "dashboard")
    context.update(
        {
            "alarms": alarms,
            "zones": zones,
            "dashboard_state_form": page_state.form,
            "dashboard_state": page_state,
        }
    )
    return render(request, "fasam/dashboard.html", context)


def alarm_queue_partial(request):
    zones = list(Zone.objects.order_by("zone_code"))
    page_state = dashboard_request_state(request, zones)
    context = _base_context(request, "dashboard")
    context.update(
        {
            "alarms": [
                _alarm_card(alarm)
                for alarm in apply_dashboard_state(_active_alarm_queryset(), page_state.values)
            ]
        }
    )
    return render(request, "fasam/partials/alarm_queue.html", context)


def fire_incident(request, alarm_reference):
    alarm = get_object_or_404(
        Alarm.objects.select_related("zone", "room", "policy"),
        pk=_parse_alarm_reference(alarm_reference),
        alarm_type=AlarmType.FIRE,
    )
    response_state = alarm_response_state(alarm)
    context = _base_context(request, "fire")
    context.update(_alarm_context(alarm))
    context.update(
        {
            "occupancy": response_state["occupancy"],
            "control_area_status_detail": context["control_area_status"],
            "has_service_notification": response_state["has_service_notification"],
            "response_steps": response_state["response_steps"],
        }
    )
    return render(request, "fasam/fire_incident_detail.html", context)


def security_incident(request, alarm_reference):
    alarm = get_object_or_404(
        Alarm.objects.select_related("zone", "room", "policy"),
        pk=_parse_alarm_reference(alarm_reference),
        alarm_type=AlarmType.SECURITY,
    )
    response_state = security_response_state(alarm)
    context = _base_context(request, "security")
    context.update(_alarm_context(alarm))
    context.update(response_state)
    return render(request, "fasam/security_incident_detail.html", context)


def zone_overview(request):
    zones = list(Zone.objects.prefetch_related("alarms", "doors", "actuators", "rooms").order_by("zone_code"))
    page_state = zone_request_state(request, zones)
    _surface_state_errors(request, page_state, "Zone")
    summaries = [_zone_summary(zone) for zone in zones]
    filtered_summaries = apply_zone_state(summaries, page_state.values)
    selected_zone = selected_zone_from_state(zones, page_state.values)
    if selected_zone is None and filtered_summaries:
        selected_zone = filtered_summaries[0]["object"]

    context = _base_context(request, "zones")
    context.update(
        {
            "zone_summaries": filtered_summaries,
            "selected_zone": _selected_zone_context(selected_zone),
            "zone_state_form": page_state.form,
            "zone_state": page_state,
        }
    )
    return render(request, "fasam/zone_overview.html", context)


def _event_log_csv_response(logs):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="fasam-event-log.csv"'
    writer = csv.writer(response)
    writer.writerow(
        [
            "Time",
            "Event",
            "Action",
            "Alarm",
            "Alarm Type",
            "Zone",
            "Device",
            "Recorded By",
            "Actor Type",
            "Result",
            "Reason",
            "Control Area",
            "Occupancy",
            "Source",
            "Details",
        ]
    )
    for log in logs:
        alarm_reference = _alarm_reference(log.alarm) if log.alarm else ""
        device = log.sensor.device_code if log.sensor else log.actuator.device_code if log.actuator else ""
        recorded_by = log.operator.full_name or log.operator.username if log.operator else log.get_actor_type_display()
        writer.writerow(
            [
                log.event_time.isoformat(),
                log.get_event_type_display(),
                log.action_label,
                alarm_reference,
                log.alarm.alarm_type if log.alarm else "",
                str(log.alarm.zone) if log.alarm else "",
                device,
                recorded_by,
                log.get_actor_type_display(),
                log.result,
                log.reason,
                log.get_control_area_status_display() if log.control_area_status else "",
                log.occupancy_status,
                log.source_system,
                log.event_details,
            ]
        )
    return response


def event_log(request):
    zones = list(Zone.objects.order_by("zone_code"))
    page_state = event_log_request_state(request, zones)
    _surface_state_errors(request, page_state, "Event log")
    logs = (
        EventLog.objects.select_related(
            "alarm",
            "alarm__zone",
            "sensor",
            "actuator",
            "operator",
            "notification",
        )
        .order_by("-event_time")
    )
    logs = apply_event_log_state(logs, page_state.values)
    if request.GET.get("export") == "csv":
        return _event_log_csv_response(logs[:1000])

    logs = logs[:100]
    selected_log = logs.first()
    if page_state.values.get("log"):
        selected_log = get_object_or_404(
            EventLog.objects.select_related("alarm", "alarm__zone", "sensor", "actuator", "operator", "notification"),
            pk=page_state.values["log"],
        )

    context = _base_context(request, "logs")
    context.update(
        {
            "logs": logs,
            "selected_log": selected_log,
            "event_log_state_form": page_state.form,
            "event_log_state": page_state,
        }
    )
    return render(request, "fasam/event_log.html", context)


@login_required
@permission_required(CONFIGURATION_PERMISSION, raise_exception=True)
def simulation(request):
    zones = Zone.objects.prefetch_related("rooms", "sensors", "actuators", "doors").order_by("zone_code")
    alarms = Alarm.objects.select_related("zone").filter(status__in=ACTIVE_ALARM_STATUSES).order_by("-first_detected_at")
    context = _base_context(request, "simulation")
    context.update(
        {
            "simulation_summary": simulation_summary(),
            "simulation_form": SimulationActionForm(),
            "scenario_presets": scenario_presets(),
            "zones": zones,
            "rooms": Room.objects.select_related("zone").order_by("zone__zone_code", "room_code"),
            "fire_sensors": (
                Sensor.objects.select_related("zone", "room", "sensor_type")
                .filter(sensor_type__category=SensorCategory.FIRE)
                .order_by("zone__zone_code", "device_code")
            ),
            "security_sensors": (
                Sensor.objects.select_related("zone", "room", "sensor_type")
                .filter(sensor_type__category=SensorCategory.SECURITY)
                .order_by("zone__zone_code", "device_code")
            ),
            "active_alarms": alarms,
            "actuators": Actuator.objects.select_related("zone", "room", "actuator_type").order_by("zone__zone_code", "device_code"),
            "command_choices": CommandType.choices,
            "severity_choices": Severity.choices,
            "staffing_choices": ControlAreaStateForm.base_fields["staffing_status"].choices,
            "service_choices": ServiceType.choices,
            "recent_simulation_logs": EventLog.objects.filter(source_system=SIMULATION_SOURCE).order_by("-event_time")[:8],
        }
    )
    return render(request, "fasam/simulation.html", context)


@login_required
@permission_required(CONFIGURATION_PERMISSION, raise_exception=True)
@require_POST
def simulation_action(request):
    form = SimulationActionForm(request.POST)
    if not form.is_valid():
        messages.error(request, f"Simulation action rejected. {form_error_summary(form)}")
        return redirect("fasam:simulation")

    operator = _manual_operator(request)
    action = form.cleaned_data["action"]
    result = None
    alarm = None

    try:
        if action == "ensure_demo_data":
            result = ensure_demo_data(operator=operator)
        elif action == "trigger_fire_sensor":
            sensor = get_object_or_404(Sensor.objects.select_related("sensor_type"), pk=form.cleaned_data["sensor"])
            if sensor.sensor_type.category != SensorCategory.FIRE:
                messages.error(request, "Selected sensor is not a fire sensor.")
                return redirect("fasam:simulation")
            result = trigger_sensor(sensor, severity=form.cleaned_data.get("severity") or Severity.HIGH, operator=operator)
            alarm = result.data.get("alarm") if result.success else None
        elif action == "trigger_fire_multi":
            zone = get_object_or_404(Zone, pk=form.cleaned_data["zone"])
            result = trigger_multiple_sensors(
                zone,
                AlarmType.FIRE,
                2,
                severity=form.cleaned_data.get("severity") or Severity.HIGH,
                operator=operator,
            )
            alarm = result.data.get("alarm") if result.success else None
        elif action == "trigger_security_sensor":
            sensor = get_object_or_404(Sensor.objects.select_related("sensor_type"), pk=form.cleaned_data["sensor"])
            if sensor.sensor_type.category != SensorCategory.SECURITY:
                messages.error(request, "Selected sensor is not a security sensor.")
                return redirect("fasam:simulation")
            result = trigger_sensor(sensor, severity=form.cleaned_data.get("severity") or Severity.HIGH, operator=operator)
            alarm = result.data.get("alarm") if result.success else None
        elif action == "trigger_security_multi":
            zone = get_object_or_404(Zone, pk=form.cleaned_data["zone"])
            result = trigger_multiple_sensors(zone, AlarmType.SECURITY, 2, severity=Severity.HIGH, operator=operator)
            alarm = result.data.get("alarm") if result.success else None
        elif action == "set_occupancy":
            room = get_object_or_404(Room, pk=form.cleaned_data["room"])
            result = set_occupancy(room, form.cleaned_data["occupancy_state"], operator=operator)
        elif action == "set_control_area":
            result = transition_control_area_state(
                ControlArea.objects.order_by("name").first(),
                form.cleaned_data["staffing_status"],
                operator,
            )
        elif action == "simulate_actuator":
            actuator = get_object_or_404(Actuator.objects.select_related("actuator_type"), pk=form.cleaned_data["actuator"])
            alarm_id = form.cleaned_data.get("alarm")
            related_alarm = Alarm.objects.filter(pk=alarm_id).first() if alarm_id else None
            issue_actuator_command(actuator, form.cleaned_data["command_type"], alarm=related_alarm, operator=operator)
            log_event(
                EventType.ACTUATOR_COMMAND_ISSUED,
                alarm=related_alarm,
                actuator=actuator,
                operator=operator,
                details=f"Simulation actuator command {form.cleaned_data['command_type']} sent to {actuator.device_code}.",
                source_system=SIMULATION_SOURCE,
            )
            result = ServiceResult.ok("Actuator command simulated.")
        elif action == "run_scenario":
            result = run_scenario(form.cleaned_data["scenario"], operator=operator)
            alarm = result.data.get("alarm") if result.success else None
        elif action == "simulate_notification":
            alarm = get_object_or_404(Alarm, pk=form.cleaned_data["alarm"])
            result = simulate_notification(
                alarm,
                form.cleaned_data["notification_action"],
                form.cleaned_data.get("service_type") or None,
                operator=operator,
            )
        elif action == "reset":
            reset_scope = form.cleaned_data["reset_scope"]
            if reset_scope == "selected_alarm":
                alarm = get_object_or_404(Alarm, pk=form.cleaned_data["alarm"])
                result = clear_alarm(alarm, operator=operator)
                alarm = None
            elif reset_scope == "selected_zone":
                zone = get_object_or_404(Zone, pk=form.cleaned_data["zone"])
                result = reset_zone(zone, operator=operator)
            elif reset_scope == "reload_demo":
                result = ensure_demo_data(operator=operator)
            elif reset_scope == "clear_logs":
                result = reset_all_simulation(operator=operator, clear_logs=True)
            else:
                result = reset_all_simulation(operator=operator)
    except ValueError as exc:
        messages.error(request, f"Simulation action failed. {exc}")
        return redirect("fasam:simulation")

    if result is None:
        messages.error(request, "Simulation action was not recognized.")
        return redirect("fasam:simulation")

    if result.success:
        messages.success(request, result.message or "Simulation action completed.")
    else:
        messages.error(request, result.message or "Simulation action failed.")
    if alarm is not None:
        return redirect(_alarm_detail_url(alarm))
    return redirect("fasam:simulation")


@login_required
@permission_required(CONFIGURATION_PERMISSION, raise_exception=True)
def configuration(request):
    context = _base_context(request, "configuration")
    context.update(
        {
            "policies": (
                ResponseRule.objects.select_related("policy", "policy__zone")
                .order_by("policy__zone__zone_code", "policy__alarm_type", "priority")
            ),
            "zones": Zone.objects.order_by("zone_code"),
            "control_areas": ControlArea.objects.order_by("name"),
        }
    )
    return render(request, "fasam/configuration.html", context)


@require_POST
def control_area_state(request):
    form = ControlAreaStateForm(request.POST)
    next_url = safe_next_url(request, request.POST.get("next"), "fasam:dashboard")
    if not form.is_valid():
        messages.error(request, f"Control area state could not be updated. {form_error_summary(form)}")
        return redirect(next_url)

    operator = _manual_operator(request)
    result = transition_control_area_state(
        ControlArea.objects.order_by("name").first(),
        form.cleaned_data["staffing_status"],
        operator,
    )
    messages.success(request, result.message) if result.success else messages.error(request, result.message)
    return redirect(safe_next_url(request, form.cleaned_data.get("next"), "fasam:dashboard"))


@require_POST
def alarm_action(request, alarm_reference):
    alarm = get_object_or_404(Alarm, pk=_parse_alarm_reference(alarm_reference))
    operator = _manual_operator(request)
    form = OperatorActionForm(request.POST)
    if not form.is_valid():
        messages.error(request, f"Operator action rejected. {form_error_summary(form)}")
        log_event(
            EventType.OPERATOR_ACTION,
            alarm=alarm,
            operator=operator,
            details=f"Rejected malformed operator action: {form_error_summary(form)}",
        )
        return redirect(_alarm_detail_url(alarm))

    action = form.cleaned_data["action"]
    is_valid_action, validation_message = validate_operator_action(alarm, action)
    if not is_valid_action:
        messages.error(request, validation_message)
        log_event(
            EventType.OPERATOR_ACTION,
            alarm=alarm,
            operator=operator,
            details=f"Rejected {action} action: {validation_message}",
        )
        return redirect(_alarm_detail_url(alarm))

    if action == "acknowledge":
        log_operator_action(alarm, operator, OperatorActionType.ACKNOWLEDGE_ALARM, "Alarm acknowledged from dashboard.")
        messages.success(request, f"{_alarm_reference(alarm)} acknowledged.")
    elif action == "notify_service":
        service_type = default_service_for_alarm(alarm)
        notify_service(
            alarm,
            service_type,
            mode=NotificationMode.MANUAL,
            operator=operator,
            message_summary=f"Manual notification for {_alarm_reference(alarm)} in {alarm.zone}.",
        )
        action_type = (
            OperatorActionType.CONTACT_FIRE_SERVICES
            if alarm.alarm_type == AlarmType.FIRE
            else OperatorActionType.CONTACT_SECURITY_SERVICES
        )
        log_operator_action(alarm, operator, action_type, "External service notified from incident detail screen.")
        messages.success(request, "Service notification recorded.")
    elif action == "confirm_fire" and alarm.alarm_type == AlarmType.FIRE:
        _manual_confirm_alarm(alarm, operator, OperatorActionType.CONFIRM_FIRE_ALARM)
        messages.success(request, "Fire alarm confirmed and response rules evaluated.")
    elif action == "confirm_security" and alarm.alarm_type == AlarmType.SECURITY:
        _manual_confirm_alarm(alarm, operator, OperatorActionType.CONFIRM_SECURITY_ALARM)
        messages.success(request, "Security alarm confirmed and response rules evaluated.")
    elif action == "confirm_response":
        log_operator_action(alarm, operator, OperatorActionType.VIEW_CONFIRMATION_STATUS, "Operator response confirmed.")
        messages.success(request, "Operator response confirmation logged.")
    elif action == "lock_doors":
        result = lock_security_doors(alarm, operator=operator)
        messages.success(request, result.message) if result.success else messages.error(request, result.message)
    elif action == "isolate_zone":
        result = isolate_zone(alarm, operator=operator)
        messages.success(request, result.message) if result.success else messages.error(request, result.message)
    elif action == "restore_access":
        result = restore_zone_access(alarm.zone, operator=operator, alarm=alarm)
        messages.success(request, result.message) if result.success else messages.error(request, result.message)
    elif action == "activate_sprinklers":
        success, message = _issue_safety_sensitive_command(alarm, operator, ActuatorKind.SPRINKLER)
        messages.success(request, message) if success else messages.error(request, message)
    elif action == "shutdown_electrical":
        success, message = _issue_safety_sensitive_command(alarm, operator, ActuatorKind.ELECTRICAL_SHUTDOWN)
        messages.success(request, message) if success else messages.error(request, message)
    elif action == "reset_restore":
        restore_zone_access(alarm.zone, operator=operator, alarm=alarm)
        alarm.status = AlarmStatus.RESOLVED
        alarm.resolved_at = timezone.now()
        alarm.save(update_fields=["status", "resolved_at"])
        log_operator_action(alarm, operator, OperatorActionType.RESET_RESTORE_SYSTEM, "Alarm resolved from UI.")
        log_event(EventType.SYSTEM_RESET, alarm=alarm, operator=operator, details="Alarm reset/restored from UI.")
        messages.success(request, f"{_alarm_reference(alarm)} reset and marked resolved.")
    else:
        messages.error(request, "That action is not valid for this alarm.")

    return redirect(_alarm_detail_url(alarm))


def _client_accepts_json(request) -> bool:
    return "application/json" in request.headers.get("Accept", "")


def _error_page(request, *, status_code: int, title: str, message: str, exception=None):
    if _client_accepts_json(request):
        from .http import error_response

        return error_response(message, status=status_code, code=title.lower().replace(" ", "_"))

    return render(
        request,
        "fasam/errors/error.html",
        {
            "status_code": status_code,
            "title": title,
            "message": message,
            "exception": exception,
            "dashboard_url": reverse("fasam:dashboard"),
            "logs_url": reverse("fasam:event_log"),
        },
        status=status_code,
    )


def bad_request(request, exception):
    return _error_page(
        request,
        status_code=400,
        title="Request Not Accepted",
        message="The submitted request could not be validated. Check the value and try again.",
        exception=exception,
    )


def permission_denied(request, exception):
    return _error_page(
        request,
        status_code=403,
        title="Access Restricted",
        message="This FASAM area is restricted to authorized configuration users.",
        exception=exception,
    )


def page_not_found(request, exception):
    return _error_page(
        request,
        status_code=404,
        title="Record Not Found",
        message="The requested FASAM page or alarm record could not be found.",
        exception=exception,
    )


def server_error(request):
    return _error_page(
        request,
        status_code=500,
        title="System Error",
        message="The prototype hit an unexpected error while handling the request.",
    )


def csrf_failure(request, reason=""):
    return _error_page(
        request,
        status_code=403,
        title="Form Expired",
        message="The form could not be accepted because its security token was missing or expired.",
        exception=reason,
    )
