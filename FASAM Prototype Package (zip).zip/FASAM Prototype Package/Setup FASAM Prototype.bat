@echo off
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
title FASAM Prototype Setup

set "PROJECT_ROOT=%~dp0fasam-prototype"

echo.
echo FASAM Prototype Setup
echo =====================
echo.

if not exist "%PROJECT_ROOT%\start_server.py" (
    echo Could not find the fasam-prototype folder next to this setup file.
    echo Expected: %PROJECT_ROOT%
    echo.
    pause
    exit /b 1
)

call :FindPython312

if not defined PYTHON_LAUNCHER (
    echo Python 3.12 was not found on this system.
    echo.
    set /p INSTALL_PYTHON=Auto install Python3.12? y/n: 

    if /I "!INSTALL_PYTHON!"=="Y" (
        where winget >nul 2>nul
        if errorlevel 1 (
            echo.
            echo WinGet was not found, so Python cannot be installed automatically.
            echo Install Python 3.12 from https://www.python.org/downloads/windows/ and run this setup again.
            echo.
            pause
            exit /b 1
        )

        echo.
        echo Installing Python 3.12 with WinGet...
        winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
        if errorlevel 1 (
            echo.
            echo Python installation did not complete successfully.
            echo.
            pause
            exit /b 1
        )

        call :FindPython312
        if not defined PYTHON_LAUNCHER (
            echo.
            echo Python may have installed, but this terminal cannot see it yet.
            echo Close this window, run this setup again, and try once more.
            echo.
            pause
            exit /b 1
        )
    ) else (
        echo.
        echo Setup cancelled. Python 3.12 is required to run this prototype.
        echo.
        pause
        exit /b 1
    )
)

echo.
set /p CREATE_SHORTCUT=Create desktop shortcut? y/n: 
if /I "!CREATE_SHORTCUT!"=="Y" (
    %PYTHON_LAUNCHER% "%PROJECT_ROOT%\start_server.py" --create-shortcut
    if errorlevel 1 goto :SetupFailed
) else (
    echo Desktop shortcut creation skipped.
)

echo.
set /p INSTALL_REQUIREMENTS=Auto install requirements? y/n: 
if /I "!INSTALL_REQUIREMENTS!"=="Y" (
    %PYTHON_LAUNCHER% "%PROJECT_ROOT%\start_server.py" --install-requirements
    if errorlevel 1 goto :SetupFailed
) else (
    echo Requirement installation skipped.
)

echo.
set /p START_SERVER=Auto start server? y/n: 
if /I "!START_SERVER!"=="Y" (
    %PYTHON_LAUNCHER% "%PROJECT_ROOT%\start_server.py" --start-server
    if errorlevel 1 goto :SetupFailed
) else (
    echo.
    echo Setup complete. Use the desktop shortcut or fasam-prototype\start_server.bat to start the server later.
)

echo.
pause
exit /b 0

:SetupFailed
echo.
echo Setup stopped before completion.
echo.
pause
exit /b 1

:FindPython312
set PYTHON_LAUNCHER=

py -3.12 -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
if not errorlevel 1 (
    set PYTHON_LAUNCHER=py -3.12
    exit /b 0
)

python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 12) else 1)" >nul 2>nul
if not errorlevel 1 (
    set PYTHON_LAUNCHER=python
    exit /b 0
)

exit /b 0
