"""Lightweight service contracts shared by future backend services."""
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ServiceResult:
    """Standard shape for service results without coupling to views."""

    success: bool
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def ok(cls, message="", **data):
        return cls(success=True, message=message, data=data)

    @classmethod
    def failed(cls, message, **data):
        return cls(success=False, message=message, data=data)
