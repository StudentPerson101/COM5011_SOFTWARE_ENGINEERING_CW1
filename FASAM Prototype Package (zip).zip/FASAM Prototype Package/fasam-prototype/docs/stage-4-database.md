# Stage 4 Database

This stage establishes and verifies the local database layer for the FASAM Django prototype.

The active database is SQLite through Django's configured `default` connection:

```text
ENGINE: django.db.backends.sqlite3
NAME: db.sqlite3
```

The database file is generated locally by Django migrations. At this stage, only Django's built-in app tables are created, such as auth, admin, sessions, and content types. FASAM domain tables are intentionally deferred to the data model / schema stage.

## What This Stage Includes

- SQLite database configuration in Django settings.
- A local `db.sqlite3` file created by `python manage.py migrate`.
- Database connection and table introspection helpers in `fasam/database.py`.
- A JSON database status endpoint at `/database-status/`.
- Documentation of the database boundary for later stages.

## What This Stage Defers

- FASAM models for buildings, zones, rooms, sensors, alarms, actuators, notifications, operators, and event logs.
- FASAM migrations and indexes.
- Seed data for zones, sensors, users, alarms, rules, and event history.
- Business logic that writes alarms, actuator commands, notifications, or audit entries.

## Verification Commands

```powershell
.\venv1\Scripts\python.exe manage.py check
.\venv1\Scripts\python.exe manage.py migrate
.\venv1\Scripts\python.exe manage.py showmigrations
```

After migrations, the endpoint below should report `can_connect: true` and list the installed Django tables:

```text
http://127.0.0.1:8000/database-status/
```
