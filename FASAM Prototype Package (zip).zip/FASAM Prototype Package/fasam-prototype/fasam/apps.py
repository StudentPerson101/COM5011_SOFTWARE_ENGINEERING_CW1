from django.apps import AppConfig


class FasamConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "fasam"
    verbose_name = "FASAM"
