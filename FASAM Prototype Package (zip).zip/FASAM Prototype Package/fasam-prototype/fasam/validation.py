"""Validation helpers for expected FASAM user and service input."""
from __future__ import annotations

import re

from django.core.exceptions import ValidationError
from django.shortcuts import resolve_url
from django.utils.http import url_has_allowed_host_and_scheme

from .models import AlarmStatus, AlarmType


ALARM_REFERENCE_RE = re.compile(r"^(?:A-)?(?P<pk>0*[1-9][0-9]{0,11})$", re.IGNORECASE)

FIRE_ACTIONS = {
    "acknowledge",
    "notify_service",
    "confirm_fire",
    "confirm_response",
    "activate_sprinklers",
    "shutdown_electrical",
    "reset_restore",
}
SECURITY_ACTIONS = {
    "acknowledge",
    "notify_service",
    "confirm_security",
    "lock_doors",
    "isolate_zone",
    "restore_access",
    "reset_restore",
}


def parse_alarm_reference(reference: str) -> int:
    """Parse UI alarm references such as A-0007 or plain numeric IDs."""

    candidate = str(reference or "").strip()
    match = ALARM_REFERENCE_RE.fullmatch(candidate)
    if match is None:
        raise ValidationError("Enter an alarm reference such as A-0001.", code="invalid_alarm_reference")
    return int(match.group("pk"))


def form_error_summary(form) -> str:
    """Flatten form errors into a short, operator-readable message."""

    messages = []
    for field_name, errors in form.errors.items():
        label = form.fields.get(field_name).label if field_name in form.fields else field_name
        prefix = "" if field_name == "__all__" else f"{label or field_name}: "
        messages.extend(f"{prefix}{error}" for error in errors)
    return " ".join(messages) or "Submitted values were not valid."


def safe_next_url(request, candidate: str | None, fallback="fasam:dashboard") -> str:
    """Return an internal redirect target, falling back when next is unsafe."""

    fallback_url = resolve_url(fallback)
    if not candidate:
        return fallback_url
    if url_has_allowed_host_and_scheme(
        candidate,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return candidate
    return fallback_url


def validate_operator_action(alarm, action: str):
    """Validate that an operator POST action is allowed for the alarm state."""

    if alarm.status in (AlarmStatus.FALSE_ALARM, AlarmStatus.RESOLVED):
        return False, "Resolved or false alarms no longer accept operator actions."

    allowed = FIRE_ACTIONS if alarm.alarm_type == AlarmType.FIRE else SECURITY_ACTIONS
    if action not in allowed:
        return False, "That action is not valid for this alarm type."

    if action in {"activate_sprinklers", "shutdown_electrical"} and alarm.status != AlarmStatus.CONFIRMED:
        return False, "Safety-sensitive fire actions require a confirmed fire alarm."

    if action in {"lock_doors", "isolate_zone"} and alarm.status != AlarmStatus.CONFIRMED:
        return False, "Security containment actions require a confirmed security alarm."

    return True, ""
