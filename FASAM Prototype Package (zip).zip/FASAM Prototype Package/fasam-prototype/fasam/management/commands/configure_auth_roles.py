"""Create Django groups and permissions for the FASAM prototype."""
from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand

from fasam.authz import ROLE_DEFINITIONS


class Command(BaseCommand):
    help = "Create or update FASAM role groups using Django auth permissions."

    def handle(self, *args, **options):
        created_groups = []
        updated_groups = []
        missing_permissions = {}

        for role in ROLE_DEFINITIONS:
            group, created = Group.objects.get_or_create(name=role.name)
            permissions = Permission.objects.filter(
                content_type__app_label="fasam",
                codename__in=[perm.split(".", 1)[1] for perm in role.permissions],
            )
            found_codenames = {f"fasam.{permission.codename}" for permission in permissions}
            missing = sorted(set(role.permissions) - found_codenames)
            if missing:
                missing_permissions[role.name] = missing

            group.permissions.set(permissions)
            if created:
                created_groups.append(role.name)
            else:
                updated_groups.append(role.name)

        self.stdout.write(self.style.SUCCESS("FASAM auth roles configured."))
        if created_groups:
            self.stdout.write(f"Created groups: {', '.join(created_groups)}")
        if updated_groups:
            self.stdout.write(f"Updated groups: {', '.join(updated_groups)}")
        if missing_permissions:
            self.stdout.write(self.style.WARNING("Some permissions were not found:"))
            for group_name, permissions in missing_permissions.items():
                self.stdout.write(f"  {group_name}: {', '.join(permissions)}")
